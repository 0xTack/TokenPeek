#!/usr/bin/env python3
"""信息跟踪 CLI。

    python main.py run        # 抓取 + 聚类打分 + 跟踪 + （到点且今天没出过就）出日报
    python main.py fetch      # 只抓取
    python main.py process    # 只聚类打分
    python main.py watch      # 只同步勾选 + 找跟踪进展
    python main.py digest     # 只出日报（--force 覆盖当天）
    python main.py status     # 看看库里的情况
"""

from __future__ import annotations

import argparse
import re
import sys
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

from tracker import db, judgment, render
from tracker import watch as watch_mod
from tracker.adapters import build_adapters, build_session
from tracker.ai import AI
from tracker.cluster import assign
from tracker.config import Config, load
from tracker.scoring import score
from tracker.translate import Translator


def log(message: str) -> None:
    print("[%s] %s" % (datetime.now().strftime("%H:%M:%S"), message), flush=True)


SOURCE_LABELS = [
    ("baidu_hot", "百度热搜", "cn"),
    ("toutiao_hot", "头条热榜", "cn"),
    ("qq_hot", "腾讯新闻", "cn"),
    ("weibo_hot", "微博热搜", "cn"),
    ("zhihu_hot", "知乎热榜", "cn"),
    ("xiaohongshu_hot", "小红书热点", "cn"),
    ("bilibili_hot", "B站热搜", "cn"),
    ("douyin_hot", "抖音热榜", "cn"),
    ("hackernews", "Hacker News", "intl"),
    ("github_trending", "GitHub Trending", "intl"),
    ("reddit", "Reddit", "intl"),
    ("rss", "RSS 订阅", "cn"),
]


def write_status(cfg: Config, conn) -> None:
    """写一份 data/status.json 给 Obsidian 插件读，省得插件去解析 YAML。"""
    import json

    sources_cfg = cfg.section("sources")
    sources = []
    for key, label, region in SOURCE_LABELS:
        item = sources_cfg.get(key) or {}
        sources.append(
            {
                "key": key,
                "label": label,
                "enabled": bool(item.get("enabled")),
                "region": item.get("region") or region,
            }
        )

    # 把每一个 RSS 订阅也单独列出来，方便逐个开关
    rss_cfg = sources_cfg.get("rss") or {}
    rss_disabled = set(rss_cfg.get("disabled") or [])
    for index, feed in enumerate(rss_cfg.get("feeds") or []):
        url = feed.get("url") or ""
        if not url:
            continue
        sources.append(
            {
                "key": "rss:%d" % index,
                "label": feed.get("name") or url,
                "enabled": url not in rss_disabled,
                "region": feed.get("region") or "cn",
                "url": url,
            }
        )

    now = datetime.now().astimezone()
    day = now.strftime("%Y-%m-%d")
    digest_path = cfg.digest_dir / ("%s.md" % day)
    last = conn.execute("SELECT * FROM digests ORDER BY date DESC LIMIT 1").fetchone()
    watches = db.list_watches(conn, active_only=True)

    alerts = {"unread": 0, "updated_at": "", "items": []}
    alerts_path = cfg.root / "data" / "alerts.json"
    if alerts_path.exists():
        try:
            alerts = json.loads(alerts_path.read_text(encoding="utf-8"))
        except ValueError:
            pass

    ai_cfg = cfg.ai
    ai_obj = AI(ai_cfg, conn)
    rows = conn.execute(
        """
        SELECT i.id, i.title, i.url, i.source, i.region, i.cluster_id,
               i.summary, c.score, c.topic
        FROM items i
        JOIN clusters c ON c.id = i.cluster_id
        WHERE i.digested_on = ?
        ORDER BY c.score DESC, i.metric DESC
        """,
        (day,),
    ).fetchall()

    top_items = []
    mobile_items = []
    seen = set()
    for row in rows:
        if row["cluster_id"] in seen:
            continue
        seen.add(row["cluster_id"])
        watch = db.get_watch_by_item(conn, row["id"])
        entry = {
            "id": row["id"],
            "title": row["title"],
            "url": row["url"],
            "source": row["source"],
            "region": row["region"],
            "score": float(row["score"] or 0),
            "topic": row["topic"] or "",
            "summary": row["summary"] or "",
            "tracked": bool(watch and watch["active"]),
            "has_ai": bool(ai_obj.cached(row["title"])),
            "has_judgment": bool(judgment.get_by_item(conn, int(row["id"]))),
        }
        mobile_items.append(entry)
        if len(top_items) < 10:
            top_items.append(entry)

    history_items = []
    for watch in watches:
        rows_h = db.list_watch_history(conn, watch["id"])
        first = rows_h[0] if rows_h else None
        try:
            note = str(Path(watch["note_path"]).relative_to(cfg.vault_dir).with_suffix(""))
        except ValueError:
            note = Path(watch["note_path"]).stem
        updates_count = conn.execute(
            "SELECT COUNT(*) AS n FROM watch_updates WHERE watch_id = ?", (watch["id"],)
        ).fetchone()["n"]
        history_items.append(
            {
                "watch_id": watch["id"],
                "title": watch["title"],
                "note": note,
                "count": len(rows_h),
                "updates": int(updates_count or 0),
                "forward": int(watch["forward"] or 0),
                "backward": int(watch["backward"] or 0),
                "deep": int(watch["deep"] or 0),
                "first_date": (first["at"][:10] if first else ""),
                "first_title": (first["title"] if first else ""),
                "first_url": (first["url"] if first else ""),
                "first_source": (first["source"] if first else ""),
            }
        )

    payload = {
        "generated_at": now.isoformat(timespec="seconds"),
        "vault": str(cfg.vault_dir),
        "digest_folder": str(Path(cfg.digest_dir).relative_to(cfg.vault_dir)),
        "watch_folder": str(Path(cfg.watch_dir).relative_to(cfg.vault_dir)),
        "today": day,
        "digest_exists": digest_path.exists(),
        "digest_path": str(digest_path),
        "stats": {
            "items": db.count_items(conn),
            "watches": len(watches),
            "last_digest": last["date"] if last else "",
            "last_digest_items": last["item_count"] if last else 0,
        },
        "sources": sources,
        "top_items": top_items,
        "mobile_items": mobile_items,
        "history": history_items,
        "judgments": judgment.status_list(conn, limit=20),
        "filters": cfg.section("filters") or {},
        "dedupe": cfg.section("dedupe") or {},
        "cookies": {key: bool(value) for key, value in (cfg.cookies or {}).items()},
        "cookie_meta": cfg.section("cookies_meta") or {},
        "ai": {
            "enabled": ai_cfg["enabled"],
            "base_url": ai_cfg["base_url"],
            "model": ai_cfg["model"],
            "has_key": bool(ai_cfg["api_key"]),
        },
        "alerts": alerts,
    }

    path = cfg.root / "data" / "status.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    # 手机端没有 Python，只能读 vault 里的快照。写完 status.json 再写一份到 vault。
    try:
        vault_folder = str(
            Path(cfg.section("vault").get("folder", "朝闻天下/日报")).parts[0]
        )
        mobile_dir = cfg.vault_dir / vault_folder / ".同步数据"
        mobile_dir.mkdir(parents=True, exist_ok=True)
        mobile_payload = dict(payload)
        mobile_payload["vault"] = ""
        mobile_payload["digest_path"] = "%s/%s.md" % (payload["digest_folder"], day)
        mobile_payload["mobile_items"] = mobile_items
        mobile_payload["ai"] = {
            "enabled": False,
            "base_url": ai_cfg["base_url"],
            "model": ai_cfg["model"],
            "reasoning_effort": ai_cfg.get("reasoning_effort", ""),
            "has_key": False,
        }
        (mobile_dir / "mobile.json").write_text(
            json.dumps(mobile_payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception as exc:
        print("[warn] 写入手机快照失败：%s" % exc, file=sys.stderr)


def cmd_fetch(cfg: Config, conn) -> int:
    from concurrent.futures import ThreadPoolExecutor

    session = build_session(cfg.http)
    adapters = build_adapters(cfg, session)
    if not adapters:
        log("没有启用任何信息源，检查 config.yaml")
        return 0

    def run_one(adapter):
        try:
            return adapter, adapter.fetch(), None
        except Exception as exc:
            return adapter, [], exc

    with ThreadPoolExecutor(max_workers=6) as pool:
        results = list(pool.map(run_one, adapters))

    collected = []
    for adapter, got, exc in results:
        if exc is not None:
            log("!! %s 抓取异常: %s" % (adapter.name, exc))
            continue
        log("%s %-18s %3d 条" % ("✓" if got else "·", adapter.name, len(got)))
        collected.extend(got)

    inserted = db.upsert_items(conn, collected)
    log("抓取 %d 条，去重后新增 %d 条" % (len(collected), inserted))
    return inserted


def _cluster_window(cfg: Config) -> str:
    hours = max(48, cfg.window_hours * 2)
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    return cutoff.isoformat(timespec="seconds")


def cmd_process(cfg: Config, conn) -> None:
    since = _cluster_window(cfg)
    threshold = float(cfg.section("clustering").get("threshold", 0.5))
    keep = set(cfg.section("clustering").get("keep_separate") or [])
    clusters = assign(conn, since, threshold, keep)
    stats = score(conn, since, cfg.scoring)
    log("聚类 %d 组，打分 %d 条" % (clusters, stats["items"]))


def cmd_watch(cfg: Config, conn) -> int:
    session = build_session(cfg.http)
    ai = AI(cfg.ai, conn, session)

    added, removed = watch_mod.sync_from_notes(conn, cfg, ai)
    if added or removed:
        log("跟踪：新增 %d 条，取消 %d 条" % (added, removed))

    watch_mod.sync_reads_from_notes(conn, cfg)

    updates = watch_mod.update_watches(conn, cfg, ai=ai)
    if updates:
        log("跟踪：发现 %d 条新进展" % updates)

    try:
        classified = judgment.classify_pending(conn, cfg, ai)
    except Exception as exc:  # 证据归类失败不能拖垮抓取/出报
        log("判断：证据归类失败（已跳过）：%s" % exc)
        classified = 0
    if classified:
        log("判断：自动归类 %d 条证据" % classified)

    try:
        cmd_stats(cfg, conn)
    except Exception as exc:
        log("统计：刷新失败（已跳过）：%s" % exc)
    return updates


def cmd_watch_stop(cfg: Config, conn, watch_id: int) -> int:
    row = watch_mod.stop_watch(conn, cfg, watch_id)
    if row is None:
        log("跟踪不存在：%s" % watch_id)
        return 1
    log("已停止追踪：%s" % row["title"])
    return 0


def cmd_watch_start(cfg: Config, conn, watch_id: int) -> int:
    row = watch_mod.resume_watch(conn, cfg, watch_id)
    if row is None:
        log("跟踪不存在：%s" % watch_id)
        return 1
    log("已重新开始追踪：%s" % row["title"])
    return 0


def cmd_watch_sort(cfg: Config, conn, watch_id: int, order: str) -> int:
    row = db.get_watch(conn, watch_id)
    if row is None:
        log("跟踪不存在：%s" % watch_id)
        return 1
    watch_mod._rewrite_note(conn, cfg, row, order=order)
    log("时间线已切换为：%s" % ("最新在前" if order == "newest" else "最初在前"))
    return 0


def cmd_stats(cfg: Config, conn, day: str = None) -> int:
    """刷新某份日报末尾的统计块，不抓取、不重排正文。"""
    now = datetime.now().astimezone()
    day = day or now.strftime("%Y-%m-%d")
    path = cfg.digest_dir / ("%s.md" % day)
    if not path.exists():
        log("找不到 %s 的日报，跳过统计" % day)
        return 1

    watch_mod.sync_reads_from_notes(conn, cfg)
    stats = {
        "day": day,
        "today_fetched": db.count_items_for_day(conn, day),
        "today_read": db.count_reads(conn, day),
        "total_read": db.count_reads(conn),
        "total_watches": int(
            conn.execute("SELECT COUNT(*) AS n FROM watches").fetchone()["n"] or 0
        ),
    }
    text = path.read_text(encoding="utf-8")
    updated = render.update_stats_block(text, stats)
    if updated != text:
        path.write_text(updated, encoding="utf-8")
    log(
        "统计（%s）：今日已读 %d，累计已读 %d，累计追踪 %d"
        % (
            day,
            stats["today_read"],
            stats["total_read"],
            stats["total_watches"],
        )
    )
    return 0


def cmd_digest(cfg: Config, conn, force: bool = False) -> None:
    now = datetime.now().astimezone()
    day = now.strftime("%Y-%m-%d")

    if not force and db.get_digest(conn, day):
        log("今天（%s）的日报已经生成过了，跳过" % day)
        return

    if force:
        db.clear_digest(conn, day)

    session = build_session(cfg.http)
    translator = Translator(cfg.section("translate"), conn, session)
    ai = AI(cfg.ai, conn, session)
    groups = watch_mod.recent_updates(conn)
    watch_mod.sync_reads_from_notes(conn, cfg)

    path = render.write_digest(
        conn, cfg, now, translator=translator, day=day, watch_groups=groups, ai=ai,
        session=session,
    )
    if path is None:
        log("没有新条目，今天先不出报")
        return
    if translator.calls:
        log("翻译 %d 条" % translator.calls)
    if ai.calls:
        log("AI 解读 %d 条" % ai.calls)
    if ai.error:
        log("AI 出错（已跳过）：%s" % ai.error)
    log("日报已写入：%s" % path)


def cmd_ai_test(cfg: Config, conn) -> int:
    session = build_session(cfg.http)
    ai = AI(cfg.ai, conn, session)
    if not ai.api_key:
        log("还没配置 API Key（config.yaml 的 ai.api_key）")
        return 1
    ok, message = ai.test()
    log("AI %s：%s" % ("可用" if ok else "不可用", message))
    return 0 if ok else 1


def cmd_ai_one(cfg: Config, conn, item_id: int) -> int:
    """插件点击「AI 解读」时调用，只输出一行 JSON。"""
    import json as _json

    row = db.get_item(conn, item_id)
    if row is None:
        print(_json.dumps({"ok": False, "error": "item not found"}, ensure_ascii=False))
        return 1

    session = build_session(cfg.http)
    ai = AI(cfg.ai, conn, session)
    ai.max_items = 10 ** 6  # 用户主动点的不受条数限制

    translator = Translator(cfg.section("translate"), conn, session)
    title = row["title"]
    summary = row["summary"] or ""

    from tracker.enrich import cache_key as _ck

    cached = db.get_enrich(conn, _ck(row["title"]))
    if cached is not None:
        ai.context = cached["summary"] or ""

    if row["region"] == "intl":
        zh, zs, _ = translator.display(title, summary, row["lang"] or "")
        title = zh or title
        summary = zs or summary

    text = ai.interpret(title, summary, force=True)
    print(
        _json.dumps(
            {"ok": bool(text), "text": text, "error": ai.error}, ensure_ascii=False
        )
    )
    return 0 if text else 1


def cmd_ai_chat(cfg: Config, conn, item_id: int, messages_json: str) -> int:
    """围绕一条新闻继续对话，输出一行 JSON。"""
    import json as _json

    row = db.get_item(conn, item_id)
    if row is None:
        print(_json.dumps({"ok": False, "error": "item not found"}, ensure_ascii=False))
        return 1
    try:
        messages = _json.loads(messages_json)
    except ValueError as exc:
        print(_json.dumps({"ok": False, "error": "messages JSON 解析失败：%s" % exc}, ensure_ascii=False))
        return 1
    if not isinstance(messages, list):
        print(_json.dumps({"ok": False, "error": "messages 必须是数组"}, ensure_ascii=False))
        return 1

    session = build_session(cfg.http)
    ai = AI(cfg.ai, conn, session)
    ai.max_items = 10 ** 6
    translator = Translator(cfg.section("translate"), conn, session)

    title = row["title"]
    summary = row["summary"] or ""
    if row["region"] == "intl":
        zh, zs, _ = translator.display(title, summary, row["lang"] or "")
        title = zh or title
        summary = zs or summary

    text = ai.chat(
        title,
        summary,
        _item_context(conn, row),
        messages,
        insight=ai.cached(title),
    )
    print(
        _json.dumps(
            {
                "ok": bool(text),
                "text": text,
                "error": ai.error,
                "item": {
                    "id": int(row["id"]),
                    "title": title,
                    "url": row["url"],
                    "source": row["source"],
                },
            },
            ensure_ascii=False,
        )
    )
    return 0 if text else 1


def _item_context(conn, row) -> str:
    from tracker.enrich import cache_key as _ck

    cached = db.get_enrich(conn, _ck(row["title"]))
    return (cached["summary"] if cached else "") or ""


def cmd_ai_all(cfg: Config, conn, day: str = None) -> int:
    """给某份日报里所有还没解读的新闻批量生成 AI 解读，逐行输出 JSON。"""
    import json as _json

    now = datetime.now().astimezone()
    day = day or now.strftime("%Y-%m-%d")
    rows = conn.execute(
        """
        SELECT DISTINCT i.id, i.title, i.summary, i.region, i.lang, i.url, i.source
        FROM digest_seen d
        JOIN items i ON i.id = d.item_id
        WHERE d.date = ?
        ORDER BY i.id
        """,
        (day,),
    ).fetchall()
    if not rows:
        print(_json.dumps({"ok": False, "error": "这一天没有日报条目"}, ensure_ascii=False))
        return 1

    # 按日报里的实际显示顺序从前往后解读
    order: list = []
    report = cfg.digest_dir / ("%s.md" % day)
    if report.exists():
        try:
            text = report.read_text(encoding="utf-8")
            for match in re.finditer(r"<!-- t:(\d+) -->", text):
                order.append(int(match.group(1)))
        except OSError:
            order = []
    if order:
        rank = {item_id: index for index, item_id in enumerate(order)}
        rows = sorted(
            rows,
            key=lambda row: rank.get(int(row["id"]), len(rank) + int(row["id"])),
        )

    def one(row) -> dict:
        worker = db.connect(cfg.db_path)
        try:
            session = build_session(cfg.http)
            ai = AI(cfg.ai, worker, session)
            ai.max_items = 10 ** 6
            translator = Translator(cfg.section("translate"), worker, session)
            title = row["title"]
            summary = row["summary"] or ""
            ai.context = _item_context(worker, row)
            if row["region"] == "intl":
                zh, zs, _ = translator.display(title, summary, row["lang"] or "")
                title = zh or title
                summary = zs or summary
            text = ai.interpret(title, summary, force=True)
            return {
                "item_id": int(row["id"]),
                "title": title,
                "ok": bool(text),
                "text": text,
                "error": ai.error,
            }
        except Exception as exc:
            return {
                "item_id": int(row["id"]),
                "title": row["title"],
                "ok": False,
                "text": "",
                "error": str(exc),
            }
        finally:
            worker.close()

    from concurrent.futures import ThreadPoolExecutor

    with ThreadPoolExecutor(max_workers=3) as pool:
        for result in pool.map(one, rows):
            print(_json.dumps(result, ensure_ascii=False), flush=True)
    return 0


def cmd_judge(cfg: Config, conn, item_id: int, note: str = "") -> int:
    """给一条新闻起草判断卡，只输出一行 JSON，插件拿去给用户编辑。"""
    import json as _json

    row = db.get_item(conn, item_id)
    if row is None:
        print(_json.dumps({"ok": False, "error": "item not found"}, ensure_ascii=False))
        return 1

    session = build_session(cfg.http)
    ai = AI(cfg.ai, conn, session)
    ai.max_items = 10 ** 6

    extra = "来源：%s\n地区：%s\n%s" % (
        row["source"],
        row["region"],
        ("用户补充：%s" % note) if note else "",
    )
    card = ai.draft_judgment(
        row["title"],
        row["summary"] or "",
        _item_context(conn, row),
        extra=extra,
    )
    print(
        _json.dumps(
            {
                "ok": bool(card.get("claim")),
                "item": {
                    "id": int(row["id"]),
                    "title": row["title"],
                    "url": row["url"],
                    "source": row["source"],
                    "region": row["region"],
                },
                "card": card,
                "error": ai.error,
            },
            ensure_ascii=False,
        )
    )
    return 0 if card else 1


def cmd_judge_save(
    cfg: Config,
    conn,
    item_id,
    judgment_id,
    data: str,
    reason: str = "",
) -> int:
    """保存用户确认后的判断卡；已有判断则版本 +1。"""
    import json as _json

    try:
        card = _json.loads(data)
    except ValueError as exc:
        print(_json.dumps({"ok": False, "error": "JSON 解析失败：%s" % exc}, ensure_ascii=False))
        return 1
    if not isinstance(card, dict) or not str(card.get("claim") or "").strip():
        print(_json.dumps({"ok": False, "error": "判断不能为空"}, ensure_ascii=False))
        return 1

    existing = None
    if judgment_id:
        existing = judgment.get_judgment(conn, int(judgment_id))
        if existing is None:
            print(_json.dumps({"ok": False, "error": "判断不存在"}, ensure_ascii=False))
            return 1
        item_id = int(existing["item_id"])
    elif item_id:
        existing = judgment.get_by_item(conn, int(item_id))
    else:
        print(_json.dumps({"ok": False, "error": "缺少 --item 或 --id"}, ensure_ascii=False))
        return 1

    item = db.get_item(conn, int(item_id))
    if item is None:
        print(_json.dumps({"ok": False, "error": "原文不存在"}, ensure_ascii=False))
        return 1

    watch = watch_mod.ensure_watch(conn, cfg, int(item_id))
    watch_id = int(watch["id"]) if watch is not None else None
    change_reason = reason or str(card.get("change_reason") or "")

    if existing is not None:
        judgment_id = int(existing["id"])
        version = judgment.update_judgment(
            conn,
            judgment_id,
            card,
            change_reason=change_reason or "复核后修订",
            trigger_item_id=int(item_id),
            status=str(card.get("status") or existing["status"] or "观察中"),
        )
        action = "updated"
    else:
        judgment_id = judgment.create_judgment(
            conn,
            int(item_id),
            card,
            watch_id=watch_id,
            change_reason=change_reason or "初始判断",
            status=str(card.get("status") or "观察中"),
        )
        version = 1
        action = "created"

    print(
        _json.dumps(
            {
                "ok": True,
                "action": action,
                "id": judgment_id,
                "version": version,
                "watch_id": watch_id,
            },
            ensure_ascii=False,
        )
    )
    return 0


def cmd_judge_review(cfg: Config, conn, judgment_id: int, note: str = "") -> int:
    """带着跟踪到的新事实复核判断，返回修订草案（不自动保存）。"""
    import json as _json

    row = judgment.get_judgment(conn, judgment_id)
    if row is None:
        print(_json.dumps({"ok": False, "error": "判断不存在"}, ensure_ascii=False))
        return 1
    item = db.get_item(conn, int(row["item_id"]))
    if item is None:
        print(_json.dumps({"ok": False, "error": "原文不存在"}, ensure_ascii=False))
        return 1

    facts = []
    since = row["updated_at"] or row["created_at"] or ""
    if row["watch_id"]:
        updates = conn.execute(
            """
            SELECT i.title, i.url, i.source, i.summary,
                   COALESCE(i.published_at, i.fetched_at) AS at
            FROM watch_updates u
            JOIN items i ON i.id = u.item_id
            WHERE u.watch_id = ? AND u.created_at >= ?
            ORDER BY at DESC
            LIMIT 8
            """,
            (int(row["watch_id"]), since),
        ).fetchall()
        for update in updates:
            facts.append(
                "- %s | %s | %s | %s"
                % (
                    (update["at"] or "")[:16],
                    update["source"],
                    update["title"],
                    (update["summary"] or "")[:300],
                )
            )
    if note:
        facts.append("- 用户补充：%s" % note)

    session = build_session(cfg.http)
    ai = AI(cfg.ai, conn, session)
    ai.max_items = 10 ** 6
    current = judgment.card_of(row)
    revised = ai.review_judgment(
        current,
        item["title"],
        "\n".join(facts) if facts else "（暂无新增事实，请评估当前判断是否仍然成立。）",
    )
    print(
        _json.dumps(
            {
                "ok": bool(revised.get("claim")),
                "id": int(judgment_id),
                "item_id": int(row["item_id"]),
                "current": current,
                "card": revised,
                "new_facts": facts,
                "error": ai.error,
            },
            ensure_ascii=False,
        )
    )
    return 0 if revised else 1


def cmd_judge_list(cfg: Config, conn, as_json: bool = False) -> int:
    import json as _json

    items = judgment.status_list(conn, limit=100)
    if as_json:
        print(_json.dumps(items, ensure_ascii=False))
        return 0
    if not items:
        log("还没有判断卡")
        return 0
    for item in items:
        log(
            "#%d v%d · %d%% · %s · %s"
            % (
                item["id"],
                item["version"],
                item["confidence"],
                item["status"],
                item["claim"][:70],
            )
        )
    return 0


def cmd_run(cfg: Config, conn) -> None:
    log("=== 开始 ===")
    cmd_fetch(cfg, conn)
    cmd_process(cfg, conn)
    cmd_watch(cfg, conn)

    now = datetime.now().astimezone()
    day = now.strftime("%Y-%m-%d")
    if db.get_digest(conn, day):
        log("今天的日报已存在，本次只入库（晚上那次就是这样）")
    elif now.hour < cfg.digest_hour:
        log("还没到 %d 点，先只入库" % cfg.digest_hour)
    else:
        cmd_digest(cfg, conn)
    log("=== 结束 ===")


def cmd_watch_flags(cfg: Config, conn, watch_id: int, forward, backward) -> int:
    db.set_watch_flags(conn, watch_id, forward=forward, backward=backward)
    log("已更新跟踪设置：向前=%s 向后=%s" % (
        "开" if forward in (None, 1) else "关",
        "开" if backward in (None, 1) else "关",
    ))
    return 0


def cmd_research(cfg: Config, conn, watch_id: int, deep: bool) -> int:
    session = build_session(cfg.http)
    ai = AI(cfg.ai, conn, session)
    count = watch_mod.research_watch(conn, cfg, watch_id, ai=ai, deep=deep)
    log("重新搜索完成%s，新增 %d 条" % ("（已扩大范围）" if deep else "", count))
    return 0


def cmd_add(cfg: Config, conn, url: str, title: str, watch_id) -> int:
    session = build_session(cfg.http)
    ai = AI(cfg.ai, conn, session)
    result = watch_mod.add_custom(conn, cfg, session, ai, url, title=title, watch_id=watch_id)
    if result is None:
        log("添加失败，检查链接")
        return 1
    log("已添加，跟踪编号 %d" % result)
    return 0


def cmd_toggle_feed(cfg: Config, conn, url: str, enabled: int) -> int:
    import json

    path = cfg.root / "data" / "overrides.json"
    data = {}
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except ValueError:
            data = {}
    rss = data.setdefault("sources", {}).setdefault("rss", {})
    disabled = set(rss.get("disabled") or [])
    if enabled:
        disabled.discard(url)
    else:
        disabled.add(url)
    rss["disabled"] = sorted(disabled)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    log("订阅源已%s：%s" % ("开启" if enabled else "关闭", url))
    return 0


def cmd_status(cfg: Config, conn) -> None:
    total = db.count_items(conn)
    recent = db.count_items(
        conn, (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat(timespec="seconds")
    )
    last = conn.execute("SELECT * FROM digests ORDER BY date DESC LIMIT 1").fetchone()
    watches = db.list_watches(conn, active_only=True)

    log("vault：%s" % cfg.digest_dir)
    log("数据库：%s" % cfg.db_path)
    log("条目总数 %d，近 24 小时 %d" % (total, recent))
    log("跟踪中 %d 条" % len(watches))
    if last:
        log("最近一份日报：%s（%d 条 / %d 组）" % (last["date"], last["item_count"], last["cluster_count"]))
    else:
        log("还没生成过日报")

    top = conn.execute(
        "SELECT title, score, source_count, region FROM clusters ORDER BY score DESC LIMIT 5"
    ).fetchall()
    if top:
        log("当前分数最高的 5 组：")
        for row in top:
            log("  %.1f  [%s] %s (%d 源)" % (row["score"], row["region"], row["title"][:50], row["source_count"]))


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="信息跟踪：抓取 -> 聚类 -> Obsidian 日报")
    parser.add_argument("--config", help="配置文件路径", default=None)
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("run", help="抓取 + 处理 + 跟踪 + 按需出日报")
    sub.add_parser("fetch", help="只抓取")
    sub.add_parser("process", help="只聚类打分")
    sub.add_parser("watch", help="只同步勾选并查找跟踪进展")
    digest_parser = sub.add_parser("digest", help="只出日报")
    digest_parser.add_argument("--force", action="store_true", help="忽略今天已存在的日报")
    stats_parser = sub.add_parser("stats", help="刷新日报末尾的阅读统计")
    stats_parser.add_argument("--day", default="", help="YYYY-MM-DD，默认今天")
    sub.add_parser("ai-test", help="测试 AI 接口是否可用")
    ai_one_parser = sub.add_parser("ai-one", help="给单条新闻生成 AI 解读（JSON）")
    ai_one_parser.add_argument("--item", type=int, required=True)
    ai_all_parser = sub.add_parser("ai-all", help="批量生成一份日报的 AI 解读（JSON 行）")
    ai_all_parser.add_argument("--day", default="", help="YYYY-MM-DD，默认今天")
    chat_parser = sub.add_parser("ai-chat", help="围绕一条新闻继续对话（JSON）")
    chat_parser.add_argument("--item", type=int, required=True)
    chat_parser.add_argument("--messages", required=True, help="[{role, content}] JSON")
    judge_parser = sub.add_parser("judge", help="给单条新闻起草判断卡（JSON）")
    judge_parser.add_argument("--item", type=int, required=True)
    judge_parser.add_argument("--note", default="", help="用户补充材料")
    judge_save_parser = sub.add_parser("judge-save", help="保存/修订判断卡")
    judge_save_parser.add_argument("--item", type=int, default=None)
    judge_save_parser.add_argument("--id", type=int, default=None)
    judge_save_parser.add_argument("--data", required=True, help="判断卡 JSON")
    judge_save_parser.add_argument("--reason", default="", help="版本变更原因")
    judge_review_parser = sub.add_parser("judge-review", help="带新事实复核判断（JSON）")
    judge_review_parser.add_argument("--id", type=int, required=True)
    judge_review_parser.add_argument("--note", default="", help="用户补充的新事实")
    judge_list_parser = sub.add_parser("judge-list", help="列出判断卡")
    judge_list_parser.add_argument("--json", action="store_true")
    flags_parser = sub.add_parser("watch-flags", help="设置向前/向后跟踪开关")
    flags_parser.add_argument("--watch", type=int, required=True)
    flags_parser.add_argument("--forward", type=int, choices=[0, 1])
    flags_parser.add_argument("--backward", type=int, choices=[0, 1])
    stop_parser = sub.add_parser("watch-stop", help="停止一个跟踪话题")
    stop_parser.add_argument("--watch", type=int, required=True)
    start_parser = sub.add_parser("watch-start", help="重新开始一个跟踪话题")
    start_parser.add_argument("--watch", type=int, required=True)
    sort_parser = sub.add_parser("watch-sort", help="切换跟踪时间线排序")
    sort_parser.add_argument("--watch", type=int, required=True)
    sort_parser.add_argument("--order", choices=["newest", "oldest"], default="newest")
    research_parser = sub.add_parser("research", help="重新搜索一个跟踪话题")
    research_parser.add_argument("--watch", type=int, required=True)
    research_parser.add_argument("--deep", action="store_true", help="扩大搜索范围")
    add_parser = sub.add_parser("add", help="自定义添加一个链接")
    add_parser.add_argument("--url", required=True)
    add_parser.add_argument("--title", default="")
    add_parser.add_argument("--watch", type=int, default=None)
    feed_parser = sub.add_parser("toggle-feed", help="开关单个 RSS 订阅")
    feed_parser.add_argument("--url", required=True)
    feed_parser.add_argument("--on", type=int, choices=[0, 1], required=True)
    sub.add_parser("status", help="查看状态")

    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        return 1

    try:
        cfg = load(args.config)
        conn = db.connect(cfg.db_path)
    except Exception as exc:
        log("启动失败：%s" % exc)
        return 2

    try:
        if args.command == "run":
            cmd_run(cfg, conn)
        elif args.command == "fetch":
            cmd_fetch(cfg, conn)
        elif args.command == "process":
            cmd_process(cfg, conn)
        elif args.command == "watch":
            cmd_watch(cfg, conn)
        elif args.command == "digest":
            cmd_digest(cfg, conn, force=args.force)
        elif args.command == "stats":
            cmd_stats(cfg, conn, args.day or None)
        elif args.command == "ai-test":
            return cmd_ai_test(cfg, conn)
        elif args.command == "ai-one":
            return cmd_ai_one(cfg, conn, args.item)
        elif args.command == "ai-all":
            cmd_ai_all(cfg, conn, args.day or None)
        elif args.command == "ai-chat":
            return cmd_ai_chat(cfg, conn, args.item, args.messages)
        elif args.command == "judge":
            return cmd_judge(cfg, conn, args.item, args.note)
        elif args.command == "judge-save":
            code = cmd_judge_save(
                cfg, conn, args.item, args.id, args.data, args.reason
            )
            try:
                write_status(cfg, conn)
            except Exception:
                traceback.print_exc()
            return code
        elif args.command == "judge-review":
            return cmd_judge_review(cfg, conn, args.id, args.note)
        elif args.command == "judge-list":
            return cmd_judge_list(cfg, conn, args.json)
        elif args.command == "watch-flags":
            return cmd_watch_flags(cfg, conn, args.watch, args.forward, args.backward)
        elif args.command == "watch-stop":
            return cmd_watch_stop(cfg, conn, args.watch)
        elif args.command == "watch-start":
            return cmd_watch_start(cfg, conn, args.watch)
        elif args.command == "watch-sort":
            return cmd_watch_sort(cfg, conn, args.watch, args.order)
        elif args.command == "research":
            return cmd_research(cfg, conn, args.watch, args.deep)
        elif args.command == "add":
            return cmd_add(cfg, conn, args.url, args.title, args.watch)
        elif args.command == "toggle-feed":
            return cmd_toggle_feed(cfg, conn, args.url, args.on)
        elif args.command == "status":
            cmd_status(cfg, conn)

        try:
            write_status(cfg, conn)
        except Exception:
            traceback.print_exc()
    except Exception:
        traceback.print_exc()
        return 3
    finally:
        conn.close()

    return 0


if __name__ == "__main__":
    sys.exit(main())
