#!/bin/bash
# 双击这个文件即可安装/修复朝闻天下本地环境。
# 如果 macOS 提示无法打开，右键 → 打开。
set -euo pipefail
cd "$(dirname "$0")"
exec ./scripts/setup.sh "$@"
