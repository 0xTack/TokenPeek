"""跟踪。

用户在日报里勾选「- [ ] 跟踪这条」，下一次运行时会：

1. 扫描最近几天的日报，把勾选的条目登记成 watch；
2. 在之后抓到的内容里找同一件事的后续报道（标题相似 / 链接相同 / 关键词覆盖）；
3. 把新进展按「链条」写进 `信息跟踪/跟踪/<标题>.md`，并在日报里汇总；
4. 写一份 `data/alerts.json`，Obsidian 插件轮询它来弹提醒。

链条用 Obsidian 的块引用串起来：每条进展带 ^uN，下一条写明「接 ^u(N-1)」，
在阅读视图里可以点着往回跳。
"""

from __future__ import annotations

import json
import re
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from . import db
from .util import (
    canonical_url,
    detect_lang,
    iso_now,
    jaccard,
    normalize_title,
    slug,
    strip_html,
    to_iso,
    tokens,
    url_hash,
)

MARK_RE = re.compile(r"- \[([ xX])\][^\n]*?<!--\s*t:(\d+)\s*-->")
READ_RE = re.compile(r"- \[([ xX])\][^\n]*?<!--\s*r:(\d+)\s*-->")
LOOKBACK_DAYS = 14


def _note_path(cfg, conn, item_id: int, title: str) -> str:
    folder = Path(cfg.watch_dir)
    base = slug(title) or ("item-%d" % item_id)
    path = folder / ("%s.md" % base)
    taken = {
        row["note_path"]
        for row in conn.execute("SELECT note_path FROM watches WHERE item_id <> ?", (item_id,))
    }
    if str(path) in taken:
        path = folder / ("%s-%d.md" % (base, item_id))
    return str(path)


def _vault_link(cfg, path: Path) -> str:
    try:
        return str(path.relative_to(cfg.vault_dir).with_suffix(""))
    except ValueError:
        return path.stem


def sync_from_notes(conn, cfg, ai=None) -> Tuple[int, int]:
    """把日报里勾选的条目变成 watch；取消勾选则停跟。返回（新增，取消）。"""
    folder = Path(cfg.digest_dir)
    if not folder.exists():
        return 0, 0

    files = sorted(folder.glob("*.md"))[-LOOKBACK_DAYS:]
    added = 0
    removed = 0

    for path in files:
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            continue
        for match in MARK_RE.finditer(text):
            checked = match.group(1).lower() == "x"
            item_id = int(match.group(2))
            item = db.get_item(conn, item_id)
            if item is None:
                continue
            watch = db.get_watch_by_item(conn, item_id)

            if checked:
                if watch is None:
                    note_path = _note_path(cfg, conn, item_id, item["title"])
                    db.add_watch(
                        conn,
                        item_id,
                        item["title"],
                        item["url"],
                        sorted(tokens(item["title"])),
                        item["region"],
                        note_path,
                    )
                    added += 1
                    watch = db.get_watch_by_item(conn, item_id)
                    if watch is not None:
                        build_history(conn, cfg, watch, ai)
                        _rewrite_note(conn, cfg, watch)
                elif not watch["active"]:
                    db.set_watch_active(conn, item_id, True)
                    fresh = db.get_watch_by_item(conn, item_id)
                    if fresh is not None:
                        _rewrite_note(conn, cfg, fresh)
                    added += 1
            elif watch is not None and watch["active"]:
                db.set_watch_active(conn, item_id, False)
                fresh = db.get_watch_by_item(conn, item_id)
                if fresh is not None:
                    _rewrite_note(conn, cfg, fresh)
                removed += 1

    return added, removed


ACTIVE_RE = re.compile(r"^active:\s*([01])\s*$", re.M)
ITEM_ID_RE = re.compile(r"^item_id:\s*(\d+)\s*$", re.M)


def sync_from_watch_notes(conn, cfg) -> int:
    """把跟踪笔记里的 active 状态同步回数据库。

    手机端没有 Python，插件的「停止追踪 / 重新追踪」只能直接改笔记。
    桌面端下一次运行时用它把数据库对齐，避免被旧的 active 覆盖。
    顺便给旧笔记补上 item_id，插件改日报勾选时要用。
    返回状态发生变化的条数。
    """
    changed = 0
    for watch in db.list_watches(conn, active_only=False):
        path = Path(watch["note_path"])
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            continue
        match = ACTIVE_RE.search(text)
        if match is None:
            continue

        if ITEM_ID_RE.search(text) is None:
            try:
                text = ACTIVE_RE.sub(
                    "item_id: %d\nactive: %s"
                    % (int(watch["item_id"]), match.group(1)),
                    text,
                    count=1,
                )
                path.write_text(text, encoding="utf-8")
            except OSError:
                pass

        active = int(match.group(1))
        if active != int(watch["active"] or 0):
            db.set_watch_active(conn, int(watch["item_id"]), bool(active))
            changed += 1
    return changed


def sync_digest_marks(conn, cfg) -> int:
    """让日报里的「跟踪」勾选和跟踪状态保持一致。

    手机端改跟踪笔记后，日报勾选可能还是旧状态；不统一的话下次运行
    会把它当成「重新勾选」或「取消勾选」，来回覆盖。返回改动的文件数。
    """
    folder = Path(cfg.digest_dir)
    if not folder.exists():
        return 0

    states = {
        int(watch["item_id"]): bool(int(watch["active"] or 0))
        for watch in db.list_watches(conn, active_only=False)
    }
    if not states:
        return 0

    def replace(match: "re.Match[str]") -> str:
        item_id = int(match.group(2))
        if item_id not in states:
            return match.group(0)
        box = "- [x]" if states[item_id] else "- [ ]"
        return re.sub(r"- \[[ xX]\]", box, match.group(0), count=1)

    changed = 0
    for path in sorted(folder.glob("*.md"))[-LOOKBACK_DAYS:]:
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            continue
        updated = MARK_RE.sub(replace, text)
        if updated != text:
            try:
                path.write_text(updated, encoding="utf-8")
            except OSError:
                continue
            changed += 1
    return changed


def sync_reads_from_notes(conn, cfg) -> int:
    """把日报里的「已读」勾选同步到 read_items；返回最近状态里已读的条数。"""
    folder = Path(cfg.digest_dir)
    if not folder.exists():
        return 0

    latest: Dict[int, Tuple[str, bool]] = {}
    for path in sorted(folder.glob("*.md"))[-LOOKBACK_DAYS:]:
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            continue
        date = path.stem
        for match in READ_RE.finditer(text):
            item_id = int(match.group(2))
            checked = match.group(1).lower() == "x"
            previous = latest.get(item_id)
            if previous is None or date >= previous[0]:
                latest[item_id] = (date, checked)

    for item_id, (date, checked) in latest.items():
        if checked:
            db.mark_read(conn, item_id, digest_date=date)
        else:
            db.unmark_read(conn, item_id)
    return sum(1 for _, checked in latest.values() if checked)


def stop_watch(conn, cfg, watch_id: int):
    """停止一个跟踪话题，并把笔记状态改掉。"""
    row = db.get_watch(conn, watch_id)
    if row is None:
        return None
    db.set_watch_active(conn, int(row["item_id"]), False)
    updated = db.get_watch(conn, watch_id)
    if updated is not None:
        _rewrite_note(conn, cfg, updated)
    return updated


def resume_watch(conn, cfg, watch_id: int):
    """重新开始一个已停止的跟踪话题。"""
    row = db.get_watch(conn, watch_id)
    if row is None:
        return None
    db.set_watch_active(conn, int(row["item_id"]), True)
    updated = db.get_watch(conn, watch_id)
    if updated is not None:
        _rewrite_note(conn, cfg, updated)
    return updated


def ensure_watch(conn, cfg, item_id: int, ai=None):
    """确保某条新闻处于跟踪状态；形成判断时自动调用。"""
    item = db.get_item(conn, item_id)
    if item is None:
        return None

    watch = db.get_watch_by_item(conn, item_id)
    if watch is None:
        note_path = _note_path(cfg, conn, item_id, item["title"])
        db.add_watch(
            conn,
            item_id,
            item["title"],
            item["url"],
            sorted(tokens(item["title"])),
            item["region"] or "cn",
            note_path,
        )
        watch = db.get_watch_by_item(conn, item_id)
        if watch is not None:
            # 形成判断时先把库内历史接上，但不为了历史摘要额外调 AI
            build_history(conn, cfg, watch, ai=None)
            _rewrite_note(conn, cfg, watch)
    elif not watch["active"]:
        db.set_watch_active(conn, item_id, True)
        _rewrite_note(conn, cfg, watch)
        watch = db.get_watch_by_item(conn, item_id)

    return watch


def _cmp_key(title: str) -> str:
    """比较标题用：去掉所有空白，避免《》标点把同一个标题拆成两串。"""
    return re.sub(r"\s+", "", normalize_title(title))[:60]


def _same_title(a: str, b: str) -> bool:
    if a == b:
        return True
    return len(a) >= 6 and len(b) >= 6 and (a in b or b in a)


def build_history(conn, cfg, watch, ai=None) -> int:
    """回溯库内同类报道，形成「历史脉络」，每条尽量配一句 AI 摘要。"""
    settings = cfg.section("history")
    if not settings.get("enabled", True):
        return 0
    if not int(watch["backward"] if "backward" in watch.keys() else 1):
        return 0

    deep = int(watch["deep"] or 0) if "deep" in watch.keys() else 0
    base_entries = int(settings.get("max_entries", 10))
    base_threshold = float(settings.get("min_similarity", 0.42))
    max_entries = base_entries * (3 if deep else 1)
    threshold = max(0.18, base_threshold - (0.14 if deep else 0))
    try:
        watch_tokens = json.loads(watch["tokens"] or "[]")
    except ValueError:
        watch_tokens = sorted(tokens(watch["title"]))

    original = db.get_item(conn, watch["item_id"])
    rows = conn.execute(
        """
        SELECT id, title, url, source, summary, region, fetched_at,
               published_at, cluster_id
        FROM items
        ORDER BY COALESCE(published_at, fetched_at) ASC
        """
    ).fetchall()

    picked = []
    seen = set()
    for row in rows:
        if row["id"] == watch["item_id"]:
            continue
        if original and original["cluster_id"] and row["cluster_id"] == original["cluster_id"]:
            continue
        if _match_score(watch_tokens, watch["title"], row) < threshold:
            continue
        key = _cmp_key(row["title"])
        if any(_same_title(key, seen_key) for seen_key in seen):
            continue
        seen.add(key)
        picked.append(row)

    # 太多就保留最早的几条 + 最近的几条
    if len(picked) > max_entries:
        picked = picked[:3] + picked[-(max_entries - 3):]

    count = 0
    for row in picked:
        ai_text = ""
        if ai is not None and ai.available() and settings.get("ai_summaries", True):
            lead = strip_html(row["summary"] or "", 1200)
            ai_text = ai.summarize(row["title"], lead)
        db.add_watch_history(conn, watch["id"], row["id"], ai_text)
        count += 1
    return count


def _match_score(watch_tokens: List[str], watch_title: str, item) -> float:
    item_tokens = tokens(item["title"])
    if not item_tokens:
        return 0.0

    score = jaccard(set(watch_tokens), item_tokens)
    if watch_tokens and len(item_tokens) >= 3:
        inter = len(set(watch_tokens) & item_tokens)
        if inter:
            score = max(score, inter / float(min(len(watch_tokens), len(item_tokens))) * 0.85)

    a = normalize_title(watch_title)
    b = normalize_title(item["title"])
    if len(a) >= 4 and (a in b or b in a):
        score = max(score, 0.8)
    return score


def _read_order(path: Path) -> str:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return "newest"
    match = re.search(r"^order:\s*(newest|oldest)\s*$", text, re.M)
    return match.group(1) if match else "newest"


def _rewrite_note(conn, cfg, watch, order: str = "") -> None:
    """把「历史脉络 + 开始跟踪 + 后续进展」重写成一条时间线。"""
    note_path = Path(watch["note_path"])
    if order not in ("newest", "oldest"):
        order = _read_order(note_path)
    history = db.list_watch_history(conn, watch["id"])
    updates = conn.execute(
        """
        SELECT u.item_id, u.created_at, i.title, i.url, i.source,
               COALESCE(i.published_at, i.fetched_at) AS at
        FROM watch_updates u
        JOIN items i ON i.id = u.item_id
        WHERE u.watch_id = ?
        ORDER BY at
        """,
        (watch["id"],),
    ).fetchall()

    original = db.get_item(conn, watch["item_id"])
    events = []

    for row in history:
        events.append(
            {
                "at": row["at"],
                "title": row["title"],
                "url": row["url"],
                "source": row["source"],
                "ai": row["ai_text"] or "",
                "kind": "history",
            }
        )

    if original is not None:
        events.append(
            {
                "at": original["published_at"] or original["fetched_at"],
                "title": original["title"],
                "url": original["url"],
                "source": original["source"],
                "ai": "",
                "kind": "original",
            }
        )

    for row in updates:
        events.append(
            {
                "at": row["at"],
                "title": row["title"],
                "url": row["url"],
                "source": row["source"],
                "ai": "",
                "kind": "update",
            }
        )

    events.sort(key=lambda e: e["at"] or "")

    # 同一条新闻可能同时出现在历史、原文和进展里，按标题去重，保留最早的那次
    merged = {}
    for event in events:
        key = _cmp_key(event["title"])
        target = None
        for existing_key in merged:
            if _same_title(key, existing_key):
                target = existing_key
                break

        if target is None:
            merged[key] = event
            continue

        current = merged[target]
        if (event["at"] or "") < (current["at"] or ""):
            event["kind"] = current["kind"] if current["kind"] == "original" else event["kind"]
            if not event["ai"]:
                event["ai"] = current["ai"]
            merged[target] = event
        else:
            if not current["ai"]:
                current["ai"] = event["ai"]
            if event["kind"] == "original":
                current["kind"] = "original"

    events = sorted(
        merged.values(), key=lambda e: e["at"] or "", reverse=(order == "newest")
    )

    created = (watch["created_at"] or "")[:10]
    lines = [
        "---",
        "type: 跟踪",
        "cssclasses:",
        "  - it-reading-mode",
        "created: %s" % created,
        "source_url: %s" % watch["url"],
        "watch_id: %d" % int(watch["id"]),
        "item_id: %d" % int(watch["item_id"]),
        "active: %d" % (1 if int(watch["active"] or 0) else 0),
        "history: %d" % len(history),
        "updates: %d" % len(updates),
        "order: %s" % order,
        "---",
        "",
        "# %s" % watch["title"],
        "",
        "> [!meta]",
        ">",
    ]
    meta_parts = [
        "最早来源：%s" % (events[-1]["at"][:10] if events else "—"),
        "开始跟踪：%s" % created,
    ]
    if int(watch["active"] or 0):
        status_html = (
            '<span class="it-watch-status is-active">追踪中'
            '<span class="it-watch-menu">'
            '<a href="obsidian://info-tracker?cmd=watch-stop&watch=%d">停止追踪</a>'
            "</span></span>" % int(watch["id"])
        )
    else:
        status_html = (
            '<span class="it-watch-status">已停止追踪'
            '<span class="it-watch-menu">'
            '<a href="obsidian://info-tracker?cmd=watch-start&watch=%d">重新追踪</a>'
            "</span></span>" % int(watch["id"])
        )
    meta_parts.append(status_html)
    lines.append("> " + "　·　".join(meta_parts))

    if order == "newest":
        sort_links = (
            "**最近**　[最初](obsidian://info-tracker?cmd=watch-sort&watch=%d&order=oldest)"
            % int(watch["id"])
        )
    else:
        sort_links = (
            "[最近](obsidian://info-tracker?cmd=watch-sort&watch=%d&order=newest)　**最初**"
            % int(watch["id"])
        )
    lines += [
        "",
        "## 时间线",
        "",
        "> [!timeline]",
        ">",
        "> %s" % sort_links,
        ">",
    ]

    for event in events:
        when = datetime.fromisoformat(event["at"]).astimezone()
        lines.append(
            "> - **%s** · [%s](<%s>)"
            % (
                when.strftime("%Y-%m-%d"),
                event["title"],
                event["url"],
            )
        )
        if event["ai"]:
            lines.append(">   - 摘要：%s" % event["ai"].replace("\n", " "))

    if not events:
        lines.append("> _还没有可回溯的内容。_")

    lines.append("")
    path = Path(watch["note_path"])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def _notify(title: str, body: str) -> None:
    try:
        script = 'display notification "%s" with title "%s"' % (
            body.replace('"', "'"),
            title.replace('"', "'"),
        )
        subprocess.run(["osascript", "-e", script], check=False, timeout=10)
    except Exception:
        pass


def _write_alerts(cfg, alerts: List[Dict]) -> None:
    path = Path(cfg.root) / "data" / "alerts.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "updated_at": iso_now(),
        "unread": len(alerts),
        "items": alerts,
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def update_watches(conn, cfg, now: Optional[datetime] = None, ai=None) -> int:
    """给所有 active watch 找后续报道，写笔记 + 提醒。返回新增进展条数。"""
    now = now or datetime.now(timezone.utc)
    watches = db.list_watches(conn, active_only=True)
    if not watches:
        _write_alerts(cfg, [])
        return 0

    since = (now - timedelta(days=7)).isoformat(timespec="seconds")
    candidates = conn.execute(
        """
        SELECT id, title, url, source, region, fetched_at, published_at, cluster_id
        FROM items
        WHERE fetched_at >= ?
        ORDER BY fetched_at DESC
        """,
        (since,),
    ).fetchall()

    threshold = float(cfg.section("watch").get("min_similarity", 0.5))
    per_watch = int(cfg.section("watch").get("max_updates_per_watch", 5))

    alerts: List[Dict] = []
    total = 0

    for watch in watches:
        if "forward" in watch.keys() and not int(watch["forward"] or 0):
            continue
        built = 0
        if not db.has_watch_history(conn, watch["id"]):
            built = build_history(conn, cfg, watch, ai)

        try:
            watch_tokens = json.loads(watch["tokens"] or "[]")
        except ValueError:
            watch_tokens = sorted(tokens(watch["title"]))

        original = db.get_item(conn, watch["item_id"])
        original_cluster = original["cluster_id"] if original else None
        history_titles = {
            _cmp_key(row["title"])
            for row in db.list_watch_history(conn, watch["id"])
        }

        def is_known(title: str) -> bool:
            key = _cmp_key(title)
            return any(_same_title(key, known) for known in history_titles)

        matches = []
        for item in candidates:
            if item["id"] == watch["item_id"]:
                continue
            if original_cluster and item["cluster_id"] == original_cluster:
                continue
            if is_known(item["title"]):
                continue
            if db.seen_update(conn, watch["id"], item["id"]):
                continue
            if _match_score(watch_tokens, watch["title"], item) >= threshold:
                matches.append(item)

        if not matches:
            if built:
                _rewrite_note(conn, cfg, watch)
            continue

        matches = matches[:per_watch]
        for item in matches:
            db.add_watch_update(conn, watch["id"], item["id"])
            when = datetime.fromisoformat(item["published_at"] or item["fetched_at"])
            alerts.append(
                {
                    "watch_id": watch["id"],
                    "title": watch["title"],
                    "note": _vault_link(cfg, Path(watch["note_path"])),
                    "headline": item["title"],
                    "url": item["url"],
                    "source": item["source"],
                    "time": when.astimezone().isoformat(timespec="minutes"),
                }
            )

        _rewrite_note(conn, cfg, watch)
        db.touch_watch(conn, watch["id"])
        total += len(matches)

    _write_alerts(cfg, alerts)

    if alerts and bool(cfg.section("notify").get("desktop", True)):
        first = alerts[0]
        body = "%s（共 %d 条新进展）" % (first["headline"][:40], len(alerts))
        _notify("信息跟踪", body)

    return total


def _fetch_page(session, url, timeout=15):
    try:
        resp = session.get(url, timeout=timeout, allow_redirects=True)
        if resp.status_code != 200:
            return "", ""
        if not resp.encoding or resp.encoding.lower() in ("iso-8859-1", "latin-1"):
            resp.encoding = resp.apparent_encoding or "utf-8"
        html = resp.text
        match = re.search(r"<title[^>]*>(.*?)</title>", html, re.S | re.I)
        title = strip_html(match.group(1), 160) if match else ""
        try:
            import trafilatura

            text = trafilatura.extract(html) or ""
        except Exception:
            text = ""
        return title, text
    except Exception:
        return "", ""


def _insert_custom_item(conn, title, url, source, summary):
    now = iso_now()
    conn.execute(
        """
        INSERT OR IGNORE INTO items
            (url_hash, url, canonical, title, summary, author, source, kind,
             region, lang, published_at, fetched_at, metric, extra)
        VALUES (?, ?, ?, ?, ?, '', ?, 'custom', ?, ?, ?, ?, 0, '{}')
        """,
        (
            url_hash(url),
            url,
            canonical_url(url),
            title,
            summary,
            source,
            "intl" if detect_lang(title) != "zh" else "cn",
            detect_lang(title + summary),
            now,
            now,
        ),
    )
    conn.commit()
    row = conn.execute(
        "SELECT id FROM items WHERE url_hash = ?", (url_hash(url),)
    ).fetchone()
    return int(row["id"]) if row else None


def add_custom(conn, cfg, session, ai, url, title="", watch_id=None):
    """把用户自己找到的链接加进跟踪时间线，或新建一个跟踪话题。"""
    title = (title or "").strip()
    page_title, page_text = _fetch_page(session, url)
    title = title or page_title or url
    summary = page_text[:800]
    item_id = _insert_custom_item(conn, title, url, "自定义添加", summary)
    if item_id is None:
        return None

    if watch_id:
        watch = db.get_watch(conn, watch_id)
        if watch is not None:
            ai_text = ai.summarize(title, summary) if ai and ai.available() else ""
            db.add_watch_history(conn, watch_id, item_id, ai_text)
            _rewrite_note(conn, cfg, watch)
            return watch_id

    note_path = _note_path(cfg, conn, item_id, title)
    db.add_watch(conn, item_id, title, url, sorted(tokens(title)), detect_lang(title), note_path)
    watch = db.get_watch_by_item(conn, item_id)
    if watch is not None:
        build_history(conn, cfg, watch, ai)
        _rewrite_note(conn, cfg, watch)
        return int(watch["id"])
    return None


def research_watch(conn, cfg, watch_id, ai=None, deep=False):
    """重新搜索：按开关跑一遍向前/向后查找；deep=True 时扩大范围。"""
    watch = db.get_watch(conn, watch_id)
    if watch is None:
        return 0
    if deep:
        db.set_watch_flags(conn, watch_id, deep=1)
        watch = db.get_watch(conn, watch_id)

    count = 0
    if int(watch["backward"] or 0):
        count += build_history(conn, cfg, watch, ai)
    if int(watch["forward"] or 0):
        count += update_watches(conn, cfg, ai=ai)
    _rewrite_note(conn, cfg, watch)
    return count


def recent_updates(conn, hours: int = 26) -> List[Dict]:
    """日报用：最近新产生的跟踪进展，按 watch 聚合。"""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat(timespec="seconds")
    rows = conn.execute(
        """
        SELECT w.id, w.title, w.note_path,
               i.title AS item_title, i.url AS item_url, i.source AS item_source,
               u.created_at
        FROM watch_updates u
        JOIN watches w ON w.id = u.watch_id
        JOIN items i ON i.id = u.item_id
        WHERE u.created_at >= ?
        ORDER BY w.id, u.created_at DESC
        """,
        (cutoff,),
    ).fetchall()

    grouped: Dict[int, Dict] = {}
    for row in rows:
        key = row["id"]
        if key not in grouped:
            grouped[key] = {
                "title": row["title"],
                "note_path": row["note_path"],
                "updates": [],
            }
        grouped[key]["updates"].append(row)
    return list(grouped.values())
