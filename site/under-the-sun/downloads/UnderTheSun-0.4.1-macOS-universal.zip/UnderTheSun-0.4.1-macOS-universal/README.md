# Under the Sun（朝闻天下）

> 官网/介绍页：`docs/index.html`（可直接用 GitHub Pages 发布）

每天 07:00 抓取热搜和新闻 → 补全正文 → 去重聚类 → 打分排序 → 往 Obsidian vault 写一份「报纸」。
19:00 再抓一次，只入库不出报。

**国内 / 国外分开**，外文自动翻译；每条都能勾选「跟踪」，之后有新进展会自动补到跟踪笔记里。

再加一层 Obsidian 插件：一个主页，能开关来源、填 AI 接口、一键抓取，并弹出跟踪提醒。

不做常驻服务：定时任务 + 几个 Markdown 文件，Obsidian 只负责读和勾选。


## 平台支持

| 版本 | macOS | Windows | Linux | iOS / Android |
|---|---|---|---|---|
| 完整版（Python + 插件） | ✅ 一键安装、定时抓取 | ❌ 暂不支持 | ❌ 需手动运行 | 只读 + AI（数据由电脑同步） |
| 社区版（纯插件） | ✅ | ✅ | ✅ | ✅ |

完整版目前只提供 macOS 安装器和 launchd 定时任务。Windows / Linux 用户请使用社区版，或手动运行 Python 后端。

---

## 新用户一键安装（macOS）

不想手写命令，直接双击项目根目录的：

```text
install.command
```

它会自动：

1. 检查 Python 3.9+，创建 `.venv` 并安装依赖
2. 自动寻找或让你选择 Obsidian vault
3. 把插件、`main.js`、CSS 复制到 vault 并启用
4. 安装 07:00 / 19:00 的 launchd 定时任务
5. 初始化数据库和状态
6. 询问是否立刻抓取一次

如果 macOS 拦截，右键 `install.command` → **打开**。也可以在终端跑：

```bash
./install.command
```

可选参数：

```bash
./install.command --vault "/path/to/vault" --api-key "sk-..." --no-run
```

建议把项目放在 `~/code/info-tracker`，不要放 `~/Documents`、`~/Desktop`、`~/Downloads`，否则 launchd 可能因 macOS 权限静默失败。

---

## Obsidian 插件

插件已经装在 vault 里（`.obsidian/plugins/info-tracker/`）。**重启一次 Obsidian**，左侧栏会出现报纸图标 **朝闻天下**，点开就是主页：

- **今日状态**：日报有没有生成、库存多少条、跟踪多少条
- **判断簿**：已保存的判断卡、复核入口；新建判断从今日新闻里选一条起草
- **一键操作**：抓取并出报 / 只抓取 / 只重排日报 / 打开今日日报 / **停止**
- **选择来源**：国内、国外两组开关
- **AI 解读**：填 API、测试连接（填了 Key 自动启用）
- **跟踪提醒**：有新进展弹通知，状态栏显示条数
- **运行日志**：Python 的输出直接显示

「停止」按钮会在抓取/排版过程中杀掉 Python 子进程，不会留下半截数据。

插件只是壳：真正干活的是 Python。关掉 Obsidian，早上 7 点的日报照样生成。

## 手机端（同一个插件）

`info-tracker` 现在可以在手机 Obsidian 里加载，但手机端不跑 Python：

- 桌面端抓取后，会把一份快照写到 `<vault>/朝闻天下/.同步数据/mobile.json`
- 手机端读这份快照和日报，能看今日快照、判断簿、跟踪历史、提醒
- 手机端能 AI 解读、AI 交流，直接用 `requestUrl` 连 OpenAI 兼容接口
- API Key 和手机设置只存本机 localStorage，不写进随 vault 同步的 `data.json`
- 抓取、来源开关、Cookie、判断卡新建/复核仍然只在电脑端
- 跟踪笔记里的「停止追踪 / 重新追踪 / 时间线排序」可以直接在手机端点，插件会改笔记，电脑端下次 `watch` / `run` 自动对齐数据库
- 跟踪 / 已读可以在日报里直接勾选，电脑端下次 `watch` / `run` 同步

手机端读不到数据时，先在电脑端运行一次 `python main.py status`，或等 07:00 / 19:00 抓取后让 iCloud 同步。

## 正文补全（解决「只有标题」）

热搜条目经常只有一个标题，看完不知道发生了什么。现在每条都会尝试补全：

1. 源自带摘要（百度 desc、知乎 excerpt、腾讯 abstract、RSS summary）够长 → 直接用；
2. 链接是文章页 → 用 trafilatura 抽正文；
3. 还不行 → 拿标题去 Bing 新闻 RSS 搜一篇相关报道，取它的摘要；
4. 仍然没有 → **判定为「只有标题」，不进报纸**。

配置：

```yaml
content:
  require: true      # 补不到正文的直接丢弃
  min_chars: 40
  enrich_top: 24     # 每期最多补前 24 条
  fetch_article: true
```

报纸里每条长这样：

```markdown
> **发生了什么**：党的二十届五中全会于10月29日在京闭幕…
>
> [原文](...) · [相关报道](...)
```

标题那行下面还会多一行摘要，简讯也能一眼看懂大概。

插件设置页只放「规则」（过滤 + 跨天去重）。项目路径、Python 路径和状态栏开关在插件主页最下面的「高级设置」里，默认已经指向当前项目。

### 屏蔽规则

设置页里可以逐条添加、删除规则，每行左侧可以切换：标题包含、来源包含、链接包含、正则。默认已经带广告、招聘、带货等基础词。

需要直接改底层时，可以在 `data/overrides.json` 的 `filters.rules` 里写：

```json
{
  "filters": {
    "rules": [
      { "type": "keyword", "value": "广告" },
      { "type": "source",  "value": "抖音热榜" },
      { "type": "url",     "value": "example.com" },
      { "type": "regex",   "value": "^某话题" }
    ]
  }
}
```

`keyword` 看标题，`source` 看来源，`url` 看链接，`regex` 是正则。

## AI 解读

任何 OpenAI 兼容接口都能用（DeepSeek、Kimi、通义、Ollama、OpenAI）：

```yaml
ai:
  enabled: true
  base_url: "https://api.deepseek.com/v1"
  api_key: "sk-..."
  model: "deepseek-flash"
```

在插件主页填也行，会写到 `data/overrides.json`，不动 `config.yaml` 的注释。**填了 Key 保存会自动启用**，并立刻测一次连接。

**按需解读，不点不花钱**：日报里每条的链接后有一个 `[🤖 AI 解读]`，点一下才会调用模型，结果直接插到这条新闻下面。

**AI 交流**：日报里每条还有 `[AI 交流]`，主页头条也有 `💬 交流`。打开后可以围绕这条新闻继续追问，AI 会带着标题、摘要、正文和已有解读回答。对话记录同时保存到：

- `data/chats/<item>.json`（插件里重新打开可以继续）
- `朝闻天下/交流/<标题>.md`（Obsidian 里可读、可同步）

解读是**三段式**的，不是一句话摘要：

1. **事实**：到底发生了什么（只用材料里的信息）
2. **背景**：为什么会发生
3. **影响**：影响谁、接下来看什么

约 200–300 字，多段落。输入会带上补全后的正文，所以比只看标题准得多。

点击走的是 Obsidian URI（`obsidian://info-tracker?cmd=ai&item=123`），由插件调 Python 生成再写回笔记。

### 成本

按 DeepSeek 现价（输入约 ¥2/百万 token、输出约 ¥8/百万 token，命中缓存更便宜）估算。深度解读会带上正文，单条约 1200 输入 + 400 输出：

| 场景 | 单次 | 每天 | 每月 |
| --- | --- | --- | --- |
| 一条深度解读 | ≈ ¥0.006 | — | — |
| 点击 10 条 | — | ≈ ¥0.06 | ≈ ¥1.8 |
| 点击 30 条 | — | ≈ ¥0.18 | ≈ ¥5.4 |

翻译用的是免费接口，不额外花钱。结果按「模型 + 标题」缓存，同一篇点两次只扣一次。

## 判断卡

AI 解读是一次性的文字；判断卡是可检验、可版本化的记录。

在插件主页判断簿里点「从今日新闻新建判断」，选一条新闻，AI 会先起草一张卡：

- **判断**：不超过 60 字，有方向、有范围、有时间窗口
- **置信度**：0–100，并说明为什么不是更高或更低
- **什么算我对 / 什么算我错**：具体到可搜索的事件、指标、名单或表态
- **最强反方 / 未知**：防止只找支持自己的证据
- **信源质量**：低 / 中 / 高

你可以在弹窗里改完再保存。保存后会自动开始跟踪原新闻。以后点「复核判断」，系统会把跟踪到的新事实交给 AI，AI 只提出修订草案，你确认后版本 +1，旧版本全部保留。

判断提示词在 `prompts/judgment.md`。判断卡比普通解读长，模型 `max_tokens` 必须给到 4000。

## 报纸版式

热度分三档，字号跟着变：

| 档位 | 条数 | 样式 |
| --- | --- | --- |
| `headline` 头条 | 国内前 2、国外前 2 | 大标题、粗边框、大字号 |
| `feature` 要闻 | 国内 3–6、国外 3–5 | 中等字号 |
| `brief` 简讯 | 其余 | 小字号列表，只留标题、来源、分数、主题 |

用 Obsidian 的 callout 实现，样式来自 `.obsidian/snippets/info-tracker.css`（插件会自动安装并启用）。想改字号直接改这个文件。

## 历史新闻（回溯到最早来源）

勾选「跟踪」后，系统不只是往后追，还会**往回翻**：

1. 在库里按标题相似度找同类报道；
2. 按时间正序排，最早的一条标 `⏮ 最早来源`；
3. 每条都用 AI 写一句摘要（配置 `history.ai_summaries`）；
4. 原条目标 `📍 开始跟踪`，之后的进展继续往下加。

跟踪笔记因此变成一条完整时间线：

```markdown
## 时间线（从最早开始）

- ⏮ `2026-10-20 17:00` · [全会10月20日召开 主要议程公布](...) · 新华社 · [[朝闻天下/日报/2026-10-20|当日报纸]]
  - 🤖 全会定于10月20日在北京召开，主要议程已公布…
- `2026-10-29 20:00` · [公报发布 部署全面从严治党](...) · 澎湃新闻 …
- `2026-11-01 17:50` · [《决定》全文发布](...) · 头条热榜 … 📍 开始跟踪
- `2026-11-02 08:14` · [国办回应假期安排](...) · 澎湃新闻 …
```

插件主页新增「历史新闻（可回溯到最早来源）」卡片，列出每个跟踪话题的**最早一条**、历史条数和进展条数，点标题直接打开时间线。

配置：

```yaml
history:
  enabled: true
  max_entries: 10        # 最多回溯几条
  min_similarity: 0.42   # 比后续报道略宽松
  ai_summaries: true
```

限制：**只能回溯到库里已有的数据**（从开始运行那天起）。跑得越久，能回溯的历史越长；如果需要挖出建库之前的老报道，得再加一步按时间搜索 Bing/Google 新闻。

## 跟踪提醒

勾选某条后，下一次运行会：

1. 把它登记成跟踪项，建一个 `朝闻天下/跟踪/<标题>.md`；
2. 先回溯历史（见上一节），再在之后抓到的内容里找后续报道；
3. 把新进展追加到同一条时间线末尾；
4. 写 `data/alerts.json`，插件轮询到就弹 Obsidian 通知，同时发 macOS 系统通知。

日报顶部的「跟踪进展」也会汇总，每条都能点回当天的报纸。

---

## 日报长什么样

```
<vault>/朝闻天下/日报/2026-11-01.md
```

- **🔥 国内热搜**：百度热搜 + 头条热榜合并去重后的前 8 条
- **🌍 国外要闻**：BBC / Reddit / Google News，标题自动翻成中文，下面附原标题
- **🔔 跟踪进展**：你勾过的条目，当天发现的新报道
- **全部条目**：按国内/国外 + 主题分组，紧凑列表

每条后面或行首有复选框：

```markdown
- [ ] 跟踪这条 <!-- t:123 -->
- [ ] [标题](链接) · 百度热搜 · 714万热度 · 4.5 <!-- t:123 -->
```

**勾上 = 开始跟踪，取消勾选 = 不再跟踪。**

## 跟踪是怎么工作的

1. 你在日报里勾选某一条；
2. 下一次运行（每天 19:00 / 次日 07:00）扫描最近 14 天的日报，把勾选的条目登记成 watch；
3. 在之后抓到的内容里找同一件事的后续报道：标题相似度 + 关键词覆盖 + 相同链接；
4. 新进展追加到 `朝闻天下/跟踪/<标题>.md` 的时间线里，同时在日报顶部汇总。

跟踪笔记长这样：

```markdown
# 法定放假总数已增至13天

- 原始链接：...
- 开始跟踪：2026-11-01

## 进展

- 11-02 08:14 · [国务院办公厅回应假期安排](...) · 澎湃新闻
```

匹配阈值在 `config.yaml` 的 `watch.min_similarity`，调高更严格（少误报），调低更宽松（少漏）。

## 常用命令

```bash
cd ~/code/info-tracker

.venv/bin/python main.py run        # 完整流程（定时任务调的就是它）
.venv/bin/python main.py fetch      # 只抓取
.venv/bin/python main.py process    # 只重新聚类 + 打分
.venv/bin/python main.py watch      # 只同步勾选 + 找跟踪进展
.venv/bin/python main.py digest     # 只出日报
.venv/bin/python main.py digest --force   # 覆盖今天已生成的日报（不会丢勾选）
.venv/bin/python main.py ai-test    # 测试 AI 接口
.venv/bin/python main.py ai-chat --item <id> --messages '<json>'  # 围绕新闻多轮对话
.venv/bin/python main.py judge --item <id>          # AI 起草判断卡
.venv/bin/python main.py judge-review --id <id>     # 带新事实复核判断
.venv/bin/python main.py judge-list                 # 列出判断卡
.venv/bin/python main.py status     # 库里的情况
```

## 定时任务

```bash
./scripts/install_launchd.sh            # 安装（07:00 + 19:00）
./scripts/install_launchd.sh --run-now  # 安装并立刻跑一次
```

用 macOS `launchd` 的 `StartCalendarInterval`：**机器休眠错过时间点，唤醒后会自动补跑一次**。
晚上合盖、第二天开盖，日报就在了（前提是当前用户已登录）。

日志：`tail -f logs/run.log`

卸载：

```bash
launchctl bootout gui/$(id -u)/com.xa.infotracker
rm ~/Library/LaunchAgents/com.xa.infotracker.plist
```

## 排序怎么算

```
score = 3.0 * 平台热度(按源归一化) + 2.2 * log2(跨源数) + 1.5 * 新鲜度
```

刻意的设计：

- **单源不加分**（`log2(1)=0`）。否则每个源白送底分，日报里全是「只有它自己在说」的软文。
- **跨源合并是最高信号**：同一件事几家都在说，比单源高赞更能说明今天热。
- **每个来源有配额**，否则热搜会刷屏。
- **翻译不参与排序**，只改展示。
- 国内、国外各自排序，互不挤占。

## 数据源现状

| 源 | 状态 | 说明 |
| --- | --- | --- |
| 百度热搜 | ✅ | 页面内嵌 JSON，带热度值 |
| 头条热榜 | ✅ | 公开 JSON，带热度值 |
| 腾讯新闻 | ✅ | 公开热榜接口，带排名 |
| 知乎热榜 | ✅ | 移动端公开接口，免登录；带「万热度」 |
| 微博热搜 | ✅ | 有 Cookie 用官方接口（真实热度）；没有则走 RSS 镜像 |
| 小红书热点 | ⚠️ 走镜像 | 官方接口要登录 + 请求签名；默认用第三方 RSS 镜像 |
| B站热搜 | ✅ | 公开接口，带 heat_score |
| 抖音热榜 | ✅ | 公开接口，带 hot_value |
| 澎湃 / 新浪国内 | ✅ | RSS |
| BBC / Google News / Guardian / Al Jazeera / NYT / CNN / DW / NPR | ✅ | RSS，外文自动翻译 |
| Reddit | ✅ | 走 RSS（JSON 接口已 403），只有排名没有赞数 |
| HN / GitHub Trending | 默认关闭 | 技术向，`enabled: true` 可开 |

### 微博 / 知乎 / 小红书 Cookie 怎么填

不填也能用（走镜像），但只有排名没有热度值。想要真实热度：

1. 打开插件主页的「登录态」卡片，点「打开微博 / 知乎 / 小红书登录页」；
2. 登录成功后按 F12 → Network → 刷新页面；
3. 点任意一个请求，把 Request Headers 里的 `Cookie:` 整段复制；
4. 粘回主页对应输入框保存（也会写进 `data/overrides.json`）。

有效期：微博通常 7–30 天，知乎约 30 天，小红书约 7–14 天；平台也可能提前失效，主页会显示「已保存 N 天前」，抓不到数据时重新登录复制即可。用官方接口失败时会自动回退到镜像，不会中断。

### 小红书为什么是镜像

小红书的网页接口全部要求 `x-s` 请求签名，签名算法随前端代码变，自己实现一两天就失效。
所以默认用第三方 RSS 镜像（`sources.xiaohongshu_hot.rss_url`）：

- 优点：零配置、能用；
- 缺点：不是官方数据、只有排名、别人的服务器可能哪天就挂了。

挂了就换一个镜像，或者自建 RSSHub 再把路由地址填进去。接口没变，只改一个 URL。

加新源：RSS 直接往 `sources.rss.feeds` 加 `{name, url, region}`；`region` 填 `cn` 或 `intl`。

## 翻译

默认 MyMemory 免费接口（无需 key，每天约 1000 词），只翻标题，结果缓存进 SQLite，同一句只翻一次。

- 想连摘要一起翻：`translate.translate_summary: true`（更吃额度）
- 想换 LLM：在 `tracker/translate.py` 加一个 backend，`translate()` 签名不用变
- 额度用尽会静默跳过，不会中断日报

## 配置速查

| 项 | 说明 |
| --- | --- |
| `digest.hour` | 几点之后允许出报（默认 7，一天一份） |
| `digest.top_n_cn` / `top_n_intl` | 国内外各展示几条 |
| `digest.max_cn` / `max_intl` | 国内外最多收几条 |
| `digest.per_source_limit` | 同类来源的配额 |
| `digest.window_hours` | 日报窗口（默认 24 小时） |
| `digest.max_age_hours` | 超过这个发布时间的旧文不出现 |
| `clustering.threshold` | 标题相似度阈值 |
| `watch.min_similarity` | 跟踪进展的匹配阈值 |
| `watch.max_updates_per_watch` | 每次最多补几条进展 |
| `scoring.*` / `metric_scale` | 打分权重、热度可信度 |

## 目录

```
main.py                 CLI 入口
config.yaml             全部配置
tracker/
  config.py             配置读取
  db.py                 SQLite（items / clusters / digests / watches / judgments）
  util.py               URL 归一化、分词、时间、语言判断
  adapters/             抓取：百度/头条/微博/知乎/小红书 / RSS / Reddit / HN / GitHub
  cluster.py            跨源聚类
  scoring.py            打分 + 主题归类
  translate.py          翻译（带缓存）
  ai.py                 AI 解读（OpenAI 兼容 + 缓存）
  watch.py              跟踪：读勾选、找后续、写链条、发提醒
  judgment.py           判断卡：保存、版本、证据、日报变更
  render.py             生成报纸版式 Markdown
prompts/
  judgment.md           判断卡提示词
plugin/                 Obsidian 插件（主页 / 判断簿 / 来源开关 / AI 设置 / 提醒）
  src/main.ts
  main.js               构建产物（装到 vault 的就是它）
assets/
  info-tracker.css      报纸版式的 CSS snippet
scripts/
  run.sh                launchd 入口
  install_launchd.sh    安装定时任务
data/tracker.db         历史库（去重靠它，别删）
logs/                   运行日志
```

## 已知限制 / 下一步

1. **聚类还是标题相似度**。热搜标题短、各家改写差异大，跨站同题经常合不上（比如百度「五中全会决定」和头条「五中全会《决定》全文发布」）。
   要更准就把 `cluster.py` 的 `tokens/jaccard` 换成 embedding 余弦，接口不变。
2. **热搜本身偏猎奇**。百度/头条的热榜里社会琐事很多，如果觉得吵，把 `max_cn` 调小，或只留澎湃/新浪这类正经新闻源。
3. **微博 Cookie 会过期**，过期后回退到镜像；**小红书只能靠第三方镜像**。这两个源本身只有标题，靠 Bing 新闻补全，补不到就会被丢弃。
4. **热门评论**目前只有 Hacker News、Reddit、知乎（需 Cookie）；微博/小红书评论接口不稳定，还没接。有评论时显示在「发生了什么」之后、AI 解读之前，没有就不显示。
5. **MyMemory 有额度**，一天几十条标题没问题，翻摘要就会紧张。
6. `feedback` 表已建好但没用起来。以后可以让「勾选跟踪」本身就成为偏好信号，反推排序权重。
7. **判断证据自动分类只在 Python 版**。跟踪到判断创建之后的新事实时，AI 会自动标「支持 / 反驳 / 无关」并写 `judgment_evidence`；Pure 版还没搬。判断准确率和置信度校准也还没做。
8. **Pure 版正文只有 RSS 摘要**，没有 trafilatura / Readability 原页抽取；移动端还没实测。
9. **手机端以只读 + AI 为主**。`info-tracker` 在手机读 `朝闻天下/.同步数据/mobile.json`，能看日报/判断簿、用 AI 解读和 AI 交流；抓取、来源开关、Cookie、判断卡新建/复核仍在电脑端。跟踪笔记的停止/重新追踪/时间线排序已能在手机端直接改，跟踪/已读也可以在日报里勾选，电脑端下次运行同步。
