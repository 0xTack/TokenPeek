#!/bin/bash
# 完整版发布包：UnderTheSun-<version>-macOS-universal.zip
# 用法：./scripts/make_release.sh
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST="$ROOT/dist"
VERSION="$(tr -d '[:space:]' < "$ROOT/VERSION")"
NAME="UnderTheSun-${VERSION}-macOS-universal"
TMP="$(mktemp -d)"

if ! [[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+(-[0-9A-Za-z.-]+)?$ ]]; then
  echo "!! VERSION 不合法：$VERSION"
  exit 1
fi

mkdir -p "$DIST"

echo "同步版本号 …"
(cd "$ROOT" && node scripts/sync-version.mjs)

if [ -x "$ROOT/.venv/bin/python" ]; then
  echo "运行测试 …"
  (cd "$ROOT" && .venv/bin/python -m unittest discover -s tests >/dev/null)
fi

if command -v node >/dev/null 2>&1 && [ -d "$ROOT/plugin/node_modules" ]; then
  echo "构建插件 …"
  (cd "$ROOT/plugin" && node esbuild.config.mjs production)
fi

echo "打包 $NAME …"
rsync -a \
  --exclude '.venv' \
  --exclude 'data' \
  --exclude 'logs' \
  --exclude 'dist' \
  --exclude '.backup' \
  --exclude 'preview' \
  --exclude 'docs' \
  --exclude 'community-plugin' \
  --exclude 'plugin/node_modules' \
  --exclude 'community-plugin/node_modules' \
  --exclude 'plugin/test' \
  --exclude 'tests' \
  --exclude 'HANDOFF*.md' \
  --exclude '__pycache__' \
  --exclude '.DS_Store' \
  --exclude '.git' \
  "$ROOT/" "$TMP/$NAME/"

# 不要在发布包里带作者本机的 vault 路径；安装器会写入 data/overrides.json
sed -i '' 's#^  path: ".*"#  path: ""#' "$TMP/$NAME/config.yaml"

chmod +x "$TMP/$NAME/install.command" "$TMP/$NAME/scripts/setup.sh" \
  "$TMP/$NAME/scripts/run.sh" "$TMP/$NAME/scripts/install_launchd.sh"

(cd "$TMP" && zip -qr "$DIST/$NAME.zip" "$NAME")
rm -rf "$TMP"

(cd "$DIST" && shasum -a 256 "$NAME.zip" > "$NAME.zip.sha256")

echo "✓ 已生成：$DIST/$NAME.zip"
echo "✓ 校验值：$DIST/$NAME.zip.sha256"
echo "  发给新用户 → 解压到 ~/code → 双击 install.command"
