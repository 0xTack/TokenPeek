#!/usr/bin/env node
// 同步版本号：VERSION / community-plugin/VERSION 是唯一事实来源。
// 运行：node scripts/sync-version.mjs
import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const semver = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/;

function readVersion(file) {
  const version = readFileSync(resolve(root, file), "utf8").trim();
  if (!semver.test(version)) {
    throw new Error(`${file} 版本号不合法：${version}`);
  }
  return version;
}

function writeJson(file, value) {
  writeFileSync(resolve(root, file), JSON.stringify(value, null, 2) + "\n");
}

const full = readVersion("VERSION");
const community = readVersion("community-plugin/VERSION");

const fullManifest = JSON.parse(readFileSync(resolve(root, "plugin/manifest.json"), "utf8"));
fullManifest.version = full;
writeJson("plugin/manifest.json", fullManifest);

const communityManifest = JSON.parse(
  readFileSync(resolve(root, "community-plugin/manifest.json"), "utf8")
);
communityManifest.version = community;
writeJson("community-plugin/manifest.json", communityManifest);

const versionsPath = resolve(root, "community-plugin/versions.json");
const versions = JSON.parse(readFileSync(versionsPath, "utf8"));
versions[community] = communityManifest.minAppVersion;
writeJson("community-plugin/versions.json", versions);

console.log(`完整版 ${full}`);
console.log(`社区版 ${community}`);
