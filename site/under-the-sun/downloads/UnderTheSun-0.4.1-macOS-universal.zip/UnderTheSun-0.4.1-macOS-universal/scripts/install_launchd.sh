#!/bin/bash
# 安装 / 重装定时任务（07:00 与 19:00）。
#   ./scripts/install_launchd.sh           只安装
#   ./scripts/install_launchd.sh --run-now 安装并立刻跑一次（测试用）
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LABEL="com.xa.infotracker"
AGENT="$HOME/Library/LaunchAgents/$LABEL.plist"
UID_NUM="$(id -u)"

if [ ! -x "$ROOT/.venv/bin/python" ]; then
  echo "!! 没找到 .venv，先执行："
  echo "   cd \"$ROOT\" && python3 -m venv .venv && .venv/bin/pip install -r requirements.txt"
  exit 1
fi

mkdir -p "$HOME/Library/LaunchAgents" "$ROOT/logs" "$ROOT/data"
chmod +x "$ROOT/scripts/run.sh"

sed "s|__ROOT__|$ROOT|g" "$ROOT/scripts/$LABEL.plist.template" > "$AGENT"

launchctl bootout "gui/$UID_NUM/$LABEL" 2>/dev/null || true
launchctl bootstrap "gui/$UID_NUM" "$AGENT"
launchctl enable "gui/$UID_NUM/$LABEL"

echo "✓ 已安装：$AGENT"
echo "  定时：每天 07:00（抓取+日报）、19:00（仅抓取）"
launchctl print "gui/$UID_NUM/$LABEL" 2>/dev/null | grep -E "state|program|next" || true

if [ "${1:-}" = "--run-now" ]; then
  echo "→ 立刻执行一次 …"
  launchctl kickstart -k "gui/$UID_NUM/$LABEL"
  echo "  日志：tail -f \"$ROOT/logs/run.log\""
fi

echo
echo "卸载：launchctl bootout gui/$UID_NUM/$LABEL && rm \"$AGENT\""
