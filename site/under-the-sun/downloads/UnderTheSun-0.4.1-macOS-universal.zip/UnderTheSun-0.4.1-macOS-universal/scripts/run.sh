#!/bin/bash
# launchd 调用的入口。抓取 + 处理 + （到点且今天没出过就）出日报。
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$ROOT/logs" "$ROOT/data"

LOG="$ROOT/logs/run.log"
if [ -f "$LOG" ] && [ "$(wc -c < "$LOG" | tr -d ' ')" -gt 2000000 ]; then
  mv -f "$LOG" "$LOG.1"
fi

cd "$ROOT" || exit 1

PY="$ROOT/.venv/bin/python"
[ -x "$PY" ] || PY="$(command -v python3)"

printf '\n===== %s =====\n' "$(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG"
"$PY" "$ROOT/main.py" run >> "$LOG" 2>&1
exit $?
