#!/bin/bash
# 社区版发布产物：main.js / manifest.json / styles.css / versions.json
# 用法：./scripts/make_community_release.sh
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PLUGIN="$ROOT/community-plugin"
DIST="$ROOT/dist/community"
VERSION="$(tr -d '[:space:]' < "$PLUGIN/VERSION")"
NAME="UnderTheSun-${VERSION}-obsidian"

if ! [[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+(-[0-9A-Za-z.-]+)?$ ]]; then
  echo "!! VERSION 不合法：$VERSION"
  exit 1
fi

mkdir -p "$DIST"
rm -rf "$DIST"/*

echo "同步版本号 …"
(cd "$ROOT" && node scripts/sync-version.mjs)

echo "类型检查 …"
(cd "$PLUGIN" && ../plugin/node_modules/.bin/tsc -p tsconfig.json --noEmit)

echo "构建社区版 …"
(cd "$PLUGIN" && node esbuild.config.mjs production)

cp "$PLUGIN/main.js" "$PLUGIN/manifest.json" "$PLUGIN/styles.css" "$PLUGIN/versions.json" "$DIST/"
cp "$PLUGIN/README.md" "$PLUGIN/LICENSE" "$DIST/"

(cd "$DIST" && zip -q "$NAME.zip" main.js manifest.json styles.css versions.json)
(cd "$DIST" && shasum -a 256 main.js manifest.json styles.css versions.json "$NAME.zip" > SHA256SUMS)

echo "✓ 已生成：$DIST/"
ls -lh "$DIST"
