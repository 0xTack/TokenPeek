#!/bin/bash
# 朝闻天下 · 一键安装 / 修复本地环境
#
# 双击根目录的 install.command，或在终端执行：
#   ./scripts/setup.sh
#
# 可选参数：
#   --vault "/path/to/vault"   指定 Obsidian vault
#   --api-key "sk-..."         顺便写入 AI Key（不填则稍后在插件里填）
#   --no-launchd               不安装 07:00 / 19:00 定时任务
#   --no-run                   安装后不立刻抓取
#   --no-open                  安装后不自动打开 Obsidian
#   --no-restart               不自动退出/重启 Obsidian（测试用）
#   --no-plugin                只装 Python 环境/配置，不复制插件（插件内按钮用）
#   --dry-run                  只打印将要做的事，不修改文件

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
case "$ROOT" in
  "$HOME/Documents"*|"$HOME/Desktop"*|"$HOME/Downloads"*)
    echo "!! 项目在 macOS 受保护目录，launchd 可能没有权限。建议先移到 ~/code/info-tracker。"
    ;;
esac
VAULT=""
API_KEY=""
INSTALL_LAUNCHD=1
INSTALL_PLUGIN=1
RUN_NOW=""
OPEN_OBSIDIAN=1
SKIP_OBSIDIAN=0
DRY_RUN=0
PY=""
PYTHON=""

usage() {
  sed -n '2,15p' "$0" | sed 's/^# \{0,1\}//'
}

while [ $# -gt 0 ]; do
  case "$1" in
    --vault) VAULT="${2:-}"; shift 2 ;;
    --api-key) API_KEY="${2:-}"; shift 2 ;;
    --no-launchd) INSTALL_LAUNCHD=0; shift ;;
    --no-run) RUN_NOW=0; shift ;;
    --no-open) OPEN_OBSIDIAN=0; shift ;;
    --no-restart) SKIP_OBSIDIAN=1; shift ;;
    --no-plugin) INSTALL_PLUGIN=0; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "未知参数：$1"; usage; exit 1 ;;
  esac
done

say() { printf '\n==> %s\n' "$*"; }
warn() { printf '!! %s\n' "$*"; }
dry() { [ "$DRY_RUN" -eq 1 ]; }
run_cmd() {
  if dry; then
    printf '[dry-run] %s\n' "$*"
  else
    "$@"
  fi
}

find_vaults() {
  local base
  for base in \
    "$HOME/Library/Mobile Documents/iCloud~md~obsidian/Documents" \
    "$HOME/Documents" \
    "$HOME/Obsidian"; do
    [ -d "$base" ] || continue
    find "$base" -maxdepth 3 -type d -name .obsidian -print 2>/dev/null \
      | sed 's#/\.obsidian$##'
  done | sort -u
}

say "朝闻天下 · 一键安装"
echo "项目目录：$ROOT"

if ! command -v python3 >/dev/null 2>&1; then
  warn "没有找到 python3。请先安装 Python 3.9+（https://www.python.org/downloads/）"
  exit 1
fi
PYTHON="$(command -v python3)"
if ! "$PYTHON" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)'; then
  warn "Python 版本过低，需要 3.9+；当前：$("$PYTHON" --version 2>&1)"
  exit 1
fi
echo "Python：$("$PYTHON" --version 2>&1)"

# ---------- 选择 vault ----------
if [ -z "$VAULT" ]; then
  VAULTS=()
  while IFS= read -r line; do
    [ -n "$line" ] && VAULTS+=("$line")
  done < <(find_vaults)
  if [ "${#VAULTS[@]}" -eq 1 ]; then
    VAULT="${VAULTS[0]}"
    echo "自动找到 vault：$VAULT"
  elif [ "${#VAULTS[@]}" -gt 1 ]; then
    echo "找到多个 Obsidian vault："
    for i in "${!VAULTS[@]}"; do
      printf '  %d) %s\n' "$((i + 1))" "${VAULTS[$i]}"
    done
    read -r -p "选择编号，或直接粘贴路径： " choice
    if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#VAULTS[@]}" ]; then
      VAULT="${VAULTS[$((choice - 1))]}"
    else
      VAULT="$choice"
    fi
  else
    read -r -p "粘贴 Obsidian vault 路径（可以把文件夹拖进终端）： " VAULT
  fi
fi

VAULT="${VAULT%\"}"; VAULT="${VAULT#\"}"
VAULT="${VAULT%/}"
case "$VAULT" in
  "~"*) VAULT="${HOME}${VAULT#\~}" ;;
esac

if [ -z "$VAULT" ] || [ ! -d "$VAULT/.obsidian" ]; then
  warn "这不是一个 Obsidian vault（找不到 .obsidian）：$VAULT"
  exit 1
fi
echo "Vault：$VAULT"

# ---------- Python 环境 ----------
say "准备 Python 环境"
if [ ! -x "$ROOT/.venv/bin/python" ]; then
  echo "创建 .venv …"
  run_cmd "$PYTHON" -m venv "$ROOT/.venv"
fi
PY="$ROOT/.venv/bin/python"
if dry && [ ! -x "$PY" ]; then
  PY="$PYTHON"
fi
if ! dry; then
  echo "安装依赖（首次可能需要 1–3 分钟）…"
  "$PY" -m pip install -r "$ROOT/requirements.txt"
else
  echo "[dry-run] 会安装 requirements.txt"
fi

# ---------- API Key ----------
if [ -z "$API_KEY" ] && [ -t 0 ]; then
  echo
  read -r -s -p "DeepSeek API Key（可回车跳过，之后在插件里填）： " API_KEY
  echo
fi

# ---------- 写配置 ----------
say "写入配置"
if dry; then
  echo "[dry-run] data/overrides.json 写入 vault.path"
  [ -n "$API_KEY" ] && echo "[dry-run] 同时写入 AI Key"
else
  VAULT="$VAULT" API_KEY="$API_KEY" ROOT="$ROOT" "$PY" - <<'PY'
import json, os
from pathlib import Path

root = Path(os.environ["ROOT"])
vault = os.environ["VAULT"]
key = os.environ.get("API_KEY", "").strip()
path = root / "data" / "overrides.json"
path.parent.mkdir(parents=True, exist_ok=True)
try:
    data = json.loads(path.read_text(encoding="utf-8"))
except Exception:
    data = {}
data.setdefault("vault", {})["path"] = vault
if key:
    ai = data.setdefault("ai", {})
    ai["enabled"] = True
    ai["api_key"] = key
    ai.setdefault("base_url", "https://api.deepseek.com/v1")
    ai.setdefault("model", "deepseek-flash")
path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
print("已写入", path)
PY
fi

# ---------- 检查插件构建 ----------
if [ ! -f "$ROOT/plugin/main.js" ]; then
  if command -v node >/dev/null 2>&1 && command -v npm >/dev/null 2>&1; then
    say "没有找到 plugin/main.js，尝试构建插件"
    if ! dry; then
      (cd "$ROOT/plugin" && npm install && node esbuild.config.mjs production)
    fi
  else
    warn "缺少 plugin/main.js，且没有 Node.js。请把已构建好的 plugin/main.js 放进项目。"
    exit 1
  fi
fi

# ---------- 安装插件到 vault ----------
if [ "$INSTALL_PLUGIN" -eq 1 ]; then
if [ "$SKIP_OBSIDIAN" -eq 0 ] && ! dry && pgrep -x Obsidian >/dev/null 2>&1; then
  say "安装会修改插件配置并重启 Obsidian"
  echo "请先保存手头工作；按回车继续（Ctrl+C 取消）。"
  if [ -t 0 ]; then read -r _; fi
  osascript -e 'tell application "Obsidian" to quit' >/dev/null 2>&1 || true
  for _ in $(seq 1 20); do
    pgrep -x Obsidian >/dev/null 2>&1 || break
    sleep 1
  done
  if pgrep -x Obsidian >/dev/null 2>&1; then
    warn "Obsidian 还没有完全退出。请手动退出后重跑 install.command。"
    exit 1
  fi
fi

say "安装 Obsidian 插件"
PLUGIN_DIR="$VAULT/.obsidian/plugins/info-tracker"
SNIPPET_DIR="$VAULT/.obsidian/snippets"
if dry; then
  echo "[dry-run] 复制插件到 $PLUGIN_DIR"
  echo "[dry-run] 复制 CSS 到 $SNIPPET_DIR/info-tracker.css"
else
  mkdir -p "$PLUGIN_DIR" "$SNIPPET_DIR"
  cp "$ROOT/plugin/main.js" "$ROOT/plugin/manifest.json" "$ROOT/plugin/styles.css" "$PLUGIN_DIR/"
  cp "$ROOT/assets/info-tracker.css" "$SNIPPET_DIR/info-tracker.css"
  ROOT="$ROOT" PLUGIN_JSON="$PLUGIN_DIR/data.json" "$PY" - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ["PLUGIN_JSON"])
try:
    data = json.loads(path.read_text(encoding="utf-8"))
except Exception:
    data = {}
data["projectPath"] = os.environ["ROOT"]
data.setdefault("pythonPath", "")
data.setdefault("showStatusBar", True)
path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
PY
fi

# 启用插件 + CSS 片段
if dry; then
  echo "[dry-run] 在 community-plugins.json 启用 info-tracker"
  echo "[dry-run] 在 appearance.json 启用 info-tracker CSS"
else
  VAULT="$VAULT" "$PY" - <<'PY'
import json, os
from pathlib import Path

vault = Path(os.environ["VAULT"])
plugins_path = vault / ".obsidian" / "community-plugins.json"
try:
    plugins = json.loads(plugins_path.read_text(encoding="utf-8"))
except Exception:
    plugins = []
if "info-tracker" not in plugins:
    plugins.append("info-tracker")
plugins_path.write_text(json.dumps(plugins, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

appearance_path = vault / ".obsidian" / "appearance.json"
try:
    appearance = json.loads(appearance_path.read_text(encoding="utf-8"))
except Exception:
    appearance = {}
enabled = appearance.get("enabledCssSnippets")
if not isinstance(enabled, list):
    enabled = []
if "info-tracker" not in enabled:
    enabled.append("info-tracker")
appearance["enabledCssSnippets"] = enabled
appearance_path.write_text(json.dumps(appearance, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print("已启用插件和 CSS")
PY
fi
else
  echo "已跳过插件安装（--no-plugin）"
fi

# ---------- 定时任务 ----------
if [ "$INSTALL_LAUNCHD" -eq 1 ]; then
  say "安装定时任务（07:00 / 19:00）"
  if dry; then
    echo "[dry-run] scripts/install_launchd.sh"
  else
    chmod +x "$ROOT/scripts/run.sh" "$ROOT/scripts/install_launchd.sh"
    "$ROOT/scripts/install_launchd.sh"
  fi
else
  echo "已跳过 launchd 安装"
fi

# ---------- 首次状态 / 抓取 ----------
say "初始化数据库和状态"
if dry; then
  echo "[dry-run] python main.py status"
else
  (cd "$ROOT" && "$PY" main.py status) || true
fi

if [ -z "$RUN_NOW" ] && [ -t 0 ]; then
  echo
  read -r -p "现在抓取一次并生成今天的日报？[Y/n] " answer
  case "$answer" in
    n|N) RUN_NOW=0 ;;
    *) RUN_NOW=1 ;;
  esac
fi
if [ "${RUN_NOW:-0}" = "1" ]; then
  say "开始抓取（可能要 1–2 分钟）"
  if dry; then
    echo "[dry-run] python main.py run"
  else
    (cd "$ROOT" && "$PY" main.py run) || warn "抓取失败，查看 $ROOT/logs/run.log"
  fi
fi

if [ "$OPEN_OBSIDIAN" -eq 1 ] && ! dry; then
  say "打开 Obsidian"
  open -b md.obsidian 2>/dev/null || open -a Obsidian 2>/dev/null || true
fi

say "完成"
echo "项目：$ROOT"
echo "Vault：$VAULT"
echo "定时：每天 07:00 抓取并出报，19:00 只抓取"
echo "日志：$ROOT/logs/run.log"
echo
echo "如果 Obsidian 提示受限模式：设置 → 第三方插件 → 关闭受限模式，并确认「朝闻天下」已启用。"
echo "手机端 AI Key 在手机 Obsidian 的 设置 → 第三方插件 → 朝闻天下 里单独填。"
