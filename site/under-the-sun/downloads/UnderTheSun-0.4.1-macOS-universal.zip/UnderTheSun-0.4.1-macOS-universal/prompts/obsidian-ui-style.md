# Obsidian 原生 UI / 按钮风格提示词

你是 Obsidian 插件 OmniBooks 的 UI 工程师。只改界面，不编造数据。

## 整体风格

Obsidian 原生桌面风格（Obsidian native UI）：平面、低饱和、无渐变、无装饰性阴影。
不要做成网页 SaaS 风格，不要圆角过大，不要彩色描边。

## 设计令牌

- 背景：`var(--background-primary)`
- 控件底色：`var(--background-secondary)`
- 边框：`1px solid var(--background-modifier-border)`
- 圆角：控件 `8px`，胶囊 `10px`
- 高度：常规控件 `34px`，分段控件 `20–24px`
- 字号：正文 `12–13px`，辅助 `10–11px`
- 字重：常规 `400`，选中 `600`
- 间距：`8px`；控件内边距 `0 12px`
- 文字：常态 `var(--text-muted)`，悬停/选中 `var(--text-normal)`
- 数字：`font-variant-numeric: tabular-nums`

## 交互状态（必须显式覆盖）

禁止把主题强调色用于边框或焦点环：
`--interactive-accent`、`--background-modifier-border-focus` 一律不用。

base / hover / focus / focus-visible / active / selected 六个状态都要钉死：

```css
border: 1px solid var(--background-modifier-border) !important;
outline: none !important;
box-shadow: none !important;
```

Obsidian 全局的 `button:focus-visible` 会画橙色焦点圈，所以必须用 `!important`。

悬停只允许变文字颜色或换成 `--background-modifier-hover`，不加缩放、不加阴影。

## 菜单

使用 Obsidian 原生 Menu（macOS 上下文菜单，带毛玻璃）。

- 条目 `24–28px`，`13px` 字号
- 选中项前置 ✓
- 分组之间用 `1px` 分隔线
- 分组标题用禁用项（灰色），不要用彩色标题
- 菜单项不要图标堆砌，最多一个前置图标

## 控件规范

同一种控件只用一套样式：分段控件统一为无边框、选中淡底加粗。

下拉框、按钮、筛选按钮三者高度与字号必须一致（`34px / 12px`）。

筛选按钮文字固定，不要因为选中项变长而撑宽；激活时只加粗，当前条件放进 `title` 提示。

不要出现编号（1. 2. 3.、圈号），不要用感叹号。

## 图表规范

- 横向条形：`grid-template-columns: 64px 1fr 42px`，轨道高 `8px`，圆角 `4px`
- 柱状图：柱子高度按最大值归一，数值显示在柱子上方
- 数量为 0 时不要画柱子（不要留 `2px` 的小条）
- 热力图 5 级红，从浅到深
- 图表颜色用低饱和 `hsl`，避免高饱和纯色

## 文案

- 中文，直白，不写套话
- AI 推荐理由必须点名具体书名或作者，不要空泛词
- 数据不足时宁可留空或写“暂无”，不要编造

## 性能

- 动画只改 `transform` / `opacity`
- 不要给每张卡加 `will-change`
- 不要为了一个效果新增遮罩层或大量 DOM

## 用途

在 Obsidian 插件里统一按钮、分段控件、下拉框、筛选按钮、菜单和图表的外观时，优先按以上令牌和状态覆盖，避免主题强调色、渐变、阴影和网页 SaaS 感。
