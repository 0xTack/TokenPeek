# 发布规则（Under the Sun）

按 `通用发布规格` 执行。两个产品各自独立版本，互不共用版本号。

## 版本来源

| 产品 | 版本唯一来源 | 产物 |
|---|---|---|
| 完整版（Python + 插件） | `VERSION` | `dist/UnderTheSun-<version>-macOS-universal.zip` |
| 社区版（纯插件） | `community-plugin/VERSION` | `dist/community/` 下的 `main.js`、`manifest.json`、`styles.css`、`versions.json` |

`node scripts/sync-version.mjs` 会把版本同步到两个 `manifest.json` 和社区版 `versions.json`。不要手改这些文件里的版本号。

## 发布前检查

- [ ] 工作区干净，代码已合并
- [ ] 只改 `VERSION` / `community-plugin/VERSION`
- [ ] `node scripts/sync-version.mjs` 已执行
- [ ] Python 测试通过
- [ ] 插件 TypeScript 类型检查通过
- [ ] 在干净目录重新构建
- [ ] 没有把 `.venv`、`data/`、`logs/`、密钥、vault 路径打进产物
- [ ] 上一版资产仍可下载
- [ ] 站点没有旧版本号或旧仓库地址

## 构建

```bash
# 完整版
./scripts/make_release.sh

# 社区版
./scripts/make_community_release.sh
```

产物在 `dist/`，每个压缩包旁边有 `.sha256`；社区版目录里有 `SHA256SUMS`。

## Tag 与 Release

- tag 与版本一一对应：`v0.4.0`、`v0.1.0`
- 先提交，再打 tag，再创建 Release 草稿
- 已发布的 tag 和资产不改；要改就发新 PATCH
- 完整版 Release 资产：`UnderTheSun-<version>-macOS-universal.zip` + `.sha256`
- 社区版 Release 资产：`main.js`、`manifest.json`、`styles.css`、`versions.json`、`SHA256SUMS`

## Release Notes 模板

```markdown
## Under the Sun <version>

- 新增：……
- 改进：……
- 修复：……

下载：
- 完整版（macOS）：UnderTheSun-<version>-macOS-universal.zip
- 社区版（Obsidian）：main.js / manifest.json / styles.css / versions.json

安装：
- 完整版解压后双击 install.command
- 社区版放入 .obsidian/plugins/under-the-sun/

校验：
- 见 SHA256SUMS
```

规则：

- 面向用户，不写内部函数名、提交号、工单号
- 3–6 条，动词开头
- 不写未完成或未验证的功能
- 不泄露密钥、内网地址、用户数据

## 站点

- 站点源码在 `docs/`，用 GitHub Pages 发布（`main` / `/docs`）
- 站点只放页面和小资源；安装包放 Release
- 下载链接使用版本化地址，不要指向 `latest`
- 发版后检查：页面 200、版本号正确、下载 200、校验值一致

## 回滚

- 某个平台包有问题：删除该资产并说明，其它平台保留，尽快发补丁
- 整版不可用：标记 pre-release / 撤下，恢复上一版，发新 PATCH
- 回滚后必须实测：能装、能启动、能读到已有数据
