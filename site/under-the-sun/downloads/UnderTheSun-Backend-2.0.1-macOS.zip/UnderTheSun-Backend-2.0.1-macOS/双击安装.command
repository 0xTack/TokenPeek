#!/bin/bash
# 双击这个文件安装本地增强服务。
# 它只是 install-backend.command 的同名入口，方便在 Finder 里一眼找到。
set -euo pipefail
cd "$(dirname "$0")"
exec ./install-backend.command "$@"
