#!/bin/bash
# Under the Sun 完整版后端安装器（macOS）
#
# 只安装 Python 后端、launchd 服务和 token，不安装/覆盖 Obsidian 插件。
# 用法：双击 install-backend.command，或在终端执行：
#   ./scripts/install_backend.sh
#
# 可选参数：
#   --vault "/path/to/vault"   指定 Obsidian vault
#   --no-launchd               不安装后台服务，只准备环境
#   --no-open                  不自动打开 Obsidian
#   --dry-run                  只打印将要做的事

set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VAULT=""
INSTALL_LAUNCHD=1
OPEN_OBSIDIAN=1
DRY_RUN=0
PORT="${UNDER_THE_SUN_PORT:-8765}"
LABEL="com.0xtack.underthesun.backend"
AGENT="$HOME/Library/LaunchAgents/$LABEL.plist"
TOKEN_DIR="$HOME/.underthesun"
TOKEN_FILE="$TOKEN_DIR/token"

while [ $# -gt 0 ]; do
  case "$1" in
    --vault) VAULT="${2:-}"; shift 2 ;;
    --no-launchd) INSTALL_LAUNCHD=0; shift ;;
    --no-open) OPEN_OBSIDIAN=0; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help) sed -n '2,14p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "未知参数：$1"; exit 1 ;;
  esac
done

say() { printf '\n==> %s\n' "$*"; }
warn() { printf '!! %s\n' "$*"; }
dry() { [ "$DRY_RUN" -eq 1 ]; }
run_cmd() {
  if dry; then printf '[dry-run] %s\n' "$*"; else "$@"; fi
}

find_vaults() {
  local base
  for base in \
    "$HOME/Library/Mobile Documents/iCloud~md~obsidian/Documents" \
    "$HOME/Documents" \
    "$HOME/Obsidian"; do
    [ -d "$base" ] || continue
    find "$base" -maxdepth 3 -type d -name .obsidian -print 2>/dev/null \
      | sed 's#/\.obsidian$##'
  done | sort -u
}

say "Under the Sun · 完整版后端安装器"
echo "后端目录：$ROOT"

if ! command -v python3 >/dev/null 2>&1; then
  warn "没有找到 python3。请先安装 Python 3.9+：https://www.python.org/downloads/"
  exit 1
fi
if ! python3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)'; then
  warn "Python 版本过低，需要 3.9+；当前：$(python3 --version 2>&1)"
  exit 1
fi
echo "Python：$(python3 --version 2>&1)"

# ---------- 选择 vault ----------
if [ -z "$VAULT" ]; then
  VAULTS=()
  while IFS= read -r line; do
    [ -n "$line" ] && VAULTS+=("$line")
  done < <(find_vaults)
  if [ "${#VAULTS[@]}" -eq 1 ]; then
    VAULT="${VAULTS[0]}"
    echo "自动找到 vault：$VAULT"
  elif [ "${#VAULTS[@]}" -gt 1 ]; then
    echo "找到多个 Obsidian vault："
    for i in "${!VAULTS[@]}"; do
      printf '  %d) %s\n' "$((i + 1))" "${VAULTS[$i]}"
    done
    read -r -p "选择编号，或直接粘贴路径： " choice
    if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#VAULTS[@]}" ]; then
      VAULT="${VAULTS[$((choice - 1))]}"
    else
      VAULT="$choice"
    fi
  else
    read -r -p "粘贴 Obsidian vault 路径（可以把文件夹拖进终端）： " VAULT
  fi
fi

VAULT="${VAULT%\"}"; VAULT="${VAULT#\"}"; VAULT="${VAULT%/}"
case "$VAULT" in "~"*) VAULT="${HOME}${VAULT#\~}" ;; esac
if [ -z "$VAULT" ] || [ ! -d "$VAULT/.obsidian" ]; then
  warn "这不是一个 Obsidian vault（找不到 .obsidian）：$VAULT"
  exit 1
fi
echo "Vault：$VAULT"

# ---------- Python 环境 ----------
say "准备 Python 环境"
if [ ! -x "$ROOT/.venv/bin/python" ]; then
  run_cmd python3 -m venv "$ROOT/.venv"
fi
PY="$ROOT/.venv/bin/python"
if dry && [ ! -x "$PY" ]; then PY="$(command -v python3)"; fi
if ! dry; then
  "$PY" -m pip install --upgrade pip >/dev/null 2>&1 || true
  echo "安装依赖（首次可能需要 1–3 分钟）…"
  "$PY" -m pip install -r "$ROOT/requirements.txt"
fi

# ---------- 配置 ----------
say "写入 vault 配置"
if dry; then
  echo "[dry-run] data/overrides.json 写入 vault.path"
else
  VAULT="$VAULT" ROOT="$ROOT" "$PY" - <<'PY'
import json, os
from pathlib import Path
root = Path(os.environ["ROOT"])
path = root / "data" / "overrides.json"
path.parent.mkdir(parents=True, exist_ok=True)
try:
    data = json.loads(path.read_text(encoding="utf-8"))
except Exception:
    data = {}
data.setdefault("vault", {})["path"] = os.environ["VAULT"]
path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
print("已写入", path)
PY
fi

# ---------- token ----------
say "生成后端 token"
if dry; then
  echo "[dry-run] 写入 $TOKEN_FILE"
else
  mkdir -p "$TOKEN_DIR"
  if [ ! -s "$TOKEN_FILE" ]; then
    openssl rand -hex 32 > "$TOKEN_FILE"
    chmod 600 "$TOKEN_FILE"
  fi
  echo "token 文件：$TOKEN_FILE"
fi

# ---------- 写入插件配置 ----------
say "写入插件配置"
PLUGIN_JSON="$VAULT/.obsidian/plugins/under-the-sun/data.json"
if dry; then
  echo "[dry-run] 如果存在 ${PLUGIN_JSON}，写入 backendUrl / backendToken"
elif [ -d "$(dirname "$PLUGIN_JSON")" ]; then
  if ! $DRY_RUN && pgrep -x Obsidian >/dev/null 2>&1; then
    echo "先退出 Obsidian，避免配置被覆盖。"
    osascript -e 'tell application "Obsidian" to quit' >/dev/null 2>&1 || true
    for _ in $(seq 1 20); do pgrep -x Obsidian >/dev/null 2>&1 || break; sleep 1; done
  fi
  ROOT="$ROOT" PLUGIN_JSON="$PLUGIN_JSON" TOKEN_FILE="$TOKEN_FILE" PORT="$PORT" "$PY" - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ["PLUGIN_JSON"])
try:
    data = json.loads(path.read_text(encoding="utf-8"))
except Exception:
    data = {}
data["backendUrl"] = "http://127.0.0.1:%s" % os.environ["PORT"]
data["backendToken"] = Path(os.environ["TOKEN_FILE"]).read_text(encoding="utf-8").strip()
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
print("已写入", path)
PY
else
  warn "没有找到 under-the-sun 插件目录；先安装插件，或稍后在插件设置里粘贴 token。"
fi

# ---------- launchd ----------
if [ "$INSTALL_LAUNCHD" -eq 1 ]; then
  say "安装后台服务（$LABEL）"
  if dry; then
    echo "[dry-run] 写入 $AGENT 并 bootstrap"
  else
    mkdir -p "$HOME/Library/LaunchAgents" "$ROOT/logs"
    sed -e "s|__ROOT__|$ROOT|g" -e "s|__PY__|$PY|g" \
      "$ROOT/scripts/underthesun-backend.plist.template" > "$AGENT"
    launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
    launchctl bootstrap "gui/$(id -u)" "$AGENT"
    launchctl enable "gui/$(id -u)/$LABEL"
    echo "已安装：$AGENT"
  fi
else
  echo "已跳过 launchd"
fi

# ---------- 验证 ----------
if ! dry; then
  say "等待后端启动"
  for _ in $(seq 1 20); do
    if curl -fsS "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; then
      echo "后端已就绪：http://127.0.0.1:$PORT"
      break
    fi
    sleep 1
  done
  curl -s "http://127.0.0.1:$PORT/health" || warn "后端还没起来，查看 $ROOT/logs/backend.log"
  echo
fi

if [ "$OPEN_OBSIDIAN" -eq 1 ] && ! dry; then
  say "打开 Obsidian"
  open -b md.obsidian 2>/dev/null || open -a Obsidian 2>/dev/null || true
fi

say "完成"
echo "后端：$ROOT"
echo "插件不会被安装器覆盖；请在 Obsidian 里刷新 under-the-sun 主页。"
echo "卸载：launchctl bootout gui/$(id -u)/$LABEL && rm \"$AGENT\""
