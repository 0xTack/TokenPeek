#!/usr/bin/env python3
"""Under the Sun 本地后端。

Obsidian 插件只通过 http://127.0.0.1:<port> 调用这里，不直接运行 Python。
默认端口 8765，token 从 ~/.underthesun/token 读取；没有就自动生成。
"""

from __future__ import annotations

import json
import os
import secrets
import subprocess
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parent
TOKEN_FILE = Path.home() / ".underthesun" / "token"
LOG_FILE = ROOT / "logs" / "run.log"
OVERRIDES = ROOT / "data" / "overrides.json"
STATUS = ROOT / "data" / "status.json"
API_VERSION = 1

ALLOWED_COMMANDS = {
    "run",
    "fetch",
    "process",
    "watch",
    "digest",
    "status",
    "stats",
    "watch-stop",
    "watch-start",
    "watch-sort",
    "toggle-feed",
    "add",
    "research",
    "ai-one",
    "ai-all",
    "judge",
    "judge-review",
    "judge-list",
    "watch-flags",
}

_child: subprocess.Popen | None = None


def read_version() -> str:
    try:
        return (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        return "0.0.0"


def load_token() -> str:
    env = os.environ.get("UNDER_THE_SUN_TOKEN", "").strip()
    if env:
        return env
    try:
        token = TOKEN_FILE.read_text(encoding="utf-8").strip()
        if token:
            return token
    except OSError:
        pass
    token = secrets.token_urlsafe(32)
    TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(token + "\n", encoding="utf-8")
    try:
        TOKEN_FILE.chmod(0o600)
    except OSError:
        pass
    print("生成后端 token：%s" % TOKEN_FILE, flush=True)
    return token


TOKEN = load_token()


def python_binary() -> str:
    venv = ROOT / ".venv" / "bin" / "python"
    if venv.exists():
        return str(venv)
    return sys.executable


def json_response(handler: BaseHTTPRequestHandler, code: int, payload: Any) -> None:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def text_response(handler: BaseHTTPRequestHandler, code: int, text: str) -> None:
    body = text.encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", "text/plain; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def read_json_body(handler: BaseHTTPRequestHandler) -> Dict[str, Any]:
    length = int(handler.headers.get("Content-Length") or 0)
    if length <= 0:
        return {}
    raw = handler.rfile.read(length)
    try:
        data = json.loads(raw.decode("utf-8"))
        return data if isinstance(data, dict) else {}
    except (ValueError, UnicodeDecodeError):
        return {}


def run_cli(args: List[str]) -> Dict[str, Any]:
    global _child
    if not args:
        return {"code": -1, "output": "缺少命令"}
    command = str(args[0])
    if command not in ALLOWED_COMMANDS:
        return {"code": -1, "output": "不允许的命令：%s" % command}
    if _child is not None and _child.poll() is None:
        return {"code": -1, "output": "已有任务在运行"}

    cmd = [python_binary(), str(ROOT / "main.py"), *[str(a) for a in args]]
    env = dict(os.environ)
    env["PYTHONUNBUFFERED"] = "1"
    started = time.time()
    try:
        _child = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            text=True,
        )
        output, _ = _child.communicate(timeout=900)
        code = _child.returncode
    except subprocess.TimeoutExpired:
        _child.kill()
        output, _ = _child.communicate()
        code = -1
        output = (output or "") + "\n任务超时"
    except Exception as exc:  # noqa: BLE001
        code = -1
        output = "启动失败：%s" % exc
    finally:
        _child = None

    if len(output) > 200000:
        output = output[-200000:]
    return {
        "code": int(code if code is not None else -1),
        "output": output,
        "duration": round(time.time() - started, 2),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "UnderTheSun/%s" % read_version()

    def log_message(self, fmt: str, *args: Any) -> None:
        # 避免每个请求都刷屏；需要排查时再看 stdout
        if os.environ.get("UNDER_THE_SUN_DEBUG"):
            super().log_message(fmt, *args)

    def authorized(self) -> bool:
        if not TOKEN:
            return True
        return self.headers.get("X-Under-The-Sun-Token", "") == TOKEN

    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Under-The-Sun-Token")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            return json_response(
                self,
                200,
                {"ok": True, "version": read_version(), "api": API_VERSION},
            )
        if not self.authorized():
            return json_response(self, 401, {"ok": False, "error": "unauthorized"})
        if self.path == "/status":
            try:
                data = json.loads(STATUS.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                data = {}
            data["version"] = read_version()
            data["api"] = API_VERSION
            return json_response(self, 200, data)
        if self.path == "/logs":
            try:
                lines = LOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                lines = []
            return text_response(self, 200, "\n".join(lines[-300:]))
        return json_response(self, 404, {"ok": False, "error": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        if not self.authorized():
            return json_response(self, 401, {"ok": False, "error": "unauthorized"})
        if self.path == "/cli":
            data = read_json_body(self)
            args = data.get("args")
            if not isinstance(args, list):
                return json_response(self, 400, {"ok": False, "error": "args must be an array"})
            return json_response(self, 200, run_cli(args))
        if self.path == "/config":
            data = read_json_body(self)
            try:
                current = json.loads(OVERRIDES.read_text(encoding="utf-8"))
                if not isinstance(current, dict):
                    current = {}
            except (OSError, ValueError):
                current = {}

            def merge(base: Dict[str, Any], patch: Dict[str, Any]) -> None:
                for key, value in patch.items():
                    if isinstance(value, dict) and isinstance(base.get(key), dict):
                        merge(base[key], value)
                    else:
                        base[key] = value

            merge(current, data)
            OVERRIDES.parent.mkdir(parents=True, exist_ok=True)
            OVERRIDES.write_text(
                json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            return json_response(self, 200, {"ok": True})
        return json_response(self, 404, {"ok": False, "error": "not found"})


def main() -> int:
    host = os.environ.get("UNDER_THE_SUN_HOST", "127.0.0.1")
    port = int(os.environ.get("UNDER_THE_SUN_PORT", "8765"))
    server = ThreadingHTTPServer((host, port), Handler)
    print("Under the Sun backend %s on http://%s:%d" % (read_version(), host, port), flush=True)
    print("token file: %s" % TOKEN_FILE, flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
