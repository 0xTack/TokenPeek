#!/bin/bash
# 双击安装/修复 Under the Sun 完整版后端（不安装插件）。
set -euo pipefail
cd "$(dirname "$0")"
exec ./scripts/install_backend.sh "$@"
