"""打分与主题归类。

排序完全由规则决定（可复现、可调参、不吃 token）：
    score = 平台热度(归一化) + 跨源数量 + 时间新鲜度

LLM / 翻译只负责把外文变成中文，不参与排序 —— 否则你每天都在猜它为什么这么排。
"""

from __future__ import annotations

import math
import re
import sqlite3
from datetime import datetime, timezone
from typing import Dict, List

from .util import normalize_title, parse_dt

TOPIC_RULES = [
    (
        "时政 / 社会",
        [
            "政府", "政策", "会议", "全会", "人大", "政协", "国务院", "主席",
            "总理", "公安", "法院", "检察", "通报", "事故", "遇难", "受灾",
            "地震", "洪水", "台风", "火灾", "案件", "警方", "司法", "反腐",
            "医疗", "医保", "教育", "学校", "就业", "养老", "住房", "疫情",
            "民生", "维权", "调查", "回应", "辟谣",
            "protest", "court", "police", "election", "government", "law",
            "disaster", "storm", "flood", "fire", "killed", "dead",
        ],
    ),
    (
        "经济 / 民生",
        [
            "经济", "股市", "房价", "消费", "gdp", "央行", "利率", "汇率",
            "裁员", "物价", "税收", "工资", "养老金", "关税", "贸易",
            "economy", "inflation", "market", "jobs", "housing", "tariff",
            "recession", "layoff", "price",
        ],
    ),
    (
        "科技 / AI",
        [
            "ai", "人工智能", "大模型", "芯片", "半导体", "华为", "苹果",
            "手机", "互联网", "平台", "算法", "机器人", "新能源", "航天",
            "自动驾驶", "开源", "编程", "软件",
            "openai", "model", "chip", "semiconductor", "robot", "startup",
        ],
    ),
    (
        "国际",
        [
            "美国", "俄罗斯", "乌克兰", "以色列", "伊朗", "欧盟", "联合国",
            "日本", "韩国", "印度", "欧洲", "中东", "外交", "制裁", "冲突",
            "战争", "停火", "峰会",
            "ukraine", "israel", "iran", "russia", "china", "europe",
            "united nations", "sanction", "ceasefire", "war", "summit",
        ],
    ),
    (
        "文娱 / 体育",
        [
            "电影", "票房", "演唱会", "明星", "综艺", "电视剧", "音乐",
            "足球", "篮球", "奥运", "世界杯", "联赛", "夺冠",
            "film", "movie", "music", "football", "olympic", "match",
        ],
    ),
]


def _topic_of(text: str) -> str:
    normalized = normalize_title(text)
    if not normalized:
        return "其他"

    best_topic = "其他"
    best_hits = 0
    for topic, keywords in TOPIC_RULES:
        hits = 0
        for kw in keywords:
            if re.search(r"[\u4e00-\u9fff]", kw):
                if kw in normalized:
                    hits += 1
            elif re.search(r"\b%s\b" % re.escape(kw), normalized):
                hits += 1
        if hits > best_hits:
            best_topic, best_hits = topic, hits
    return best_topic


def score(conn: sqlite3.Connection, since_iso: str, weights: Dict[str, float]) -> Dict[str, int]:
    rows = conn.execute(
        """
        SELECT i.id, i.cluster_id, i.source, i.kind, i.region, i.metric,
               i.title, i.summary, i.published_at, i.fetched_at
        FROM items i
        WHERE i.fetched_at >= ? AND i.cluster_id IS NOT NULL
        """,
        (since_iso,),
    ).fetchall()

    if not rows:
        return {"clusters": 0, "items": 0}

    scale_map = weights.get("metric_scale") or {}

    def scaled(member) -> float:
        return float(member["metric"] or 0) * float(scale_map.get(member["kind"], 1.0))

    per_source_max: Dict[str, float] = {}
    for row in rows:
        source = row["source"]
        per_source_max[source] = max(per_source_max.get(source, 0.0), scaled(row))

    grouped: Dict[int, List[sqlite3.Row]] = {}
    for row in rows:
        grouped.setdefault(int(row["cluster_id"]), []).append(row)

    now = datetime.now(timezone.utc)
    half_life = max(1.0, float(weights.get("recency_half_life_hours", 24)))
    metric_w = float(weights.get("metric_weight", 3.0))
    source_w = float(weights.get("source_weight", 2.2))
    recency_w = float(weights.get("recency_weight", 1.5))

    for cluster_id, members in grouped.items():
        main = max(members, key=lambda m: (scaled(m), int(m["id"])))
        metric = scaled(main)
        sources = {m["source"] for m in members}

        source_max = max(per_source_max.get(m["source"], 0.0) for m in members)
        if source_max > 1:
            metric_norm = math.log1p(metric) / math.log1p(source_max)
        else:
            metric_norm = 0.0
        metric_norm = min(1.0, max(0.0, metric_norm))

        latest = max(
            (parse_dt(m["published_at"]) or parse_dt(m["fetched_at"]) or now) for m in members
        )
        age_hours = max(0.0, (now - latest).total_seconds() / 3600.0)
        recency = math.exp(-age_hours / half_life)

        # 单源不加分（log2(1)=0），避免每个源白送底分把日报塞满
        total = (
            metric_w * metric_norm
            + source_w * math.log2(max(1, len(sources)))
            + recency_w * recency
        )

        text = " ".join((m["title"] or "") + " " + (m["summary"] or "") for m in members)
        topic = _topic_of(text)

        conn.execute(
            """
            UPDATE clusters
            SET score = ?, metric = ?, source_count = ?, item_count = ?,
                latest = ?, topic = ?, region = ?
            WHERE id = ?
            """,
            (
                round(total, 2),
                metric,
                len(sources),
                len(members),
                latest.isoformat(timespec="seconds"),
                topic,
                main["region"] or "cn",
                cluster_id,
            ),
        )

    conn.commit()
    return {"clusters": len(grouped), "items": len(rows)}
