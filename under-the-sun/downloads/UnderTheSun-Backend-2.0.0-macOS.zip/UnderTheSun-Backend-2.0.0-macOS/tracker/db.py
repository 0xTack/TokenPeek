"""SQLite 存储层。"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, List, Optional

from .util import canonical_url, detect_lang, iso_now, to_iso, url_hash

SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    url_hash     TEXT NOT NULL UNIQUE,
    url          TEXT NOT NULL,
    canonical    TEXT NOT NULL,
    title        TEXT NOT NULL,
    summary      TEXT DEFAULT '',
    author       TEXT DEFAULT '',
    source       TEXT NOT NULL,
    kind         TEXT NOT NULL,
    region       TEXT DEFAULT 'cn',
    lang         TEXT DEFAULT '',
    published_at TEXT,
    fetched_at   TEXT NOT NULL,
    metric       REAL DEFAULT 0,
    extra        TEXT DEFAULT '{}',
    cluster_id   INTEGER,
    digested_on  TEXT
);
CREATE INDEX IF NOT EXISTS idx_items_fetched ON items(fetched_at);
CREATE INDEX IF NOT EXISTS idx_items_cluster ON items(cluster_id);
CREATE INDEX IF NOT EXISTS idx_items_digested ON items(digested_on);
CREATE INDEX IF NOT EXISTS idx_items_region ON items(region);

CREATE TABLE IF NOT EXISTS clusters (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    title        TEXT,
    score        REAL DEFAULT 0,
    metric       REAL DEFAULT 0,
    source_count INTEGER DEFAULT 1,
    item_count   INTEGER DEFAULT 1,
    region       TEXT DEFAULT 'cn',
    latest       TEXT,
    topic        TEXT DEFAULT '其他',
    created_at   TEXT
);
CREATE INDEX IF NOT EXISTS idx_clusters_score ON clusters(score);

CREATE TABLE IF NOT EXISTS digests (
    date          TEXT PRIMARY KEY,
    path          TEXT,
    created_at    TEXT,
    item_count    INTEGER,
    cluster_count INTEGER
);

-- 每份日报实际收录过的条目：跨天去重靠它判断「昨天是不是上过」
CREATE TABLE IF NOT EXISTS digest_seen (
    date       TEXT NOT NULL,
    item_id    INTEGER NOT NULL,
    title      TEXT,
    region     TEXT DEFAULT 'cn',
    PRIMARY KEY (date, item_id)
);
CREATE INDEX IF NOT EXISTS idx_digest_seen_date ON digest_seen(date);

-- 翻译缓存：同一句话只翻一次
CREATE TABLE IF NOT EXISTS translations (
    key        TEXT PRIMARY KEY,
    source     TEXT,
    target     TEXT,
    created_at TEXT
);

-- AI 解读缓存：同一条新闻只调用一次模型
CREATE TABLE IF NOT EXISTS ai_cache (
    key        TEXT PRIMARY KEY,
    model      TEXT,
    title      TEXT,
    text       TEXT,
    created_at TEXT
);

-- 正文补全缓存：只有标题的条目，用 Bing 新闻 / 原页正文补一段
CREATE TABLE IF NOT EXISTS enrich_cache (
    key        TEXT PRIMARY KEY,
    title      TEXT,
    summary    TEXT,
    url        TEXT,
    created_at TEXT
);

-- 热门评论缓存
CREATE TABLE IF NOT EXISTS comments_cache (
    item_id    INTEGER PRIMARY KEY,
    payload    TEXT,
    created_at TEXT
);

-- 跟踪：用户在日报里勾了「跟踪」的条目
CREATE TABLE IF NOT EXISTS watches (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id    INTEGER UNIQUE,
    title      TEXT,
    url        TEXT,
    tokens     TEXT,
    region     TEXT,
    note_path  TEXT,
    created_at TEXT,
    updated_at TEXT,
    active     INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS watch_updates (
    watch_id   INTEGER NOT NULL,
    item_id    INTEGER NOT NULL,
    created_at TEXT,
    PRIMARY KEY (watch_id, item_id)
);

-- 历史脉络：跟踪时回溯库内同类报道，每条带 AI 摘要
CREATE TABLE IF NOT EXISTS watch_history (
    watch_id   INTEGER NOT NULL,
    item_id    INTEGER NOT NULL,
    ai_text    TEXT,
    created_at TEXT,
    PRIMARY KEY (watch_id, item_id)
);

-- 判断卡：用户确认过的、可被事实检验的判断
CREATE TABLE IF NOT EXISTS judgments (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id          INTEGER,
    watch_id         INTEGER,
    question         TEXT,
    claim_type       TEXT,
    claim            TEXT,
    confidence       INTEGER DEFAULT 50,
    confidence_note  TEXT,
    horizon          TEXT,
    scope            TEXT,
    source_quality   TEXT DEFAULT '{}',
    facts            TEXT DEFAULT '[]',
    reasoning        TEXT DEFAULT '[]',
    assumptions      TEXT DEFAULT '[]',
    confirm_if       TEXT DEFAULT '[]',
    falsifiers       TEXT DEFAULT '[]',
    counter          TEXT,
    unknowns         TEXT DEFAULT '[]',
    watch_signals    TEXT DEFAULT '[]',
    status           TEXT DEFAULT '观察中',
    version          INTEGER DEFAULT 1,
    created_at       TEXT,
    updated_at       TEXT,
    active           INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_judgments_item ON judgments(item_id);
CREATE INDEX IF NOT EXISTS idx_judgments_updated ON judgments(updated_at);

-- 判断版本：每次修订都留一份完整快照，旧判断不覆盖
CREATE TABLE IF NOT EXISTS judgment_versions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    judgment_id     INTEGER NOT NULL,
    version         INTEGER NOT NULL,
    claim_type      TEXT,
    claim           TEXT,
    confidence      INTEGER,
    payload         TEXT,
    change_reason   TEXT,
    trigger_item_id INTEGER,
    created_at      TEXT,
    UNIQUE(judgment_id, version)
);
CREATE INDEX IF NOT EXISTS idx_judgment_versions ON judgment_versions(judgment_id);

-- 判断证据：后续事实与判断的关系，先留表，自动分类以后再做
CREATE TABLE IF NOT EXISTS judgment_evidence (
    judgment_id INTEGER NOT NULL,
    item_id     INTEGER NOT NULL,
    stance      TEXT DEFAULT 'neutral',
    note        TEXT,
    source      TEXT DEFAULT 'user',
    created_at  TEXT,
    PRIMARY KEY (judgment_id, item_id)
);

-- 已读记录：只记第一次读的时间，用于日报统计
CREATE TABLE IF NOT EXISTS read_items (
    item_id     INTEGER PRIMARY KEY,
    read_at     TEXT,
    read_date   TEXT,
    digest_date TEXT
);
CREATE INDEX IF NOT EXISTS idx_read_items_date ON read_items(read_date);

-- 预留：以后用「收藏 / 忽略」反过来调权重
CREATE TABLE IF NOT EXISTS feedback (
    item_id    INTEGER NOT NULL,
    action     TEXT NOT NULL,
    created_at TEXT,
    PRIMARY KEY (item_id, action)
);
"""

MIGRATIONS = {
    "items": {
        "region": "TEXT DEFAULT 'cn'",
        "lang": "TEXT DEFAULT ''",
    },
    "clusters": {
        "region": "TEXT DEFAULT 'cn'",
    },
    "watches": {
        "forward": "INTEGER DEFAULT 1",
        "backward": "INTEGER DEFAULT 1",
        "deep": "INTEGER DEFAULT 0",
    },
}


def connect(path: Path) -> sqlite3.Connection:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    init(conn)
    return conn


def _migrate(conn: sqlite3.Connection) -> None:
    """老库补列，避免升级后打不开。"""
    for table, columns in MIGRATIONS.items():
        existing = {row["name"] for row in conn.execute("PRAGMA table_info(%s)" % table)}
        for name, decl in columns.items():
            if name not in existing:
                conn.execute("ALTER TABLE %s ADD COLUMN %s %s" % (table, name, decl))


def init(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    _migrate(conn)
    conn.commit()


def upsert_items(conn: sqlite3.Connection, items: Iterable[Any]) -> int:
    """按 url_hash 去重写入，返回新增条数。"""
    now = datetime.now(timezone.utc)
    now_iso = now.isoformat(timespec="seconds")
    oldest = now - timedelta(days=30)
    inserted = 0
    for item in items:
        canon = canonical_url(item.url)
        if not item.url or not item.title:
            continue
        # feed 里翻出来的陈年文章直接丢掉，别进库
        if item.published_at is not None and item.published_at < oldest:
            continue
        lang = item.lang or detect_lang(item.title + " " + (item.summary or ""))
        cur = conn.execute(
            """
            INSERT OR IGNORE INTO items
                (url_hash, url, canonical, title, summary, author, source,
                 kind, region, lang, published_at, fetched_at, metric, extra)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                url_hash(item.url),
                item.url,
                canon,
                item.title.strip(),
                item.summary or "",
                item.author or "",
                item.source,
                item.kind,
                item.region or "cn",
                lang,
                to_iso(item.published_at),
                now_iso,
                float(item.metric or 0.0),
                json.dumps(item.extra or {}, ensure_ascii=False),
            ),
        )
        inserted += cur.rowcount
    conn.commit()
    return inserted


def count_items(conn: sqlite3.Connection, since: Optional[str] = None) -> int:
    if since:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM items WHERE fetched_at >= ?", (since,)
        ).fetchone()
    else:
        row = conn.execute("SELECT COUNT(*) AS n FROM items").fetchone()
    return int(row["n"])


def mark_read(
    conn: sqlite3.Connection,
    item_id: int,
    digest_date: str = "",
    read_date: Optional[str] = None,
) -> None:
    """记录第一次已读；重复解析同一份日报时不会把日期往后推。"""
    now = iso_now()
    local_day = read_date or datetime.now().astimezone().strftime("%Y-%m-%d")
    conn.execute(
        "INSERT OR IGNORE INTO read_items"
        " (item_id, read_at, read_date, digest_date) VALUES (?, ?, ?, ?)",
        (int(item_id), now, local_day, digest_date),
    )
    conn.commit()


def unmark_read(conn: sqlite3.Connection, item_id: int) -> None:
    conn.execute("DELETE FROM read_items WHERE item_id = ?", (int(item_id),))
    conn.commit()


def read_ids(conn: sqlite3.Connection) -> set:
    return {
        int(row["item_id"])
        for row in conn.execute("SELECT item_id FROM read_items")
    }


def count_reads(conn: sqlite3.Connection, day: Optional[str] = None) -> int:
    if day:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM read_items WHERE read_date = ?", (day,)
        ).fetchone()
    else:
        row = conn.execute("SELECT COUNT(*) AS n FROM read_items").fetchone()
    return int(row["n"])


def count_items_for_day(conn: sqlite3.Connection, day: str) -> int:
    row = conn.execute(
        "SELECT COUNT(*) AS n FROM items WHERE substr(fetched_at, 1, 10) = ?",
        (day,),
    ).fetchone()
    return int(row["n"])


def get_digest(conn: sqlite3.Connection, date: str) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM digests WHERE date = ?", (date,)).fetchone()


def record_digest(
    conn: sqlite3.Connection,
    date: str,
    path: str,
    item_count: int,
    cluster_count: int,
) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO digests (date, path, created_at, item_count, cluster_count)"
        " VALUES (?, ?, ?, ?, ?)",
        (date, path, iso_now(), item_count, cluster_count),
    )
    conn.commit()


def mark_digested(conn: sqlite3.Connection, date: str, item_ids: List[int]) -> None:
    conn.executemany(
        "UPDATE items SET digested_on = ? WHERE id = ?",
        [(date, item_id) for item_id in item_ids],
    )
    conn.commit()


def clear_digest(conn: sqlite3.Connection, date: str) -> None:
    """重出某天的日报前，把当天的「已推送」标记撤掉。"""
    conn.execute("UPDATE items SET digested_on = NULL WHERE digested_on = ?", (date,))
    conn.execute("DELETE FROM digests WHERE date = ?", (date,))
    conn.commit()


def clear_digest_seen(conn: sqlite3.Connection, date: str) -> None:
    """重出当天日报且确实写成功后，再替换当天的去重记录。"""
    conn.execute("DELETE FROM digest_seen WHERE date = ?", (date,))
    conn.commit()


def record_digest_seen(
    conn: sqlite3.Connection, date: str, rows: Iterable[Any]
) -> None:
    """记下这份日报收录了哪些条目，供第二天做「跨天去重」。"""
    conn.executemany(
        "INSERT OR IGNORE INTO digest_seen (date, item_id, title, region)"
        " VALUES (?, ?, ?, ?)",
        [(date, int(item_id), title or "", region or "cn") for item_id, title, region in rows],
    )
    conn.commit()


def list_digest_seen(conn: sqlite3.Connection, dates: List[str]) -> List[sqlite3.Row]:
    if not dates:
        return []
    placeholders = ",".join("?" for _ in dates)
    return conn.execute(
        "SELECT date, item_id, title, region FROM digest_seen WHERE date IN (%s)"
        % placeholders,
        tuple(dates),
    ).fetchall()


# ---------------------------------------------------------------- 翻译缓存


def get_translation(conn: sqlite3.Connection, key: str) -> Optional[str]:
    row = conn.execute("SELECT target FROM translations WHERE key = ?", (key,)).fetchone()
    return row["target"] if row else None


def save_translation(conn: sqlite3.Connection, key: str, source: str, target: str) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO translations (key, source, target, created_at)"
        " VALUES (?, ?, ?, ?)",
        (key, source, target, iso_now()),
    )
    conn.commit()


# ---------------------------------------------------------------- AI 解读缓存


def get_ai_cache(conn: sqlite3.Connection, key: str) -> Optional[str]:
    row = conn.execute("SELECT text FROM ai_cache WHERE key = ?", (key,)).fetchone()
    return row["text"] if row else None


def save_ai_cache(conn: sqlite3.Connection, key: str, model: str, title: str, text: str) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO ai_cache (key, model, title, text, created_at)"
        " VALUES (?, ?, ?, ?, ?)",
        (key, model, title, text, iso_now()),
    )
    conn.commit()


# ---------------------------------------------------------------- 正文 / 评论缓存


def get_enrich(conn: sqlite3.Connection, key: str) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM enrich_cache WHERE key = ?", (key,)).fetchone()


def save_enrich(conn: sqlite3.Connection, key: str, title: str, summary: str, url: str) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO enrich_cache (key, title, summary, url, created_at)"
        " VALUES (?, ?, ?, ?, ?)",
        (key, title, summary, url, iso_now()),
    )
    conn.commit()


def get_comments(conn: sqlite3.Connection, item_id: int) -> Optional[str]:
    row = conn.execute(
        "SELECT payload FROM comments_cache WHERE item_id = ?", (item_id,)
    ).fetchone()
    return row["payload"] if row else None


def save_comments(conn: sqlite3.Connection, item_id: int, payload: str) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO comments_cache (item_id, payload, created_at)"
        " VALUES (?, ?, ?)",
        (item_id, payload, iso_now()),
    )
    conn.commit()


# ---------------------------------------------------------------- 跟踪


def get_item(conn: sqlite3.Connection, item_id: int) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone()


def get_watch_by_item(conn: sqlite3.Connection, item_id: int) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM watches WHERE item_id = ?", (item_id,)).fetchone()


def add_watch(
    conn: sqlite3.Connection,
    item_id: int,
    title: str,
    url: str,
    tokens: List[str],
    region: str,
    note_path: str,
    forward: int = 1,
    backward: int = 1,
) -> None:
    now = iso_now()
    conn.execute(
        """
        INSERT OR IGNORE INTO watches
            (item_id, title, url, tokens, region, note_path, created_at, updated_at, active,
             forward, backward, deep)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 0)
        """,
        (item_id, title, url, json.dumps(tokens, ensure_ascii=False), region, note_path,
         now, now, forward, backward),
    )
    conn.execute("UPDATE watches SET active = 1 WHERE item_id = ?", (item_id,))
    conn.commit()


def set_watch_active(conn: sqlite3.Connection, item_id: int, active: bool) -> None:
    conn.execute(
        "UPDATE watches SET active = ? WHERE item_id = ?", (1 if active else 0, item_id)
    )
    conn.commit()


def set_watch_flags(
    conn: sqlite3.Connection,
    watch_id: int,
    forward: Optional[int] = None,
    backward: Optional[int] = None,
    deep: Optional[int] = None,
) -> None:
    for column, value in (("forward", forward), ("backward", backward), ("deep", deep)):
        if value is not None:
            conn.execute(
                "UPDATE watches SET %s = ? WHERE id = ?" % column,
                (1 if value else 0, watch_id),
            )
    conn.commit()


def get_watch(conn: sqlite3.Connection, watch_id: int) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM watches WHERE id = ?", (watch_id,)).fetchone()


def list_watches(conn: sqlite3.Connection, active_only: bool = True) -> List[sqlite3.Row]:
    sql = "SELECT * FROM watches"
    if active_only:
        sql += " WHERE active = 1"
    sql += " ORDER BY id"
    return conn.execute(sql).fetchall()


def touch_watch(conn: sqlite3.Connection, watch_id: int) -> None:
    conn.execute("UPDATE watches SET updated_at = ? WHERE id = ?", (iso_now(), watch_id))
    conn.commit()


def seen_update(conn: sqlite3.Connection, watch_id: int, item_id: int) -> bool:
    row = conn.execute(
        "SELECT 1 FROM watch_updates WHERE watch_id = ? AND item_id = ?",
        (watch_id, item_id),
    ).fetchone()
    return row is not None


def add_watch_update(conn: sqlite3.Connection, watch_id: int, item_id: int) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO watch_updates (watch_id, item_id, created_at) VALUES (?, ?, ?)",
        (watch_id, item_id, iso_now()),
    )
    conn.commit()


# ---------------------------------------------------------------- 历史脉络


def add_watch_history(
    conn: sqlite3.Connection, watch_id: int, item_id: int, ai_text: str = ""
) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO watch_history (watch_id, item_id, ai_text, created_at)"
        " VALUES (?, ?, ?, ?)",
        (watch_id, item_id, ai_text, iso_now()),
    )
    conn.commit()


def list_watch_history(conn: sqlite3.Connection, watch_id: int) -> List[sqlite3.Row]:
    return conn.execute(
        """
        SELECT h.item_id, h.ai_text, i.title, i.url, i.source,
               COALESCE(i.published_at, i.fetched_at) AS at
        FROM watch_history h
        JOIN items i ON i.id = h.item_id
        WHERE h.watch_id = ?
        ORDER BY at ASC
        """,
        (watch_id,),
    ).fetchall()


def has_watch_history(conn: sqlite3.Connection, watch_id: int) -> bool:
    row = conn.execute(
        "SELECT 1 FROM watch_history WHERE watch_id = ? LIMIT 1", (watch_id,)
    ).fetchone()
    return row is not None


def query(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> List[sqlite3.Row]:
    return conn.execute(sql, params).fetchall()
