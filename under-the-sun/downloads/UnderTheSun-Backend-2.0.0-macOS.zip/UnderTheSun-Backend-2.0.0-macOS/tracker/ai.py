"""AI 解读。

走 OpenAI 兼容的 /chat/completions（DeepSeek、Kimi、通义、Ollama、OpenAI 都行），
结果按「模型 + 标题」缓存，同一篇文章只花一次钱。
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests

from . import db

JUDGMENT_PROMPT_PATH = Path(__file__).resolve().parent.parent / "prompts" / "judgment.md"
EVIDENCE_PROMPT_PATH = Path(__file__).resolve().parent.parent / "prompts" / "evidence.md"

CHAT_PROMPT = (
    "你是新闻分析助手，正在和用户讨论一条具体新闻。\n"
    "规则：\n"
    "1. 只基于下面提供的材料、已有解读和对话历史回答，不要编造。\n"
    "2. 区分事实、推断和判断；不知道就说不知道。\n"
    "3. 回答简洁，先直接回答，再补依据。\n"
    "4. 用户要判断时，给出可检验的判断、置信度和最强反方。\n"
    "5. 不要重复整篇解读，不要把话说满。\n"
    "6. 回答保持紧凑，不要输出多余空行；不要用占位符或空白段落。\n"
)

JUDGMENT_REVIEW_PROMPT = (
    "\n\n你现在做的是「判断复核」，不是重写新闻解读。\n"
    "输入里有：当前判断卡、上次修订时间、之后出现的新事实。\n"
    "请输出修订后的完整判断卡 JSON，字段与系统提示完全一致，并额外增加两个字段：\n"
    '  "change_reason": "为什么维持或修改，1-2 句",\n'
    '  "status_suggestion": "观察中 / 加强 / 削弱 / 已修正 / 已证伪 五选一"\n'
    "规则：\n"
    "- 如果新事实不足以改变判断，claim、confidence、confirm_if、falsifiers 保持原样，"
    "change_reason 写「维持：…」，status_suggestion 写「观察中」或「加强」。\n"
    "- 如果新事实触及原 falsifiers，必须下调置信度或修改 claim，不能假装没看见。\n"
    "- 新事实只能来自输入，不要编造。\n"
    "- 只输出 JSON 对象。"
)


def _extract_json(text: str) -> Optional[Dict[str, Any]]:
    raw = (text or "").strip()
    if not raw:
        return None
    raw = re.sub(r"^```(?:json)?\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)
    start = raw.find("{")
    end = raw.rfind("}")
    if start == -1 or end == -1:
        return None
    try:
        value = json.loads(raw[start : end + 1])
    except (TypeError, ValueError):
        return None
    return value if isinstance(value, dict) else None

SYSTEM_PROMPT = (
    "你是资深新闻评论编辑，按下面的方法分析一条新闻，不要复述新闻。严格按格式输出，不要加多余文字：\n"
    "一句话：不超过 40 字，概括最核心的事实与意义。\n"
    "===\n"
    "【事实】只写材料中确定的事实；材料不足时补一句「尚不清楚：…」\n"
    "【报道评价】用 1-2 句判断报道本身：信源是否单一、是否缺关键背景、标题是否夸大；只写能判断的\n"
    "【核心矛盾】这件事真正的冲突是什么（如权利 vs 权力、效率 vs 公平、管理 vs 自由）\n"
    "【利益与权力】谁获利、谁承担成本、谁有决定权、谁没有发言权\n"
    "【原因】为什么会发生（制度 / 经济 / 技术 / 文化）\n"
    "【反方】反对这个判断的人，最强的理由是什么\n"
    "【判断】一句话给出你的判断\n"
    "【更大的问题】从个案上升到什么更普遍的问题\n"
    "要求：材料不足时明确说「已知信息有限」，不要编造；每节不超过两句；总字数 300-500。"
)


class AI:
    def __init__(self, cfg, conn, session: Optional[requests.Session] = None):
        self.enabled = bool(cfg.get("enabled")) and bool(cfg.get("api_key"))
        self.base_url = str(cfg.get("base_url") or "").rstrip("/")
        self.api_key = str(cfg.get("api_key") or "")
        self.model = str(cfg.get("model") or "")
        self.max_items = int(cfg.get("max_items", 12))
        self.timeout = int(cfg.get("timeout", 60))
        self.temperature = float(cfg.get("temperature", 0.3))
        self.reasoning_effort = str(cfg.get("reasoning_effort") or "")
        self.conn = conn
        self.session = session or requests.Session()
        self.calls = 0
        self.error = ""
        self.context = ""

    def available(self) -> bool:
        return self.enabled

    def cached(self, title: str) -> str:
        """只读缓存，不发请求。用于渲染时判断这条解读过没有。"""
        if not title:
            return ""
        key = hashlib.sha1((self.model + "|" + title).encode("utf-8")).hexdigest()
        return db.get_ai_cache(self.conn, key) or ""

    def interpret(self, title: str, summary: str = "", force: bool = False) -> str:
        if not self.enabled or not title:
            return ""

        key = hashlib.sha1((self.model + "|" + title).encode("utf-8")).hexdigest()
        cached = db.get_ai_cache(self.conn, key)
        if cached is not None:
            return cached

        if not force and self.calls >= self.max_items:
            return ""

        text = self._chat(title, summary)
        self.calls += 1
        if text:
            db.save_ai_cache(self.conn, key, self.model, title, text)
        return text

    def chat(
        self,
        title: str,
        summary: str = "",
        context: str = "",
        messages=None,
        insight: str = "",
    ) -> str:
        """围绕一条新闻继续对话。messages 是 [{role, content}]。"""
        if not self.enabled or not title:
            return ""

        history = []
        for message in (messages or [])[-20:]:
            if not isinstance(message, dict):
                continue
            role = str(message.get("role") or "")
            content = str(message.get("content") or "").strip()
            if role in ("user", "assistant") and content:
                history.append({"role": role, "content": content})

        system = (
            CHAT_PROMPT
            + "\n新闻标题：%s\n摘要：%s\n正文：%s\n已有解读：%s\n"
            % (
                title,
                (summary or "（无摘要）")[:800],
                (context or summary or "（无正文）")[:1800],
                (insight or "（还没有生成解读）")[:1200],
            )
        )
        payload = {
            "model": self.model,
            "temperature": 0.4,
            "max_tokens": 2000,
            "messages": [{"role": "system", "content": system}] + history,
        }
        if self.reasoning_effort:
            payload["reasoning_effort"] = self.reasoning_effort
        text = self._post(payload)
        self.calls += 1
        return text

    def summarize(self, title: str, text: str) -> str:
        """把外文报道概括成 2–3 句中文，用于「发生了什么」。"""
        if not self.enabled or not title:
            return ""
        key = hashlib.sha1(("sum|" + self.model + "|" + title).encode("utf-8")).hexdigest()
        cached = db.get_ai_cache(self.conn, key)
        if cached is not None:
            return cached
        if self.calls >= self.max_items * 2:
            return ""

        payload = {
            "model": self.model,
            "temperature": 0.2,
            "max_tokens": 400,
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "你是中文新闻编辑。用 2-3 句中文客观概括这条新闻：发生了什么、"
                        "涉及谁、关键数字。不评论、不推测，没有的信息不要编。直接给正文。"
                    ),
                },
                {
                    "role": "user",
                    "content": "标题：%s\n正文：%s" % (title, (text or "")[:1800]),
                },
            ],
        }
        text_out = self._post(payload)
        self.calls += 1
        if text_out:
            db.save_ai_cache(self.conn, key, self.model, "sum|" + title, text_out)
        return text_out

    def _judgment_prompt(self) -> str:
        try:
            return JUDGMENT_PROMPT_PATH.read_text(encoding="utf-8")
        except OSError:
            return (
                "你是新闻判断编辑。把新闻转成可检验的判断卡。"
                "输出 JSON，字段包括 question、claim_type、claim、confidence、"
                "confidence_note、horizon、scope、source_quality、facts、reasoning、"
                "assumptions、confirm_if、falsifiers、counter、unknowns、watch。"
                "claim 不超过 60 字，必须可证伪；facts 只写材料事实。"
            )

    def draft_judgment(
        self, title: str, summary: str = "", context: str = "", extra: str = ""
    ) -> Dict[str, Any]:
        """把一条新闻起草成判断卡。返回 dict；失败返回空 dict。"""
        if not self.enabled or not title:
            return {}
        payload = {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": 4000,
            "messages": [
                {"role": "system", "content": self._judgment_prompt()},
                {
                    "role": "user",
                    "content": (
                        "标题：%s\n摘要：%s\n补充正文：%s\n%s\n"
                        "请把这条新闻转成判断卡。"
                        % (
                            title,
                            (summary or "（无摘要）")[:1200],
                            (context or "（无正文）")[:1600],
                            extra or "",
                        )
                    ),
                },
            ],
        }
        if self.reasoning_effort:
            payload["reasoning_effort"] = self.reasoning_effort
        text = self._post(payload)
        self.calls += 1
        card = _extract_json(text)
        if card is None:
            self.error = self.error or "模型返回的不是合法 JSON"
            return {}
        return card

    def review_judgment(
        self, card: Dict[str, Any], title: str, new_facts: str
    ) -> Dict[str, Any]:
        """带着新事实复核一张判断卡，返回修订后的完整卡。"""
        if not self.enabled:
            return {}
        payload = {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": 4000,
            "messages": [
                {
                    "role": "system",
                    "content": self._judgment_prompt() + JUDGMENT_REVIEW_PROMPT,
                },
                {
                    "role": "user",
                    "content": (
                        "原新闻标题：%s\n\n当前判断卡：\n%s\n\n"
                        "上次修订之后出现的新事实：\n%s\n\n"
                        "请输出修订后的判断卡。"
                        % (
                            title,
                            json.dumps(card, ensure_ascii=False, indent=2),
                            new_facts or "（暂无新增事实）",
                        )
                    ),
                },
            ],
        }
        if self.reasoning_effort:
            payload["reasoning_effort"] = self.reasoning_effort
        text = self._post(payload)
        self.calls += 1
        revised = _extract_json(text)
        if revised is None:
            self.error = self.error or "复核返回的不是合法 JSON"
            return {}
        return revised

    def classify_evidence(
        self, card: Dict[str, Any], facts: List[Dict[str, Any]], title: str = ""
    ) -> Dict[int, Dict[str, str]]:
        """判断后续报道相对判断卡的关系，返回 {编号: {stance, note}}。"""
        if not self.enabled or not facts:
            return {}

        material = []
        for index, fact in enumerate(facts):
            material.append(
                "[%d] 标题：%s\n来源：%s\n摘要：%s"
                % (
                    index,
                    str(fact.get("title") or ""),
                    str(fact.get("source") or ""),
                    str(fact.get("summary") or "（无摘要）")[:600],
                )
            )

        card_view = {
            "question": card.get("question") or "",
            "claim_type": card.get("claim_type") or "",
            "claim": card.get("claim") or "",
            "horizon": card.get("horizon") or "",
            "facts": (card.get("facts") or [])[:6],
            "confirm_if": (card.get("confirm_if") or [])[:6],
            "falsifiers": (card.get("falsifiers") or [])[:6],
        }
        payload = {
            "model": self.model,
            "temperature": 0.1,
            "max_tokens": 2000,
            "messages": [
                {"role": "system", "content": self._evidence_prompt()},
                {
                    "role": "user",
                    "content": "判断卡：\n%s\n\n原新闻：%s\n\n后续报道：\n%s\n\n请逐条分类并输出 JSON。"
                    % (
                        json.dumps(card_view, ensure_ascii=False, indent=2),
                        title or "（未提供）",
                        "\n\n".join(material),
                    ),
                },
            ],
        }
        if self.reasoning_effort:
            payload["reasoning_effort"] = self.reasoning_effort
        text = self._post(payload)
        self.calls += 1
        data = _extract_json(text)
        if data is None:
            self.error = self.error or "证据分类返回的不是合法 JSON"
            return {}
        rows = data.get("items")
        if not isinstance(rows, list):
            return {}

        out: Dict[int, Dict[str, str]] = {}
        for row in rows:
            if not isinstance(row, dict):
                continue
            try:
                index = int(row.get("i"))
            except (TypeError, ValueError):
                continue
            stance = str(row.get("stance") or "")
            if index not in range(len(facts)) or stance not in (
                "support",
                "contradict",
                "neutral",
            ):
                continue
            out[index] = {
                "stance": stance,
                "note": str(row.get("note") or "")[:200],
            }
        return out

    def _evidence_prompt(self) -> str:
        try:
            return EVIDENCE_PROMPT_PATH.read_text(encoding="utf-8")
        except OSError:
            return (
                "你是判断复核助手。判断后续报道相对判断卡的关系："
                "support（支持）/ contradict（反驳）/ neutral（无关或重复）。"
                '只输出 JSON：{"items":[{"i":0,"stance":"support","note":"..."}]}'
            )

    def _post(self, payload: dict) -> str:
        headers = {
            "Authorization": "Bearer %s" % self.api_key,
            "Content-Type": "application/json",
        }
        last_error = ""
        for attempt in range(2):
            try:
                resp = self.session.post(
                    "%s/chat/completions" % self.base_url,
                    headers=headers,
                    json=payload,
                    timeout=self.timeout,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    content = ((data.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
                    self.error = ""
                    return content.strip()
                last_error = "HTTP %d: %s" % (resp.status_code, resp.text[:200])
                # 限流或服务端抖动，稍等后重试一次
                if attempt == 0 and (resp.status_code == 429 or resp.status_code >= 500):
                    time.sleep(1.2)
                    continue
                self.error = last_error
                return ""
            except Exception as exc:
                last_error = str(exc)
                if attempt == 0:
                    time.sleep(1.0)
                    continue
                self.error = last_error
                return ""
        self.error = last_error
        return ""

    def _chat(self, title: str, summary: str) -> str:
        payload = {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": 4000,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": "标题：%s\n摘要：%s\n正文：%s"
                    % (
                        title,
                        (summary or "（无摘要）")[:600],
                        (self.context or "（无正文）")[:1500],
                    ),
                },
            ],
        }
        headers = {
            "Authorization": "Bearer %s" % self.api_key,
            "Content-Type": "application/json",
        }
        if self.reasoning_effort:
            payload["reasoning_effort"] = self.reasoning_effort
        return self._post(payload)

    def short_summary(self, title: str, text: str = "") -> str:
        """用不超过 20 个汉字概括一条跟踪进展。"""
        if not self.enabled or not title:
            return ""
        payload = {
            "model": self.model,
            "temperature": 0.2,
            "max_tokens": 80,
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "用不超过 20 个汉字概括这条新闻，只输出一句话。"
                        "不要解释，不要加引号，不要写“总结：”。"
                    ),
                },
                {
                    "role": "user",
                    "content": "标题：%s\n摘要：%s"
                    % (title, (text or "（无摘要）")[:800]),
                },
            ],
        }
        return self._post(payload).strip()

    def translate(self, text: str, target: str = "zh-CN") -> str:
        """用当前 AI 模型翻译外文新闻，失败时由调用方回退到免费接口。"""
        text = (text or "").strip()
        if not text or not self.enabled:
            return ""
        payload = {
            "model": self.model,
            "temperature": 0,
            "max_tokens": 1200,
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "你是严谨的新闻翻译。把用户给出的外文新闻标题或摘要翻译成简体中文。"
                        "只输出译文，不要解释，不要保留原文，不要加引号。"
                        "人名、机构名、数字和日期保持准确。"
                    ),
                },
                {"role": "user", "content": text[:2000]},
            ],
        }
        return self._post(payload).strip()

    def test(self) -> Tuple[bool, str]:
        if not self.api_key:
            return False, "还没填 API Key"
        if not self.model:
            return False, "还没填模型"
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": "只回复 ok"}],
            "max_tokens": 32,
            "temperature": 0,
            "stream": False,
        }
        headers = {
            "Authorization": "Bearer %s" % self.api_key,
            "Content-Type": "application/json",
        }
        try:
            resp = self.session.post(
                "%s/chat/completions" % self.base_url,
                headers=headers,
                json=payload,
                timeout=min(self.timeout, 30),
            )
            if resp.status_code == 200:
                return True, "连接成功：%s 可用" % self.model
            return False, "HTTP %d：%s" % (resp.status_code, resp.text[:200])
        except Exception as exc:  # noqa: BLE001
            return False, "请求失败：%s" % str(exc)[:200]
