"""翻译。

默认走 MyMemory 免费接口（不需要 key，每天约 1000 词额度），
翻译结果缓存进 SQLite，同一句话只翻一次。

想换成 LLM 的话，实现一个 openai 兼容的 backend 就行，
`translate()` 的签名不用变。
"""

from __future__ import annotations

import hashlib
import html
import time
from typing import Optional, Tuple

from . import db


class Translator:
    def __init__(self, cfg, conn, session, ai=None):
        self.enabled = bool(cfg.get("enabled", True))
        self.ai = ai
        self.backend = str(cfg.get("backend", "mymemory"))
        self.target = str(cfg.get("target", "zh-CN"))
        self.translate_summary = bool(cfg.get("translate_summary", False))
        self.max_per_run = int(cfg.get("max_per_run", 80))
        self.min_interval = float(cfg.get("min_interval", 0.25))
        self.conn = conn
        self.session = session
        self.calls = 0
        self._last_call = 0.0

    def translate(self, text: str, source_lang: str = "en") -> str:
        text = (text or "").strip()
        if not self.enabled or not text or source_lang == "zh":
            return ""

        key = hashlib.sha1((self.target + "|" + text).encode("utf-8")).hexdigest()
        cached = db.get_translation(self.conn, key)
        if cached is not None:
            return cached

        if self.calls >= self.max_per_run:
            return ""

        result = ""
        if self.ai is not None and self.ai.available():
            result = self.ai.translate(text)
        if not result:
            result = self._mymemory(text, source_lang)
        self.calls += 1
        if result:
            db.save_translation(self.conn, key, text, result)
        return result

    def _mymemory(self, text: str, source_lang: str) -> str:
        lang = "zh-CN" if source_lang == "zh" else "en"
        wait = self.min_interval - (time.time() - self._last_call)
        if wait > 0:
            time.sleep(wait)
        try:
            resp = self.session.get(
                "https://api.mymemory.translated.net/get",
                params={"q": text[:500], "langpair": "%s|%s" % (lang, self.target)},
                timeout=20,
            )
            self._last_call = time.time()
            payload = resp.json()
        except Exception:
            return ""

        if int(payload.get("responseStatus") or 0) != 200:
            return ""

        out = html.unescape((payload.get("responseData") or {}).get("translatedText") or "")
        out = out.strip()
        if not out or "MYMEMORY WARNING" in out.upper():
            return ""
        return out

    def display(self, title: str, summary: str, lang: str) -> Tuple[str, str, bool]:
        """返回（展示标题，展示摘要，是否翻译过）。"""
        if not self.enabled or lang == "zh":
            return title, summary, False

        zh_title = self.translate(title, lang) or title
        translated = zh_title != title

        zh_summary = summary
        if self.translate_summary and summary:
            zh_summary = self.translate(summary[:300], lang) or summary

        return zh_title, zh_summary, translated
