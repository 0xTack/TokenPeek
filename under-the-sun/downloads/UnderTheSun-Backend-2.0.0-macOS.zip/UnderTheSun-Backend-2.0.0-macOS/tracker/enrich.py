"""给只有标题的条目补一段「到底发生了什么」。

顺序：
1. 条目自带摘要（百度 desc、知乎 excerpt、腾讯 abstract、RSS summary）够长 → 直接用；
2. 原链接像文章页 → trafilatura 抽正文；
3. 还不行 → 用标题去 Bing 新闻 RSS 搜一篇相关报道，拿它的摘要；
4. 还不行 → 这条被判定为「只有标题」，不进报纸（可配置关掉）。
"""

from __future__ import annotations

import hashlib
import json
import re
from typing import Dict, List, Optional
from urllib.parse import quote

import feedparser
import requests

from . import db
from .util import normalize_title, strip_html

BING_NEWS = "https://www.bing.com/news/search"

# 这些链接是搜索页 / 话题页，不是文章，抽正文只会得到一堆导航文字
NON_ARTICLE = (
    "/search",
    "s?wd=",
    "/trending/",
    "search_result",
    "/hot",
    "weibo?q=",
    "/topic/",
)


def _is_article_url(url: str) -> bool:
    lowered = (url or "").lower()
    return bool(lowered.startswith("http")) and not any(p in lowered for p in NON_ARTICLE)


def cache_key(title: str) -> str:
    return hashlib.sha1(normalize_title(title).encode("utf-8")).hexdigest()


def _first_sentences(text: str, limit: int = 220) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    if not text:
        return ""
    parts = re.split(r"(?<=[。！？!?])", text)
    out = ""
    for part in parts:
        if not part:
            continue
        if out and len(out) + len(part) > limit:
            break
        out += part
        if len(out) >= limit * 0.6:
            break
    return out[:limit].strip()


def fetch_article(session: requests.Session, url: str, timeout: int = 12) -> str:
    if not _is_article_url(url):
        return ""
    try:
        import trafilatura

        resp = session.get(url, timeout=timeout, allow_redirects=True)
        if resp.status_code != 200:
            return ""
        if not resp.encoding or resp.encoding.lower() in ("iso-8859-1", "latin-1"):
            resp.encoding = resp.apparent_encoding or "utf-8"
        text = trafilatura.extract(resp.text, include_comments=False) or ""
        return re.sub(r"\s+", " ", text).strip()
    except Exception:
        return ""


def bing_news(session: requests.Session, title: str, timeout: int = 12) -> tuple:
    """用标题搜一篇相关报道，返回（摘要，链接）。"""
    try:
        resp = session.get(
            BING_NEWS,
            params={"q": title, "format": "RSS"},
            timeout=timeout,
        )
        if resp.status_code != 200:
            return "", ""
        parsed = feedparser.parse(resp.content)
    except Exception:
        return "", ""

    for entry in parsed.entries[:3]:
        summary = strip_html(entry.get("summary") or "", 800)
        link = entry.get("link") or ""
        if len(summary) >= 30:
            return summary, link
    return "", ""


def enrich_clusters(conn, cfg, clusters: List[dict], session: requests.Session) -> List[dict]:
    settings = cfg.section("content")
    limit = int(settings.get("enrich_top", 24))
    min_chars = int(settings.get("min_chars", 40))
    detail_chars = int(settings.get("detail_chars", 220))
    use_article = bool(settings.get("fetch_article", True))
    timeout = int(settings.get("timeout", 12))

    for cluster in clusters[:limit]:
        main = max(cluster["items"], key=lambda r: (float(r["metric"] or 0), r["id"]))
        lead = strip_html(main["summary"] or "", 800)
        lead_url = ""

        # 摘要太短就抓正文，让「发生了什么」更详细
        if use_article and len(lead) < detail_chars:
            text = fetch_article(session, main["url"], timeout)
            if len(text) > len(lead):
                lead = text

        if len(lead) < min_chars:
            key = cache_key(cluster["title"])
            cached = db.get_enrich(conn, key)
            if cached is not None:
                lead = cached["summary"] or ""
                lead_url = cached["url"] or ""

        if len(lead) < detail_chars:
            summary, link = bing_news(session, cluster["title"], timeout)
            if use_article and link:
                article = fetch_article(session, link, timeout)
                if len(article) > len(summary):
                    summary = article
            if len(summary) > len(lead):
                lead = summary
                lead_url = link
            if len(lead) >= min_chars:
                db.save_enrich(conn, cache_key(cluster["title"]), cluster["title"], lead, lead_url)

        cluster["lead"] = _first_sentences(lead, 260)
        cluster["lead_url"] = lead_url
        cluster["has_content"] = len(lead) >= min_chars

    # 超出 enrich_top 的条目，有摘要也算有内容
    for cluster in clusters[limit:]:
        main = max(cluster["items"], key=lambda r: (float(r["metric"] or 0), r["id"]))
        summary = strip_html(main["summary"] or "", 800)
        cluster["lead"] = _first_sentences(summary)
        cluster["lead_url"] = ""
        cluster["has_content"] = len(summary) >= min_chars

    return clusters


# ---------------------------------------------------------------- 热门评论


def reddit_comments(conn, session, item, limit: int = 3) -> List[Dict]:
    """Reddit 的评论 RSS（.rss 后缀）目前仍可用。"""
    if item["kind"] != "reddit":
        return []

    cached = db.get_comments(conn, item["id"])
    if cached is not None:
        try:
            return json.loads(cached)
        except ValueError:
            return []

    try:
        extra = json.loads(item["extra"] or "{}")
    except ValueError:
        extra = {}
    link = (extra.get("discussion") or "").rstrip("/")
    if not link:
        return []

    try:
        resp = session.get(link + "/.rss", timeout=15)
        if resp.status_code != 200:
            return []
        parsed = feedparser.parse(resp.content)
    except Exception:
        return []

    comments: List[Dict] = []
    for entry in parsed.entries[: limit * 3]:
        text = strip_html(entry.get("summary") or entry.get("content", [{}])[0].get("value", ""), 300)
        author = (entry.get("author") or "").replace("/u/", "")
        if "submitted by" in text.lower()[:80]:
            continue
        if len(text) >= 20:
            comments.append({"by": author or "reddit", "text": text})
        if len(comments) >= limit:
            break

    if comments:
        db.save_comments(conn, item["id"], json.dumps(comments, ensure_ascii=False))
    return comments


def zhihu_comments(conn, session, item, cookie: str, limit: int = 3) -> List[Dict]:
    """知乎需要登录态；有 Cookie 时取前几条高赞回答的摘要。"""
    if not cookie or item["source"] != "知乎热榜":
        return []

    cached = db.get_comments(conn, item["id"])
    if cached is not None:
        try:
            return json.loads(cached)
        except ValueError:
            return []

    match = re.search(r"/question/(\d+)", item["url"])
    if not match:
        return []

    try:
        resp = session.get(
            "https://www.zhihu.com/api/v4/questions/%s/answers" % match.group(1),
            params={"limit": 5, "include": "data[*].excerpt,author.name,voteup_count"},
            headers={"Cookie": cookie, "Referer": item["url"]},
            timeout=15,
        )
        if resp.status_code != 200:
            return []
        payload = resp.json()
    except Exception:
        return []

    comments: List[Dict] = []
    for answer in (payload.get("data") or [])[: limit * 2]:
        text = strip_html(answer.get("excerpt") or "", 300)
        author = ((answer.get("author") or {}).get("name")) or "匿名"
        if len(text) >= 20:
            comments.append({"by": author, "text": text})
        if len(comments) >= limit:
            break

    if comments:
        db.save_comments(conn, item["id"], json.dumps(comments, ensure_ascii=False))
    return comments


def hn_comments(conn, session, item, limit: int = 3) -> List[Dict]:
    """Hacker News 的前几条高赞评论（官方 API 免费）。"""
    if item["kind"] != "hn":
        return []

    cached = db.get_comments(conn, item["id"])
    if cached is not None:
        try:
            return json.loads(cached)
        except ValueError:
            return []

    try:
        extra = json.loads(item["extra"] or "{}")
    except ValueError:
        extra = {}
    discussion = extra.get("discussion") or ""
    match = re.search(r"id=(\d+)", discussion)
    if not match:
        return []

    story_id = match.group(1)
    try:
        resp = session.get(
            "https://hacker-news.firebaseio.com/v0/item/%s.json" % story_id, timeout=12
        )
        kids = (resp.json() or {}).get("kids") or []
    except Exception:
        return []

    comments: List[Dict] = []
    for kid in kids[: limit * 2]:
        try:
            data = session.get(
                "https://hacker-news.firebaseio.com/v0/item/%s.json" % kid, timeout=10
            ).json() or {}
        except Exception:
            continue
        text = strip_html(data.get("text") or "", 300)
        if len(text) >= 20:
            comments.append({"by": data.get("by") or "", "text": text})
        if len(comments) >= limit:
            break

    if comments:
        db.save_comments(conn, item["id"], json.dumps(comments, ensure_ascii=False))
    return comments
