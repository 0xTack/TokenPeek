"""信息跟踪：抓取 -> 去重聚类 -> 打分 -> 生成 Obsidian 日报。"""

import warnings

# 必须在 import urllib3 之前按消息文本过滤，
# 否则 macOS 自带 Python（LibreSSL）会先抛一条无用的 NotOpenSSLWarning。
warnings.filterwarnings("ignore", message="urllib3 v2 only supports OpenSSL")

try:  # 再按类型兜一层
    from urllib3.exceptions import NotOpenSSLWarning

    warnings.filterwarnings("ignore", category=NotOpenSSLWarning)
except Exception:  # pragma: no cover
    pass

__version__ = "0.1.0"
