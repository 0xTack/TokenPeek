"""RSS / Atom。用 requests 抓、feedparser 解析，方便控制超时与 UA。"""

from __future__ import annotations

import html
from typing import List

import feedparser

from ..util import parse_dt, strip_html
from .base import Adapter, RawItem, parse_feed_bytes


class RSSAdapter(Adapter):
    kind = "rss"

    def fetch(self) -> List[RawItem]:
        feeds = self.cfg.get("feeds") or []
        per_feed = int(self.cfg.get("limit_per_feed", 8))
        timeout = int(self.cfg.get("timeout", self.cfg.get("request_timeout", 25)))

        items: List[RawItem] = []
        disabled = set(self.cfg.get("disabled") or [])
        for feed in feeds:
            if isinstance(feed, dict):
                url = feed.get("url") or ""
                name = feed.get("name") or ""
                region = feed.get("region") or self.region
            else:
                url, name = str(feed), ""
                region = self.region
            if url in disabled:
                continue
            if not url:
                continue

            try:
                resp = self.session.get(url, timeout=timeout)
                resp.raise_for_status()
            except Exception as exc:
                self.warn("%s 抓取失败: %s" % (url, exc))
                continue

            parsed = parse_feed_bytes(resp.content)
            label = name or (parsed.feed or {}).get("title") or url

            for index, entry in enumerate(parsed.entries[:per_feed]):
                link = entry.get("link") or ""
                if not link:
                    continue
                title = html.unescape(entry.get("title") or "").strip()
                if "live thread" in title.lower():
                    continue
                summary = strip_html(
                    entry.get("summary") or entry.get("description") or "", 400
                )
                published = parse_dt(
                    entry.get("published_parsed")
                    or entry.get("updated_parsed")
                    or entry.get("published")
                    or entry.get("updated")
                )
                items.append(
                    RawItem(
                        source=label,
                        kind=self.kind,
                        url=link,
                        title=title or link,
                        summary=summary,
                        author=entry.get("author") or "",
                        published_at=published,
                        metric=float(max(0, per_feed - index)),
                        region=region,
                    )
                )
        return items
