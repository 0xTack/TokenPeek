"""Reddit。

官方 JSON 接口（/hot.json）现在从不少网络环境会返回 403，
这里改走公开的 hot RSS（稳定得多）。

代价是拿不到点赞数，于是用「在本 sub 的 hot 列表里排第几」当热度代理：
越靠前越热。跨 sub 之间不可比，所以只用于展示，不参与跨源对比。
"""

from __future__ import annotations

import re
import time
from typing import List

import feedparser

from ..util import parse_dt, strip_html
from .base import Adapter, RawItem

MD_RE = re.compile(r'<div class="md">(.*?)</div>', re.S)


class RedditAdapter(Adapter):
    kind = "reddit"

    def _get(self, url: str, limit: int):
        """Reddit 对匿名请求限流很凶，429 要退避重试。"""
        for attempt in range(3):
            if attempt:
                time.sleep(2 * attempt)
            try:
                resp = self.session.get(url, params={"limit": limit}, timeout=20)
            except Exception as exc:
                self.warn("请求失败: %s" % exc)
                continue
            if resp.status_code == 429:
                self.warn("被限流，等待后重试（%d/3）" % (attempt + 1))
                time.sleep(3 * (attempt + 1))
                continue
            if resp.status_code >= 400:
                self.warn("HTTP %d: %s" % (resp.status_code, url))
                return None
            return resp
        return None

    def fetch(self) -> List[RawItem]:
        subreddits = self.cfg.get("subreddits") or []
        limit = int(self.cfg.get("limit", 15))

        items: List[RawItem] = []
        for sub in subreddits:
            url = "https://www.reddit.com/r/%s/hot/.rss" % sub
            resp = self._get(url, limit)
            if resp is None:
                continue

            parsed = feedparser.parse(resp.content)
            if not parsed.entries:
                self.warn("r/%s 没解析到条目（可能被限流）" % sub)
                continue

            for index, entry in enumerate(parsed.entries[:limit]):
                link = (entry.get("link") or "").strip()
                title = (entry.get("title") or "").strip()
                if not link or not title or "live thread" in title.lower():
                    continue

                raw_html = ""
                if entry.get("content"):
                    raw_html = entry["content"][0].get("value", "")
                elif entry.get("summary"):
                    raw_html = entry["summary"]
                match = MD_RE.search(raw_html)
                summary = strip_html(match.group(1) if match else raw_html, 400)
                if summary.lower().startswith("submitted by"):
                    summary = ""

                rank = index + 1
                items.append(
                    RawItem(
                        source="r/%s" % sub,
                        kind=self.kind,
                        url=link,
                        title=title,
                        summary=summary,
                        author=(entry.get("author") or "").replace("/u/", ""),
                        published_at=parse_dt(
                            entry.get("published") or entry.get("updated")
                        ),
                        metric=float(max(1, limit - index)),
                        region=self.region,
                        lang="en",
                        extra={"rank": rank, "discussion": link},
                    )
                )
            time.sleep(1.2)
        return items
