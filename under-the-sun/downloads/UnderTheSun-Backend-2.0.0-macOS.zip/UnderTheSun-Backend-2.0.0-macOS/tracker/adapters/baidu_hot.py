"""百度热搜。页面里内嵌了一段 JSON（<!--s-data:...-->），直接解析。"""

from __future__ import annotations

import json
import re
from typing import List
from urllib.parse import quote

from .base import Adapter, RawItem

DATA_RE = re.compile(r"<!--s-data:(.*?)-->", re.S)


class BaiduHotAdapter(Adapter):
    kind = "hot"

    def fetch(self) -> List[RawItem]:
        limit = int(self.cfg.get("limit", 20))
        try:
            resp = self.session.get(
                "https://top.baidu.com/board", params={"tab": "realtime"}, timeout=20
            )
            resp.raise_for_status()
        except Exception as exc:
            self.warn("抓取失败: %s" % exc)
            return []

        match = DATA_RE.search(resp.text)
        if not match:
            self.warn("页面结构变了，找不到 s-data")
            return []

        try:
            payload = json.loads(match.group(1))
            cards = payload["data"]["cards"][0]["content"]
        except (ValueError, KeyError, IndexError) as exc:
            self.warn("解析失败: %s" % exc)
            return []

        items: List[RawItem] = []
        for rank, card in enumerate(cards[:limit], start=1):
            title = (card.get("word") or card.get("query") or "").strip()
            if not title:
                continue
            items.append(
                RawItem(
                    source="百度热搜",
                    kind=self.kind,
                    url="https://www.baidu.com/s?wd=%s" % quote(title),
                    title=title,
                    summary=(card.get("desc") or "").strip(),
                    metric=float(card.get("hotScore") or 0),
                    region=self.region,
                    lang="zh",
                    extra={"rank": rank},
                )
            )
        return items
