"""小红书热点。

小红书没有公开的热榜接口：网页端要登录 Cookie，而且所有接口都要带 x-s 请求签名，
纯 HTTP 抓取基本拿不到（自己实现签名脚本非常容易失效）。

所以这里走 RSS 镜像：`sources.xiaohongshu_hot.rss_url`。
默认用公开镜像，挂了就换成自建 RSSHub 或别的镜像，接口不变。
"""

from __future__ import annotations

from typing import List

from .base import Adapter, RawItem, items_from_feed


class XiaohongshuHotAdapter(Adapter):
    kind = "hot"

    def fetch(self) -> List[RawItem]:
        rss_url = str(self.cfg.get("rss_url") or "").strip()
        if not rss_url:
            self.warn("没有配置 rss_url，跳过（小红书没有免签名的公开接口）")
            return []

        limit = int(self.cfg.get("limit", 20))
        try:
            return items_from_feed(
                self.session,
                rss_url,
                source="小红书热点",
                region=self.region,
                limit=limit,
            )
        except Exception as exc:
            self.warn("RSS 镜像失败（可能已失效，换一个 rss_url）: %s" % exc)
            return []
