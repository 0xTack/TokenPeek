"""腾讯新闻热榜。公开 JSON，自带 ranking。"""

from __future__ import annotations

from typing import List

from ..util import strip_html
from .base import Adapter, RawItem


class QianwenHotAdapter(Adapter):
    kind = "hot"

    def fetch(self) -> List[RawItem]:
        limit = int(self.cfg.get("limit", 20))
        try:
            resp = self.session.get(
                "https://r.inews.qq.com/gw/event/hot_ranking_list",
                params={"page_size": 50},
                timeout=20,
            )
            resp.raise_for_status()
            payload = resp.json()
            newslist = payload["idlist"][0]["newslist"]
        except Exception as exc:
            self.warn("抓取失败: %s" % exc)
            return []

        items: List[RawItem] = []
        for entry in newslist:
            if len(items) >= limit:
                break
            title = (entry.get("title") or "").strip()
            url = (entry.get("url") or "").strip()
            if not title or not url:
                continue
            if "每10分钟更新" in title:
                continue
            rank = int(entry.get("ranking") or 0)
            items.append(
                RawItem(
                    source="腾讯新闻",
                    kind=self.kind,
                    url=url,
                    title=title,
                    summary=strip_html(entry.get("abstract") or "", 300),
                    metric=float(max(1, limit - len(items))),
                    region=self.region,
                    lang="zh",
                    extra={"rank": rank or (len(items) + 1), "rank_based": True},
                )
            )
        return items
