"""知乎热榜。

走的是移动端公开接口，不需要登录、不需要 Cookie：
    https://api.zhihu.com/topstory/hot-list
返回 30 条，带「xxx 万热度」，正好当排序信号。
"""

from __future__ import annotations

import re
from typing import List

from ..util import strip_html
from .base import Adapter, RawItem

API = "https://api.zhihu.com/topstory/hot-list"
HEAT_RE = re.compile(r"([\d.]+)\s*(亿|万)?")


def _parse_heat(text: str) -> float:
    match = HEAT_RE.search(text or "")
    if not match:
        return 0.0
    value = float(match.group(1))
    unit = match.group(2)
    if unit == "亿":
        return value * 1e8
    if unit == "万":
        return value * 1e4
    return value


class ZhihuHotAdapter(Adapter):
    kind = "hot"

    def fetch(self) -> List[RawItem]:
        limit = int(self.cfg.get("limit", 20))
        cookies = self.cfg.get("_cookies") or {}
        headers = {"Referer": "https://www.zhihu.com/hot"}
        if cookies.get("zhihu"):
            headers["Cookie"] = cookies["zhihu"]
        try:
            resp = self.session.get(
                API,
                params={"limit": limit, "desktop": "false"},
                headers=headers,
                timeout=20,
            )
            resp.raise_for_status()
            payload = resp.json()
        except Exception as exc:
            self.warn("抓取失败: %s" % exc)
            return []

        items: List[RawItem] = []
        for rank, entry in enumerate((payload.get("data") or [])[:limit], start=1):
            target = entry.get("target") or {}
            title = (target.get("title") or "").strip()
            if not title:
                continue
            question_id = target.get("id")
            label = ((entry.get("card_label") or {}).get("type") or "")
            items.append(
                RawItem(
                    source="知乎热榜",
                    kind=self.kind,
                    url="https://www.zhihu.com/question/%s" % question_id,
                    title=title,
                    summary=strip_html(target.get("excerpt") or "", 300),
                    metric=_parse_heat(entry.get("detail_text") or ""),
                    region=self.region,
                    lang="zh",
                    extra={"rank": rank, "label": label},
                )
            )
        return items
