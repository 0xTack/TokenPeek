"""抖音热榜。旧版公开接口仍可用，带 hot_value。"""

from __future__ import annotations

from typing import List
from urllib.parse import quote

from .base import Adapter, RawItem


class DouyinHotAdapter(Adapter):
    kind = "hot"

    def fetch(self) -> List[RawItem]:
        limit = int(self.cfg.get("limit", 20))
        try:
            resp = self.session.get(
                "https://www.iesdouyin.com/web/api/v2/hotsearch/billboard/word/",
                timeout=20,
            )
            resp.raise_for_status()
            payload = resp.json()
            words = payload.get("word_list") or []
        except Exception as exc:
            self.warn("抓取失败: %s" % exc)
            return []

        items: List[RawItem] = []
        for rank, entry in enumerate(words[:limit], start=1):
            title = (entry.get("word") or "").strip()
            if not title:
                continue
            items.append(
                RawItem(
                    source="抖音热榜",
                    kind=self.kind,
                    url="https://www.douyin.com/search/%s" % quote(title),
                    title=title,
                    summary="",
                    metric=float(entry.get("hot_value") or 0),
                    region=self.region,
                    lang="zh",
                    extra={"rank": rank},
                )
            )
        return items
