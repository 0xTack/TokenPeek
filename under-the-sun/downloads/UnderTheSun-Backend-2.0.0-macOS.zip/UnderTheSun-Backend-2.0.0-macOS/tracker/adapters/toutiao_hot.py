"""今日头条热榜。公开 JSON 接口，带 HotValue。"""

from __future__ import annotations

from typing import List

from .base import Adapter, RawItem


class ToutiaoHotAdapter(Adapter):
    kind = "hot"

    def fetch(self) -> List[RawItem]:
        limit = int(self.cfg.get("limit", 20))
        try:
            resp = self.session.get(
                "https://www.toutiao.com/hot-event/hot-board/",
                params={"origin": "toutiao_pc"},
                timeout=20,
            )
            resp.raise_for_status()
            payload = resp.json()
        except Exception as exc:
            self.warn("抓取失败: %s" % exc)
            return []

        items: List[RawItem] = []
        for rank, entry in enumerate((payload.get("data") or [])[:limit], start=1):
            title = (entry.get("Title") or "").strip()
            if not title:
                continue
            items.append(
                RawItem(
                    source="头条热榜",
                    kind=self.kind,
                    url="https://www.toutiao.com/trending/%s/"
                    % (entry.get("ClusterIdStr") or entry.get("ClusterId") or ""),
                    title=title,
                    summary="",
                    metric=float(entry.get("HotValue") or 0),
                    region=self.region,
                    lang="zh",
                    extra={"rank": rank, "label": entry.get("LabelDesc") or ""},
                )
            )
        return items
