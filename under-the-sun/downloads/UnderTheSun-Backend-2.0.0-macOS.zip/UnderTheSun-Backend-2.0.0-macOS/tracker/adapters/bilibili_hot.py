"""B 站热搜。公开接口，带 heat_score。"""

from __future__ import annotations

from typing import List
from urllib.parse import quote

from .base import Adapter, RawItem


class BilibiliHotAdapter(Adapter):
    kind = "hot"

    def fetch(self) -> List[RawItem]:
        limit = int(self.cfg.get("limit", 20))
        try:
            resp = self.session.get(
                "https://api.bilibili.com/x/web-interface/search/square",
                params={"limit": limit},
                timeout=20,
            )
            resp.raise_for_status()
            payload = resp.json()
            trending = (payload.get("data") or {}).get("trending") or {}
            entries = trending.get("list") or []
        except Exception as exc:
            self.warn("抓取失败: %s" % exc)
            return []

        items: List[RawItem] = []
        for rank, entry in enumerate(entries[:limit], start=1):
            title = (entry.get("show_name") or entry.get("keyword") or "").strip()
            if not title:
                continue
            keyword = entry.get("keyword") or title
            items.append(
                RawItem(
                    source="B站热搜",
                    kind=self.kind,
                    url="https://search.bilibili.com/all?keyword=%s" % quote(keyword),
                    title=title,
                    summary="",
                    metric=float(entry.get("heat_score") or 0),
                    region=self.region,
                    lang="zh",
                    extra={"rank": rank},
                )
            )
        return items
