"""Hacker News 官方 API。有原生分数，是最好的排序信号来源。"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from typing import List, Optional

from ..util import parse_dt, strip_html
from .base import Adapter, RawItem

API = "https://hacker-news.firebaseio.com/v0"


class HNAdapter(Adapter):
    kind = "hn"

    def _get(self, item_id: int) -> Optional[dict]:
        try:
            resp = self.session.get(
                "%s/item/%s.json" % (API, item_id), timeout=15
            )
            if resp.status_code != 200:
                return None
            return resp.json()
        except Exception:
            return None

    def fetch(self) -> List[RawItem]:
        limit = int(self.cfg.get("limit", 30))
        min_score = float(self.cfg.get("min_score", 0))
        try:
            resp = self.session.get("%s/topstories.json" % API, timeout=15)
            resp.raise_for_status()
            ids = (resp.json() or [])[:limit]
        except Exception as exc:
            self.warn("topstories 失败: %s" % exc)
            return []

        items: List[RawItem] = []
        with ThreadPoolExecutor(max_workers=8) as pool:
            for data in pool.map(self._get, ids):
                if not data:
                    continue
                if data.get("type") != "story" or data.get("dead") or data.get("deleted"):
                    continue
                score = float(data.get("score") or 0)
                if score < min_score:
                    continue
                discussion = "https://news.ycombinator.com/item?id=%s" % data.get("id")
                items.append(
                    RawItem(
                        source="Hacker News",
                        kind=self.kind,
                        url=data.get("url") or discussion,
                        title=data.get("title") or "",
                        summary=strip_html(data.get("text") or "", 400),
                        author=data.get("by") or "",
                        published_at=parse_dt(data.get("time")),
                        metric=score,
                        region=self.region,
                        lang="en",
                        extra={
                            "discussion": discussion,
                            "comments": int(data.get("descendants") or 0),
                        },
                    )
                )
        return items
