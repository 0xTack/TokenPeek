"""适配器基类和注册表。"""

from __future__ import annotations

import html
import sys
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

import feedparser
import requests

from ..util import parse_dt, strip_html


@dataclass
class RawItem:
    source: str
    kind: str
    url: str
    title: str
    summary: str = ""
    author: str = ""
    published_at: Optional[datetime] = None
    metric: float = 0.0
    region: str = "cn"          # cn / intl
    lang: str = ""              # zh / en，留空自动判断
    extra: Dict[str, Any] = field(default_factory=dict)


class Adapter:
    kind = "base"

    def __init__(self, name: str, cfg: Dict[str, Any], session: requests.Session):
        self.name = name
        self.cfg = cfg or {}
        self.session = session
        self.last_warning = ""

    @property
    def label(self) -> str:
        return self.cfg.get("label") or self.name

    @property
    def region(self) -> str:
        return self.cfg.get("region") or "cn"

    def fetch(self) -> List[RawItem]:
        raise NotImplementedError

    def warn(self, message: str) -> None:
        self.last_warning = message
        sys.stderr.write("[warn] %s: %s\n" % (self.name, message))


def build_session(http_cfg: Dict[str, Any]) -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": http_cfg.get(
                "user_agent",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
                " (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
            ),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        }
    )
    proxy = http_cfg.get("proxy")
    if proxy:
        session.proxies.update({"http": proxy, "https": proxy})
    return session


def parse_feed_bytes(data: bytes):
    """有些镜像源声明了错误编码，先统一成 UTF-8 再解析，避免整段乱码。"""
    import re

    cleaned = re.sub(
        rb'encoding\s*=\s*["\'][^"\'>]+["\']', b'encoding="utf-8"', data, count=1
    )
    return feedparser.parse(cleaned)


def items_from_feed(
    session: requests.Session,
    url: str,
    source: str,
    region: str = "cn",
    limit: int = 20,
) -> List[RawItem]:
    """把一个 RSS/Atom 镜像包装成热榜条目（排名当热度，越靠前越热）。"""
    resp = session.get(url, timeout=25)
    resp.raise_for_status()
    parsed = parse_feed_bytes(resp.content)

    items: List[RawItem] = []
    for index, entry in enumerate(parsed.entries[:limit]):
        link = (entry.get("link") or "").strip()
        title = html.unescape(entry.get("title") or "").strip()
        if not link or not title:
            continue
        summary = entry.get("summary") or entry.get("description") or ""
        items.append(
            RawItem(
                source=source,
                kind="hot",
                url=link,
                title=title,
                summary=strip_html(summary, 300),
                published_at=parse_dt(
                    entry.get("published_parsed") or entry.get("updated_parsed")
                ),
                metric=float(max(1, limit - index)),
                region=region,
                lang="zh",
                extra={"rank": index + 1, "rank_based": True},
            )
        )
    return items


def build_adapters(
    config, session: requests.Session, include_disabled: bool = False
) -> List[Adapter]:
    from .baidu_hot import BaiduHotAdapter
    from .bilibili_hot import BilibiliHotAdapter
    from .douyin_hot import DouyinHotAdapter
    from .github_trending import GitHubTrendingAdapter
    from .hn import HNAdapter
    from .qq_hot import QianwenHotAdapter
    from .reddit import RedditAdapter
    from .rss import RSSAdapter
    from .toutiao_hot import ToutiaoHotAdapter
    from .weibo_hot import WeiboHotAdapter
    from .xiaohongshu_hot import XiaohongshuHotAdapter
    from .zhihu_hot import ZhihuHotAdapter

    registry = [
        ("baidu_hot", BaiduHotAdapter),
        ("toutiao_hot", ToutiaoHotAdapter),
        ("qq_hot", QianwenHotAdapter),
        ("weibo_hot", WeiboHotAdapter),
        ("zhihu_hot", ZhihuHotAdapter),
        ("xiaohongshu_hot", XiaohongshuHotAdapter),
        ("bilibili_hot", BilibiliHotAdapter),
        ("douyin_hot", DouyinHotAdapter),
        ("hackernews", HNAdapter),
        ("github_trending", GitHubTrendingAdapter),
        ("reddit", RedditAdapter),
        ("rss", RSSAdapter),
    ]

    adapters = []
    sources_cfg = config.section("sources")
    cookies = config.section("cookies")
    for key, cls in registry:
        cfg = dict(sources_cfg.get(key) or {})
        if not cfg.get("enabled", False) and not include_disabled:
            continue
        cfg["_cookies"] = cookies
        adapters.append(cls(key, cfg, session))
    return adapters
