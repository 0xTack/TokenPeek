"""GitHub Trending。官方没有 API，这里解析 HTML（结构简单，坏了好修）。"""

from __future__ import annotations

import re
from typing import List

from ..util import strip_html
from .base import Adapter, RawItem

ROW_RE = re.compile(r'<h2[^>]*>.*?<a[^>]*href="/([^"]+)"', re.S)
DESC_RE = re.compile(r"<p[^>]*>(.*?)</p>", re.S)
STARS_RE = re.compile(r"([\d,]+)\s+stars?\s+today", re.I)


class GitHubTrendingAdapter(Adapter):
    kind = "github"

    def fetch(self) -> List[RawItem]:
        limit = int(self.cfg.get("limit", 20))
        language = (self.cfg.get("language") or "").strip()
        params = {"since": "daily"}
        if language:
            params["language"] = language

        try:
            resp = self.session.get(
                "https://github.com/trending", params=params, timeout=25
            )
            resp.raise_for_status()
        except Exception as exc:
            self.warn("trending 抓取失败: %s" % exc)
            return []

        blocks = resp.text.split('class="Box-row"')[1:]
        items: List[RawItem] = []
        for block in blocks[:limit]:
            match = ROW_RE.search(block)
            if not match:
                continue
            repo = match.group(1).strip("/")
            if repo.count("/") != 1:
                continue

            desc = DESC_RE.search(block)
            stars = STARS_RE.search(block)
            metric = float(stars.group(1).replace(",", "")) if stars else 0.0

            summary = strip_html(desc.group(1), 300) if desc else ""
            # trending 的 <p> 里混了 "Sponsor" / "Star" 按钮文字和仓库名
            summary = re.sub(r"^(?:Sponsor|Star|Built by)\s*", "", summary)
            summary = re.sub(r"^(?:Sponsor|Star|Built by)\s*", "", summary)
            spaced_repo = repo.replace("/", " / ")
            if summary.startswith(spaced_repo):
                summary = summary[len(spaced_repo):].strip(" -–—·:")
            items.append(
                RawItem(
                    source="GitHub Trending",
                    kind=self.kind,
                    url="https://github.com/%s" % repo,
                    title=repo,
                    summary=summary,
                    metric=metric,
                    region=self.region,
                    lang="en",
                    extra={"stars_today": metric},
                )
            )
        return items
