"""微博热搜。

官方接口需要登录 Cookie（`SUB` 那一串），不登录会 403。
所以两种模式：

1. 配了 `cookie` → 走官方 ajax 接口，条目带真实热度值；
2. 没配 cookie → 走 `fallback_rss` 的 RSS 镜像，只有排名、没有热度值。

Cookie 获取：浏览器登录 weibo.com → F12 → Network → 刷新 → 任意请求的
Request Headers 里复制整段 `Cookie:`（至少要有 SUB 和 SUBP）。
"""

from __future__ import annotations

from typing import List
from urllib.parse import quote

from .base import Adapter, RawItem, items_from_feed


class WeiboHotAdapter(Adapter):
    kind = "hot"

    def fetch(self) -> List[RawItem]:
        cookies = self.cfg.get("_cookies") or {}
        cookie = str(self.cfg.get("cookie") or cookies.get("weibo") or "").strip()
        if cookie:
            items = self._from_api(cookie)
            if items:
                return items
            self.warn("官方接口没拿到数据，回退到 RSS 镜像")

        rss_url = str(self.cfg.get("fallback_rss") or "").strip()
        if not rss_url:
            self.warn("没有 Cookie 也没有配置 fallback_rss，跳过")
            return []

        try:
            return items_from_feed(
                self.session,
                rss_url,
                source="微博热搜",
                region=self.region,
                limit=int(self.cfg.get("limit", 20)),
            )
        except Exception as exc:
            self.warn("RSS 镜像失败: %s" % exc)
            return []

    def _from_api(self, cookie: str) -> List[RawItem]:
        limit = int(self.cfg.get("limit", 20))
        headers = {"Referer": "https://weibo.com/", "Cookie": cookie}
        try:
            resp = self.session.get(
                "https://weibo.com/ajax/side/hotSearch", headers=headers, timeout=20
            )
            resp.raise_for_status()
            payload = resp.json()
        except Exception as exc:
            self.warn("官方接口失败（Cookie 可能过期）: %s" % exc)
            return []

        realtime = ((payload.get("data") or {}).get("realtime")) or []
        items: List[RawItem] = []
        for rank, entry in enumerate(realtime[:limit], start=1):
            title = (entry.get("word") or "").strip()
            if not title or entry.get("is_ad"):
                continue
            items.append(
                RawItem(
                    source="微博热搜",
                    kind=self.kind,
                    url="https://s.weibo.com/weibo?q=%s" % quote("#%s#" % title),
                    title=title,
                    summary=(entry.get("note") or "").strip(),
                    metric=float(entry.get("num") or 0),
                    region=self.region,
                    lang="zh",
                    extra={"rank": rank, "label": entry.get("label_name") or ""},
                )
            )
        return items
