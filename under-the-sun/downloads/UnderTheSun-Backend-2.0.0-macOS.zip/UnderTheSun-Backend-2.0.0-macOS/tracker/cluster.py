"""跨源聚类：把「同一件事」的多条报道合并成一组。

没有用 embedding，先用标题 token 的 Jaccard 相似度做贪心聚类。
好处是无外部依赖、可解释、跑几百条只要几毫秒；
以后要更准，把 tokens/jaccard 换成向量余弦即可，接口不变。
"""

from __future__ import annotations

import sqlite3
from typing import List, Optional

from .util import iso_now, jaccard, tokens


def containment(a, b) -> float:
    """包含度：一个标题是另一个的子集时，Jaccard 会很低，但显然是同一件事。"""
    if not a or not b:
        return 0.0
    inter = len(a & b)
    if not inter:
        return 0.0
    return inter / float(min(len(a), len(b)))


def similar(a, b, threshold: float) -> bool:
    if jaccard(a, b) >= threshold:
        return True
    if min(len(a), len(b)) >= 3 and containment(a, b) >= 0.78:
        return True
    return False


def assign(
    conn: sqlite3.Connection,
    since_iso: str,
    threshold: float = 0.5,
    keep_separate: Optional[set] = None,
) -> int:
    keep_separate = keep_separate or set()
    rows = conn.execute(
        """
        SELECT id, title, source, metric, fetched_at
        FROM items
        WHERE fetched_at >= ?
        ORDER BY id
        """,
        (since_iso,),
    ).fetchall()

    conn.execute("UPDATE items SET cluster_id = NULL WHERE fetched_at >= ?", (since_iso,))
    conn.execute("DELETE FROM clusters")
    conn.commit()

    if not rows:
        return 0

    groups: List[dict] = []
    for row in rows:
        toks = tokens(row["title"])
        best = None

        if row["source"] in keep_separate:
            groups.append({"members": [row], "toks": [toks], "size": len(toks)})
            continue

        if toks:
            for group in groups:
                size = group["size"]
                if abs(len(toks) - size) > max(6, 0.8 * max(len(toks), size)):
                    continue
                if any(similar(toks, known, threshold) for known in group["toks"][:4]):
                    best = group
                    break

        if best is not None:
            best["members"].append(row)
            best["toks"].append(toks)
            best["size"] = max(best["size"], len(toks))
        else:
            groups.append({"members": [row], "toks": [toks], "size": len(toks)})

    now = iso_now()
    for group in groups:
        members = group["members"]
        representative = max(members, key=lambda r: (float(r["metric"] or 0), -int(r["id"])))
        cur = conn.execute(
            """
            INSERT INTO clusters (title, score, metric, source_count, item_count, latest, topic, created_at)
            VALUES (?, 0, 0, ?, ?, NULL, '其他', ?)
            """,
            (representative["title"], len({m["source"] for m in members}), len(members), now),
        )
        cluster_id = cur.lastrowid
        conn.executemany(
            "UPDATE items SET cluster_id = ? WHERE id = ?",
            [(cluster_id, m["id"]) for m in members],
        )

    conn.commit()
    return len(groups)
