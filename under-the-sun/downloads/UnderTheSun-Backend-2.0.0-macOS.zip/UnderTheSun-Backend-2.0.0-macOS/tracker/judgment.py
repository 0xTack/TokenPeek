"""判断卡：把一次性的 AI 评价变成可检验、可版本化的判断。

一张判断卡包含：
    问题 / 判断类型 / 判断 / 置信度 / 有效期 / 适用范围
    事实 / 推理 / 前提 / 成立条件 / 证伪条件 / 反方 / 未知 / 跟踪信号

判断本身不自动改。用户确认后保存为 v1；以后结合新事实复核时，
生成 v2、v3……旧版本全部保留，方便回看「当时为什么这么判断」。
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Optional

from .util import iso_now

CARD_TYPES = ["预测", "因果", "利益归属", "价值排序", "重要性"]
CARD_STATUSES = ["观察中", "加强", "削弱", "已修正", "已证伪", "已过期"]

# 这些字段在数据库里用 JSON 文本存
LIST_FIELDS = ("facts", "reasoning", "assumptions", "confirm_if", "falsifiers", "unknowns", "watch")

FIELD_NAMES = (
    "question",
    "claim_type",
    "claim",
    "confidence",
    "confidence_note",
    "horizon",
    "scope",
    "source_quality",
    "facts",
    "reasoning",
    "assumptions",
    "confirm_if",
    "falsifiers",
    "counter",
    "unknowns",
    "watch",
)


def _dumps(value: Any) -> str:
    return json.dumps(value if value is not None else [], ensure_ascii=False)


def _loads(value: Any, default: Any = None) -> Any:
    if value is None or value == "":
        return default
    if isinstance(value, (list, dict)):
        return value
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return default


def normalize_card(card: Dict[str, Any]) -> Dict[str, Any]:
    """只留下判断卡认识的字段，顺手把列表字段清洗成字符串列表。"""
    out: Dict[str, Any] = {}
    for name in FIELD_NAMES:
        value = card.get(name)
        if name in LIST_FIELDS:
            if isinstance(value, str):
                value = [line.strip() for line in value.split("\n") if line.strip()]
            if not isinstance(value, list):
                value = []
            out[name] = [str(item).strip() for item in value if str(item).strip()]
        elif name == "source_quality":
            if isinstance(value, str):
                value = {"level": "", "reason": value}
            if not isinstance(value, dict):
                value = {"level": "", "reason": ""}
            out[name] = {
                "level": str(value.get("level") or ""),
                "reason": str(value.get("reason") or ""),
            }
        elif name == "confidence":
            try:
                number = int(float(value))
            except (TypeError, ValueError):
                number = 50
            out[name] = max(0, min(100, number))
        else:
            out[name] = str(value or "").strip()

    if out["claim_type"] not in CARD_TYPES:
        out["claim_type"] = "重要性"
    return out


def _row_to_card(row: sqlite3.Row) -> Dict[str, Any]:
    card: Dict[str, Any] = {}
    for name in FIELD_NAMES:
        column = "watch_signals" if name == "watch" else name
        if name in LIST_FIELDS:
            card[name] = _loads(row[column], [])
        elif name == "source_quality":
            card[name] = _loads(row[column], {})
        elif name == "confidence":
            card[name] = int(row[column] or 0)
        else:
            card[name] = row[column] or ""
    return card


def _insert_version(
    conn: sqlite3.Connection,
    judgment_id: int,
    version: int,
    card: Dict[str, Any],
    change_reason: str,
    trigger_item_id: Optional[int],
) -> None:
    conn.execute(
        """
        INSERT INTO judgment_versions
            (judgment_id, version, claim_type, claim, confidence, payload,
             change_reason, trigger_item_id, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            judgment_id,
            version,
            card.get("claim_type") or "",
            card.get("claim") or "",
            int(card.get("confidence") or 0),
            _dumps(card),
            change_reason or "",
            trigger_item_id,
            iso_now(),
        ),
    )


def create_judgment(
    conn: sqlite3.Connection,
    item_id: int,
    card: Dict[str, Any],
    watch_id: Optional[int] = None,
    change_reason: str = "初始判断",
    status: str = "观察中",
) -> int:
    card = normalize_card(card)
    if status not in CARD_STATUSES:
        status = "观察中"
    now = iso_now()
    cur = conn.execute(
        """
        INSERT INTO judgments
            (item_id, watch_id, question, claim_type, claim, confidence,
             confidence_note, horizon, scope, source_quality, facts, reasoning,
             assumptions, confirm_if, falsifiers, counter, unknowns, watch_signals,
             status, version, created_at, updated_at, active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 1)
        """,
        (
            item_id,
            watch_id,
            card["question"],
            card["claim_type"],
            card["claim"],
            card["confidence"],
            card["confidence_note"],
            card["horizon"],
            card["scope"],
            _dumps(card["source_quality"]),
            _dumps(card["facts"]),
            _dumps(card["reasoning"]),
            _dumps(card["assumptions"]),
            _dumps(card["confirm_if"]),
            _dumps(card["falsifiers"]),
            card["counter"],
            _dumps(card["unknowns"]),
            _dumps(card["watch"]),
            status,
            now,
            now,
        ),
    )
    judgment_id = int(cur.lastrowid)
    _insert_version(conn, judgment_id, 1, card, change_reason, item_id)
    conn.commit()
    return judgment_id


def update_judgment(
    conn: sqlite3.Connection,
    judgment_id: int,
    card: Dict[str, Any],
    change_reason: str = "",
    trigger_item_id: Optional[int] = None,
    status: Optional[str] = None,
) -> int:
    row = conn.execute("SELECT * FROM judgments WHERE id = ?", (judgment_id,)).fetchone()
    if row is None:
        raise ValueError("判断不存在：%s" % judgment_id)

    card = normalize_card(card)
    version = int(row["version"] or 1) + 1
    new_status = status or row["status"] or "观察中"
    if new_status not in CARD_STATUSES:
        new_status = "观察中"
    now = iso_now()

    conn.execute(
        """
        UPDATE judgments
        SET question = ?, claim_type = ?, claim = ?, confidence = ?,
            confidence_note = ?, horizon = ?, scope = ?, source_quality = ?,
            facts = ?, reasoning = ?, assumptions = ?, confirm_if = ?,
            falsifiers = ?, counter = ?, unknowns = ?, watch_signals = ?,
            status = ?, version = ?, updated_at = ?
        WHERE id = ?
        """,
        (
            card["question"],
            card["claim_type"],
            card["claim"],
            card["confidence"],
            card["confidence_note"],
            card["horizon"],
            card["scope"],
            _dumps(card["source_quality"]),
            _dumps(card["facts"]),
            _dumps(card["reasoning"]),
            _dumps(card["assumptions"]),
            _dumps(card["confirm_if"]),
            _dumps(card["falsifiers"]),
            card["counter"],
            _dumps(card["unknowns"]),
            _dumps(card["watch"]),
            new_status,
            version,
            now,
            judgment_id,
        ),
    )
    _insert_version(conn, judgment_id, version, card, change_reason, trigger_item_id)
    conn.commit()
    return version


def get_judgment(conn: sqlite3.Connection, judgment_id: int) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM judgments WHERE id = ?", (judgment_id,)).fetchone()


def get_by_item(conn: sqlite3.Connection, item_id: int) -> Optional[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM judgments WHERE item_id = ? AND active = 1"
        " ORDER BY id DESC LIMIT 1",
        (item_id,),
    ).fetchone()


def list_judgments(
    conn: sqlite3.Connection, active_only: bool = True, limit: int = 50
) -> List[sqlite3.Row]:
    sql = """
        SELECT j.*, i.title AS item_title, i.url AS item_url, i.source AS item_source
        FROM judgments j
        LEFT JOIN items i ON i.id = j.item_id
    """
    if active_only:
        sql += " WHERE j.active = 1"
    sql += " ORDER BY j.updated_at DESC, j.id DESC LIMIT ?"
    return conn.execute(sql, (limit,)).fetchall()


def latest_version(conn: sqlite3.Connection, judgment_id: int) -> Optional[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM judgment_versions WHERE judgment_id = ?"
        " ORDER BY version DESC LIMIT 1",
        (judgment_id,),
    ).fetchone()


def previous_version(conn: sqlite3.Connection, judgment_id: int) -> Optional[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM judgment_versions WHERE judgment_id = ?"
        " ORDER BY version DESC LIMIT 1 OFFSET 1",
        (judgment_id,),
    ).fetchone()


def list_versions(conn: sqlite3.Connection, judgment_id: int) -> List[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM judgment_versions WHERE judgment_id = ? ORDER BY version ASC",
        (judgment_id,),
    ).fetchall()


def add_evidence(
    conn: sqlite3.Connection,
    judgment_id: int,
    item_id: int,
    stance: str = "neutral",
    note: str = "",
    source: str = "user",
) -> None:
    if stance not in ("support", "contradict", "neutral"):
        stance = "neutral"
    conn.execute(
        "INSERT OR REPLACE INTO judgment_evidence"
        " (judgment_id, item_id, stance, note, source, created_at)"
        " VALUES (?, ?, ?, ?, ?, ?)",
        (judgment_id, item_id, stance, note, source, iso_now()),
    )
    conn.commit()


def list_evidence(conn: sqlite3.Connection, judgment_id: int) -> List[sqlite3.Row]:
    return conn.execute(
        """
        SELECT e.*, i.title, i.url, i.source AS item_source, i.summary
        FROM judgment_evidence e
        LEFT JOIN items i ON i.id = e.item_id
        WHERE e.judgment_id = ?
        ORDER BY e.created_at DESC
        """,
        (judgment_id,),
    ).fetchall()


def evidence_counts(conn: sqlite3.Connection, judgment_id: int) -> Dict[str, int]:
    counts = {"support": 0, "contradict": 0, "neutral": 0}
    rows = conn.execute(
        "SELECT stance, COUNT(*) AS n FROM judgment_evidence"
        " WHERE judgment_id = ? GROUP BY stance",
        (judgment_id,),
    ).fetchall()
    for row in rows:
        stance = str(row["stance"] or "neutral")
        if stance not in counts:
            stance = "neutral"
        counts[stance] += int(row["n"] or 0)
    return counts


def classify_pending(conn: sqlite3.Connection, cfg, ai) -> int:
    """给跟踪到的新事实自动标「支持 / 反驳 / 无关」，返回本次归类条数。

    只处理判断创建之后出现的进展，每条判断每次最多处理 N 条，
    避免一次运行把历史更新全部送进模型。
    """
    if ai is None or not ai.available():
        return 0

    section = cfg.section("judgment") if cfg is not None else {}
    if not bool(section.get("auto_evidence", True)):
        return 0
    try:
        limit = max(1, int(section.get("evidence_per_run", 5)))
    except (TypeError, ValueError):
        limit = 5

    rows = conn.execute(
        """
        SELECT j.*, i.title AS item_title
        FROM judgments j
        LEFT JOIN items i ON i.id = j.item_id
        WHERE j.active = 1 AND j.watch_id IS NOT NULL
        ORDER BY j.updated_at DESC, j.id DESC
        """
    ).fetchall()

    total = 0
    for row in rows:
        pending = conn.execute(
            """
            SELECT i.id, i.title, i.source, i.summary, u.created_at
            FROM watch_updates u
            JOIN items i ON i.id = u.item_id
            LEFT JOIN judgment_evidence e
                   ON e.judgment_id = ? AND e.item_id = i.id
            WHERE u.watch_id = ?
              AND e.item_id IS NULL
              AND u.created_at >= ?
            ORDER BY u.created_at DESC
            LIMIT ?
            """,
            (
                int(row["id"]),
                int(row["watch_id"]),
                row["created_at"] or "",
                limit,
            ),
        ).fetchall()
        if not pending:
            continue

        facts = [
            {
                "id": int(item["id"]),
                "title": item["title"] or "",
                "source": item["source"] or "",
                "summary": item["summary"] or "",
            }
            for item in pending
        ]
        verdicts = ai.classify_evidence(
            card_of(row), facts, title=row["item_title"] or ""
        )
        if not verdicts:
            continue

        for index, fact in enumerate(facts):
            verdict = verdicts.get(index)
            if not verdict:
                continue
            add_evidence(
                conn,
                int(row["id"]),
                int(fact["id"]),
                stance=verdict.get("stance") or "neutral",
                note=verdict.get("note") or "",
                source="ai",
            )
            total += 1
    return total


def card_of(row: sqlite3.Row) -> Dict[str, Any]:
    return _row_to_card(row)


def summary_of(conn: sqlite3.Connection, row: sqlite3.Row) -> Dict[str, Any]:
    version = latest_version(conn, int(row["id"]))
    card = card_of(row)
    keys = set(row.keys())
    if "item_title" in keys:
        title = row["item_title"] or ""
        url = row["item_url"] or ""
        source = row["item_source"] or ""
    else:
        item = conn.execute(
            "SELECT title, url, source FROM items WHERE id = ?", (row["item_id"],)
        ).fetchone()
        title = item["title"] if item else ""
        url = item["url"] if item else ""
        source = item["source"] if item else ""
    return {
        "id": int(row["id"]),
        "item_id": int(row["item_id"] or 0),
        "title": title,
        "url": url,
        "source": source,
        "question": card["question"],
        "claim_type": card["claim_type"],
        "claim": card["claim"],
        "confidence": card["confidence"],
        "confidence_note": card["confidence_note"],
        "horizon": card["horizon"],
        "status": row["status"] or "观察中",
        "version": int(row["version"] or 1),
        "created_at": row["created_at"] or "",
        "updated_at": row["updated_at"] or "",
        "change_reason": (version["change_reason"] if version else "") or "",
        "source_quality": card["source_quality"],
        "confirm_if": card["confirm_if"],
        "falsifiers": card["falsifiers"],
        "counter": card["counter"],
        "evidence_counts": evidence_counts(conn, int(row["id"])),
    }


def status_list(conn: sqlite3.Connection, limit: int = 20) -> List[Dict[str, Any]]:
    return [summary_of(conn, row) for row in list_judgments(conn, limit=limit)]


def changes_for_day(conn: sqlite3.Connection, day: str) -> List[Dict[str, Any]]:
    """今天新建、修订或加过证据的判断。日报的「判断动态」只显示这些。"""
    rows = conn.execute(
        """
        SELECT DISTINCT j.*, i.title AS item_title, i.url AS item_url,
               i.source AS item_source
        FROM judgments j
        LEFT JOIN judgment_versions v ON v.judgment_id = j.id
        LEFT JOIN judgment_evidence e ON e.judgment_id = j.id
        LEFT JOIN items i ON i.id = j.item_id
        WHERE j.active = 1
          AND (substr(v.created_at, 1, 10) = ? OR substr(e.created_at, 1, 10) = ?)
        ORDER BY j.updated_at DESC, j.id DESC
        """,
        (day, day),
    ).fetchall()

    out: List[Dict[str, Any]] = []
    for row in rows:
        latest = latest_version(conn, int(row["id"]))
        previous = previous_version(conn, int(row["id"]))
        out.append(
            {
                "summary": summary_of(conn, row),
                "latest": _loads(latest["payload"], {}) if latest else {},
                "previous": _loads(previous["payload"], {}) if previous else {},
                "change_reason": (latest["change_reason"] if latest else "") or "",
                "evidence": [
                    {
                        "item_id": int(e["item_id"]),
                        "stance": e["stance"] or "neutral",
                        "note": e["note"] or "",
                        "title": e["title"] or "",
                        "url": e["url"] or "",
                        "source": e["item_source"] or "",
                        "created_at": e["created_at"] or "",
                    }
                    for e in list_evidence(conn, int(row["id"]))
                    if (e["created_at"] or "")[:10] == day
                ][:8],
            }
        )
    return out
