"""纯工具函数：URL 归一化、标题分词、时间解析、文本清洗。"""

from __future__ import annotations

import calendar
import hashlib
import html
import re
import unicodedata
from datetime import datetime, timezone
from typing import Iterable, Optional, Set
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

TRACKING_KEYS = {
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
    "utm_id", "utm_name", "utm_reader", "fbclid", "gclid", "dclid",
    "msclkid", "mc_cid", "mc_eid", "ref", "ref_src", "ref_url",
    "spm", "from", "source", "share_token", "share_source",
    "isappinstalled", "sk", "si", "feature", "trk", "_hsenc", "_hsmi",
}

STOPWORDS = {
    "the", "a", "an", "and", "or", "but", "of", "to", "in", "on", "for",
    "with", "at", "by", "from", "is", "are", "was", "were", "be", "been",
    "it", "its", "this", "that", "these", "those", "as", "how", "why",
    "what", "when", "who", "will", "can", "could", "should", "would",
    "new", "now", "just", "about", "into", "over", "after", "more",
    "his", "her", "their", "our", "your", "you", "we", "they", "not",
    "no", "yes", "best", "top", "vs", "via",
}


def canonical_url(url: str) -> str:
    """去掉跟踪参数、统一 scheme/host、去掉尾斜杠和 fragment。"""
    if not url:
        return ""
    url = html.unescape(str(url).strip())
    try:
        parts = urlsplit(url)
    except ValueError:
        return url
    if not parts.scheme or not parts.netloc:
        return url

    scheme = parts.scheme.lower()
    if scheme in ("http", "https"):
        scheme = "https"
    netloc = parts.netloc.lower()
    if netloc.startswith("www."):
        netloc = netloc[4:]

    path = re.sub(r"/+$", "", parts.path) or "/"

    query = []
    for key, value in parse_qsl(parts.query, keep_blank_values=True):
        if key.lower() in TRACKING_KEYS:
            continue
        if key.lower().startswith("utm_"):
            continue
        query.append((key, value))
    query.sort()

    return urlunsplit((scheme, netloc, path, urlencode(query), ""))


def url_hash(url: str) -> str:
    return hashlib.sha1(canonical_url(url).encode("utf-8")).hexdigest()


def normalize_title(title: str) -> str:
    text = unicodedata.normalize("NFKC", title or "").lower()
    text = re.sub(r"https?://\S+", " ", text)
    text = re.sub(r"[^\w\u4e00-\u9fff]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def tokens(text: str) -> Set[str]:
    """英文按词，中文按字 bigram —— 对跨源同题足够用。"""
    normalized = normalize_title(text)
    out: Set[str] = set()

    for word in re.findall(r"[a-z][a-z0-9]{1,}", normalized):
        if len(word) >= 2 and word not in STOPWORDS:
            out.add(word)

    for run in re.findall(r"[\u4e00-\u9fff]+", normalized):
        if len(run) == 1:
            out.add(run)
        else:
            for i in range(len(run) - 1):
                out.add(run[i:i + 2])

    return out


def jaccard(a: Set[str], b: Set[str]) -> float:
    if not a or not b:
        return 0.0
    inter = len(a & b)
    if not inter:
        return 0.0
    return inter / float(len(a) + len(b) - inter)


def parse_dt(value) -> Optional[datetime]:
    """支持 datetime / unix 时间戳 / struct_time / ISO 字符串。"""
    if value is None:
        return None

    dt: Optional[datetime] = None
    if isinstance(value, datetime):
        dt = value
    elif isinstance(value, (int, float)):
        dt = datetime.fromtimestamp(float(value), tz=timezone.utc)
    elif isinstance(value, (tuple, list)) and len(value) >= 6:
        try:
            dt = datetime.fromtimestamp(calendar.timegm(tuple(value)), tz=timezone.utc)
        except (ValueError, OverflowError):
            return None
    else:
        text = str(value).strip()
        if not text:
            return None
        if text.isdigit():
            dt = datetime.fromtimestamp(int(text), tz=timezone.utc)
        else:
            try:
                dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
            except ValueError:
                return None

    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def iso_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def to_iso(dt: Optional[datetime]) -> Optional[str]:
    if dt is None:
        return None
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def strip_html(text: str, limit: int = 400) -> str:
    if not text:
        return ""
    text = re.sub(r"<(script|style)\b.*?</\1>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) > limit:
        text = text[:limit].rstrip() + "…"
    return text


def md_safe(text: str, limit: int = 120) -> str:
    """让标题能安全放进 markdown 链接文本。"""
    text = strip_html(text, limit * 2)
    text = text.replace("[", "（").replace("]", "）").replace("\n", " ")
    text = text.replace("|", "／").strip()
    if len(text) > limit:
        text = text[:limit].rstrip() + "…"
    return text or "（无标题）"


LEAD_PREFIX_RE = re.compile(
    r"^(?:[>\-*•·]\s*)*(?:\+\s*\d+|\d+\s*[.、)])\s*"
)
LEAD_BULLET_RE = re.compile(r"^(?:[-*•·]\s+)+")


def clean_lead(text: str) -> str:
    """去掉摘要开头的列表符号（如 "- +1"、"1."、"•"），让正文左对齐。"""
    text = re.sub(r"\s+", " ", text or "").strip()
    for _ in range(3):
        cleaned = LEAD_BULLET_RE.sub("", text)
        cleaned = LEAD_PREFIX_RE.sub("", cleaned).strip()
        if cleaned == text:
            break
        text = cleaned
    return text


def slug(text: str) -> str:
    return re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff]+", "-", text).strip("-")[:60]


CJK_RE = re.compile(r"[\u4e00-\u9fff]")


def has_cjk(text: str) -> bool:
    return bool(CJK_RE.search(text or ""))


def cjk_ratio(text: str) -> float:
    if not text:
        return 0.0
    cjk = len(CJK_RE.findall(text))
    return cjk / float(max(1, len(text)))


def detect_lang(text: str) -> str:
    return "zh" if cjk_ratio(text) >= 0.15 else "en"


def fmt_count(value) -> str:
    """把 7904281 显示成 790万。"""
    try:
        number = float(value or 0)
    except (TypeError, ValueError):
        return ""
    if number >= 1e8:
        return "%.1f亿" % (number / 1e8)
    if number >= 1e4:
        return "%.0f万" % (number / 1e4)
    return "%d" % number
