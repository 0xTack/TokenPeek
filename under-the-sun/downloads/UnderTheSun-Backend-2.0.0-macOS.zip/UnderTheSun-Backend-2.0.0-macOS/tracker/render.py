"""把聚类结果渲染成 Obsidian 里的「报纸」。

版式用 callout 分三档（配合插件装上的 CSS snippet 控制字号）：
    headline  头条   —— 大字号
    feature   要闻   —— 中字号
    brief     简讯   —— 小字号列表

用 callout 而不是裸 HTML，是因为 callout 里面的内容是正常 Markdown，
「跟踪」的复选框才能点。
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import quote

from . import db, judgment
from .util import clean_lead, fmt_count, has_cjk, md_safe, tokens

UNIT = {"hn": " 分", "reddit": "", "github": " 星", "rss": "", "hot": ""}
TOPIC_ORDER = ["时政 / 社会", "经济 / 民生", "科技 / AI", "国际", "文娱 / 体育", "其他"]
DIGEST_TITLE_RE = re.compile(
    r"^>\s*\[!(?:headline|feature|brief)(?:-[a-z]+)?\]\s+(.+?)\s*$", re.M
)


def _previous_digest_tokens(conn: sqlite3.Connection, cfg, day: str, days: int) -> List[set]:
    """收集前几天的报纸标题，用于判断今天是不是又上了同一件事。

    优先读 digest_seen（保存的是原标题，外文也能匹配）；老日报没有这张表时，
    退回到解析 markdown 的 callout 标题。
    """
    if days <= 0:
        return []

    base = datetime.strptime(day, "%Y-%m-%d")
    dates = [
        (base - timedelta(days=offset)).strftime("%Y-%m-%d")
        for offset in range(1, days + 1)
    ]

    titles: List[str] = []
    for row in db.list_digest_seen(conn, dates):
        if row["title"]:
            titles.append(row["title"])

    for date in dates:
        # 老数据的 digested_on 还在时，用原语言标题补一遍（外文尤其需要）
        for row in conn.execute(
            "SELECT title FROM items WHERE digested_on = ?", (date,)
        ):
            if row["title"]:
                titles.append(row["title"])

        path = Path(cfg.digest_dir) / ("%s.md" % date)
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            continue
        titles.extend(match.group(1) for match in DIGEST_TITLE_RE.finditer(text))

    seen = set()
    out: List[set] = []
    for title in titles:
        toks = tokens(title)
        key = tuple(sorted(toks))
        if len(toks) < 2 or key in seen:
            continue
        seen.add(key)
        out.append(toks)
    return out


def _is_repeat(toks: set, previous: List[set], threshold: float, containment: float) -> bool:
    """标题 token 与旧报纸里的某条够像，就算同一件事。"""
    if len(toks) < 2:
        return False
    for known in previous:
        if len(known) < 2:
            continue
        inter = len(toks & known)
        if not inter:
            continue
        union = len(toks) + len(known) - inter
        if union and inter / float(union) >= threshold:
            return True
        # 新标题只是在旧标题上多加了后半句时，Jaccard 会偏低，用包含度兜一下
        if (
            min(len(toks), len(known)) >= 4
            and max(len(toks), len(known)) >= 6
            and inter / float(min(len(toks), len(known))) >= containment
        ):
            return True
    return False


def _extra(row, key: str, default=None):
    try:
        extra = json.loads(row["extra"] or "{}")
    except (TypeError, ValueError):
        return default
    return extra.get(key, default)


def _discussion(row) -> str:
    link = _extra(row, "discussion", "") or ""
    return link if link and link != row["url"] else ""


def _source_suffix(row) -> str:
    kind = row["kind"]
    metric = float(row["metric"] or 0)

    if kind == "hot":
        if _extra(row, "rank_based"):
            rank = _extra(row, "rank")
            return "热门 #%d" % int(rank) if rank else ""
        return "%s热度" % fmt_count(metric) if metric else ""
    if kind == "reddit":
        rank = _extra(row, "rank")
        return "热门 #%d" % int(rank) if rank else ""
    if metric >= 1 and UNIT.get(kind):
        return "%d%s" % (int(round(metric)), UNIT[kind])
    return ""


def _source_line(items: List[sqlite3.Row], separator: str = " · ") -> str:
    best: Dict[str, sqlite3.Row] = {}
    for item in items:
        source = item["source"]
        current = best.get(source)
        if current is None or float(item["metric"] or 0) >= float(current["metric"] or 0):
            best[source] = item
    parts = []
    for source, row in sorted(best.items(), key=lambda kv: -float(kv[1]["metric"] or 0)):
        suffix = _source_suffix(row)
        parts.append("*%s* %s" % (source, suffix) if suffix else "*%s*" % source)
    return separator.join(parts)


def _main_item(cluster: dict):
    return max(cluster["items"], key=lambda r: (float(r["metric"] or 0), r["id"]))


BRIEF_LEAD_CHARS = 140


def _prefer_brief(cluster: dict) -> bool:
    """发生了什么较短时用简讯，较长时用正式新闻版式。"""
    lead = clean_lead(cluster.get("lead") or "")
    return len(lead) <= BRIEF_LEAD_CHARS


def _quota_key(cluster: dict) -> str:
    kind = cluster.get("main_kind")
    if kind in ("rss", "hot"):
        return cluster["main_source"]
    return kind or cluster["main_source"]


def _diversify(
    clusters: List[dict],
    quota: int,
    limit: int,
    mins: Optional[Dict[str, int]] = None,
) -> List[dict]:
    if limit <= 0:
        return []

    picked: List[dict] = []
    chosen = set()
    counts: Dict[str, int] = {}

    # 先放「保底」来源，比如知乎、小红书各 5 条
    for label, need in (mins or {}).items():
        for cluster in clusters:
            if cluster["id"] in chosen or cluster["main_source"] != label:
                continue
            picked.append(cluster)
            chosen.add(cluster["id"])
            counts[label] = counts.get(label, 0) + 1
            if counts[label] >= need:
                break

    # 再按分数补齐，受单源上限约束
    for cluster in clusters:
        if len(picked) >= limit:
            break
        if cluster["id"] in chosen:
            continue
        key = _quota_key(cluster)
        if quota > 0 and counts.get(key, 0) >= quota:
            continue
        picked.append(cluster)
        chosen.add(cluster["id"])
        counts[key] = counts.get(key, 0) + 1

    picked.sort(key=lambda c: (-float(c["score"]), c["id"]))
    return picked[:limit]


def collect(
    conn: sqlite3.Connection, cfg, now: datetime, stats: Optional[Dict[str, int]] = None
) -> Tuple[List[dict], List[dict]]:
    cutoff = (now - timedelta(hours=cfg.window_hours)).astimezone(timezone.utc)
    age_cutoff = (now - timedelta(hours=cfg.max_age_hours)).astimezone(timezone.utc)
    day = now.strftime("%Y-%m-%d")

    filters = cfg.section("filters") or {}
    filter_on = bool(filters.get("enabled", False))
    min_title = int(filters.get("min_title_chars", 6))
    block_words = [str(w).strip() for w in (filters.get("block_keywords") or []) if str(w).strip()]

    rule_matchers = []
    for rule in filters.get("rules") or []:
        if not isinstance(rule, dict):
            continue
        if rule.get("enabled", True) is False:
            continue
        kind = str(rule.get("type") or "keyword").strip().lower()
        value = str(rule.get("value") or "").strip()
        if not value:
            continue
        if kind in ("regex", "正则"):
            try:
                rule_matchers.append(("regex", re.compile(value, re.I)))
            except re.error:
                continue
        elif kind in ("source", "来源"):
            rule_matchers.append(("source", value.lower()))
        elif kind in ("url", "链接", "domain", "域名"):
            rule_matchers.append(("url", value.lower()))
        else:
            rule_matchers.append(("keyword", value.lower()))

    def blocked(row) -> bool:
        if not filter_on:
            return False
        text = (row["title"] or "").strip()
        if len(re.sub(r"\s+", "", text)) < min_title:
            return True
        low = text.lower()
        source = (row["source"] or "").lower()
        url = (row["url"] or "").lower()
        for kind, matcher in rule_matchers:
            if kind == "regex" and matcher.search(text):
                return True
            if kind == "keyword" and matcher in low:
                return True
            if kind == "source" and matcher in source:
                return True
            if kind == "url" and matcher in url:
                return True
        return any(word.lower() in low for word in block_words)

    rows = conn.execute(
        """
        SELECT i.id, i.title, i.url, i.source, i.kind, i.region, i.lang,
               i.summary, i.metric, i.published_at, i.fetched_at, i.extra,
               i.cluster_id,
               c.score AS c_score, c.topic AS c_topic, c.region AS c_region,
               c.title AS c_title
        FROM items i
        JOIN clusters c ON c.id = i.cluster_id
        WHERE i.fetched_at >= ?
          AND COALESCE(i.published_at, i.fetched_at) >= ?
          AND (i.digested_on IS NULL OR i.digested_on <> ?)
        ORDER BY c.score DESC, i.metric DESC
        """,
        (
            cutoff.isoformat(timespec="seconds"),
            age_cutoff.isoformat(timespec="seconds"),
            day,
        ),
    ).fetchall()

    groups: Dict[int, dict] = {}
    order: List[int] = []
    skipped_filter = 0
    for row in rows:
        score = float(row["c_score"] or 0)
        if score < cfg.min_score:
            continue
        if blocked(row):
            skipped_filter += 1
            continue
        cid = int(row["cluster_id"])
        if cid not in groups:
            groups[cid] = {
                "id": cid,
                "score": score,
                "topic": row["c_topic"] or "其他",
                "region": row["c_region"] or row["region"] or "cn",
                "title": row["c_title"] or row["title"],
                "main_source": row["source"],
                "main_kind": row["kind"],
                "items": [],
            }
            order.append(cid)
        groups[cid]["items"].append(row)

    clusters = [groups[cid] for cid in order]
    for cluster in clusters:
        main = _main_item(cluster)
        cluster["main_source"] = main["source"]
        cluster["main_kind"] = main["kind"]
        cluster["region"] = cluster["region"] or main["region"] or "cn"

    # 跨天去重：昨天已经上过、又没有勾跟踪的新闻，今天不再重复出现。
    # 跟踪中的条目保留，因为它的后续进展需要继续被看到。
    dedupe = cfg.section("dedupe") or {}
    skipped = 0
    if dedupe.get("enabled", True):
        days = int(dedupe.get("lookback_days", 7))
        threshold = float(dedupe.get("min_similarity", 0.62))
        containment = float(dedupe.get("containment", 0.86))
        previous = _previous_digest_tokens(conn, cfg, day, days)
        if previous:
            tracked_ids = {
                int(row["item_id"])
                for row in conn.execute("SELECT item_id FROM watches WHERE active = 1")
            }
            kept = []
            for cluster in clusters:
                if any(int(item["id"]) in tracked_ids for item in cluster["items"]):
                    kept.append(cluster)
                    continue
                title_tokens = []
                for item in cluster["items"]:
                    toks = tokens(item["title"])
                    if len(toks) >= 2:
                        title_tokens.append(toks)
                if any(
                    _is_repeat(toks, previous, threshold, containment)
                    for toks in title_tokens
                ):
                    skipped += 1
                    continue
                kept.append(cluster)
            clusters = kept
    if stats is not None:
        stats["skipped_repeat"] = skipped
        stats["skipped_filter"] = skipped_filter

    domestic = [c for c in clusters if c["region"] != "intl"]
    foreign = [c for c in clusters if c["region"] == "intl"]

    return (
        _diversify(domestic, cfg.per_source_limit, cfg.max_cn, cfg.min_per_source),
        _diversify(foreign, cfg.per_source_limit, cfg.max_intl, cfg.min_per_source),
    )


def _checked_ids(path: Path, marker: str = "t") -> set:
    """重出日报时保留用户已经勾选的状态（t=跟踪，r=已读）。"""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return set()
    pattern = re.compile(r"- \[([xX])\][^\n]*?<!--\s*%s:(\d+)\s*-->" % marker)
    return {
        int(match.group(2))
        for match in pattern.finditer(text)
        if match.group(1).lower() == "x"
    }


def _wikilink(note_path: str, cfg) -> str:
    try:
        rel = Path(note_path).relative_to(cfg.vault_dir)
        return str(rel.with_suffix(""))
    except ValueError:
        return Path(note_path).stem


def _display(cluster: dict, main, translator) -> Tuple[str, str, str]:
    """返回（标题，摘要，原标题）。国外条目会翻译。"""
    title = cluster["title"]
    summary = (main["summary"] or "").strip()
    original = ""

    if translator is not None and cluster["region"] == "intl":
        title_zh, summary_zh, translated = translator.display(
            title, summary, main["lang"] or ""
        )
        if translated:
            original = title
            title = title_zh
            summary = summary_zh or summary

    return title, summary, original


def _ai_link(item_id: int) -> str:
    return "obsidian://info-tracker?cmd=ai&item=%d" % item_id


def _chat_link(item_id: int, title: str) -> str:
    return "obsidian://info-tracker?cmd=chat&item=%d&title=%s" % (
        item_id,
        quote(md_safe(title, 80), safe=""),
    )


def _split_ai(text: str) -> Tuple[str, str]:
    """把 AI 输出拆成「一句话总结」和「深度解读」。"""
    text = (text or "").strip()
    if not text:
        return "", ""
    parts = re.split(r"\n?\s*===\s*\n?", text, maxsplit=1)
    if len(parts) == 2:
        summary, deep = parts[0].strip(), parts[1].strip()
    else:
        lines = text.split("\n", 1)
        if len(lines) == 2 and len(lines[0]) <= 80:
            summary, deep = lines[0].strip(), lines[1].strip()
        else:
            summary, deep = "", text

    summary = re.sub(r"^(一句话|总结)[:：]\s*", "", summary).strip()
    deep = re.sub(r"^(深度解读|深度思考)[:：]\s*", "", deep).strip()
    return summary, deep


def _ai_block(text: str) -> List[str]:
    summary, deep = _split_ai(text)
    out: List[str] = []
    if summary:
        out += ["> **一句话**：%s" % summary]
    if deep:
        out += [">", "> > [!ai] 深度解读"]
        first_section = True
        for line in deep.split("\n"):
            line = line.strip()
            if not line:
                continue
            if line.startswith("【") and "】" not in line:
                continue
            if line.startswith("【") and "】" in line:
                if not first_section:
                    out.append("> >")
                head, rest = line.split("】", 1)
                head = head.replace("【", "").strip()
                out.append("> > **%s**：%s" % (head, rest.lstrip("：: ")))
                first_section = False
            else:
                out.append("> > %s" % line)
    return out


def expand_comments(comments: List[dict]) -> List[str]:
    """热评跟「发生了什么」同级，放在 AI 解读前面；没有就不输出。"""
    rows = []
    for comment in comments[:3]:
        text = str(comment.get("text") or "").strip()
        if not text:
            continue
        # 老缓存里可能混进 Reddit 的帖子元信息，不是真评论
        if "submitted by" in text.lower()[:80]:
            continue
        rows.append(
            "> - **%s**：%s"
            % (md_safe(comment.get("by") or "匿名", 16), md_safe(text, 220))
        )
    if not rows:
        return []
    return [">", "> **热评**："] + rows


def _story(
    level: str,
    index: int,
    cluster: dict,
    translator,
    ai,
    checked: set,
    read: set,
    comments: Optional[List[dict]] = None,
) -> List[str]:
    main = _main_item(cluster)
    title, summary, original = _display(cluster, main, translator)

    insight = ""
    show_link = False
    if ai is not None and ai.available():
        insight = ai.cached(title)
        show_link = not insight

    # 国内红、国外蓝；简讯统一灰色，所以只给头条/要闻带地区后缀
    callout = "%s-%s" % (level, "intl" if cluster["region"] == "intl" else "cn")
    lines = ["> [!%s] %s" % (callout, md_safe(title, 90)), ">"]
    lines.append("> %s" % _source_line(cluster["items"]))
    if original:
        lines.append("> 原标题：%s" % md_safe(original, 90))

    lead = clean_lead(cluster.get("lead") or "")
    if (
        lead
        and cluster["region"] == "intl"
        and not has_cjk(lead)
        and translator is not None
        and translator.translate_summary
    ):
        lead = translator.translate(lead[:600], main["lang"] or "") or lead
    if lead:
        lines += [">", "> **发生了什么**：%s" % lead]

    if comments:
        lines += expand_comments(comments)

    if insight:
        lines.append(">")
        lines.extend(_ai_block(insight))

    link = "[原文](<%s>)" % main["url"]
    lead_url = cluster.get("lead_url") or ""
    if lead_url:
        link += " · [相关报道](<%s>)" % lead_url
    discussion = _discussion(main)
    if discussion:
        link += " · [讨论](<%s>)" % discussion
    if show_link:
        link += " · [AI 解读](%s)" % _ai_link(main["id"])
    if ai is not None and ai.available():
        link += " · [AI 交流](%s)" % _chat_link(main["id"], title)
    lines += [">", "> %s" % link]

    lines += [
        ">",
        "> - [%s] *已读* <!-- r:%d -->"
        % ("x" if main["id"] in read else " ", main["id"]),
        "> - [%s] **跟踪** <!-- t:%d -->"
        % ("x" if main["id"] in checked else " ", main["id"]),
        "> ^item-%d" % main["id"],
    ]
    lines.append("")
    return lines


def _brief(cluster: dict, translator, checked: set, read: set, ai=None, comments=None) -> List[str]:
    main = _main_item(cluster)
    title, _, _ = _display(cluster, main, translator)

    lines = ["> [!brief] %s" % md_safe(title, 80), ">"]
    lines.append("> %s · %s" % (_source_line(cluster["items"]), cluster["topic"]))

    lead = clean_lead(cluster.get("lead") or "")
    if lead:
        lines += [">", "> %s" % md_safe(lead, 220)]

    if comments:
        lines += expand_comments(comments)

    link = "[原文](<%s>)" % main["url"]
    if cluster.get("lead_url"):
        link += " · [相关报道](<%s>)" % cluster["lead_url"]
    if ai is not None and ai.available():
        link += " · [AI 解读](%s)" % _ai_link(main["id"])
        link += " · [AI 交流](%s)" % _chat_link(main["id"], title)
    lines += [">", "> %s" % link]

    lines += [
        ">",
        "> - [%s] *已读* <!-- r:%d -->"
        % ("x" if main["id"] in read else " ", main["id"]),
        "> - [%s] **跟踪** <!-- t:%d -->"
        % ("x" if main["id"] in checked else " ", main["id"]),
        "> ^item-%d" % main["id"],
    ]
    lines.append("")
    return lines


def _stats_block(stats: dict) -> List[str]:
    line = "今日已读 %d 条　累计已读 %d 条　累计追踪 %d 条" % (
        int(stats.get("today_read") or 0),
        int(stats.get("total_read") or 0),
        int(stats.get("total_watches") or 0),
    )
    return [
        "<!-- it-stats:start -->",
        "> [!footer]",
        ">",
        "> %s" % line,
        "",
        "<!-- it-stats:end -->",
        "",
    ]


STATS_RE = re.compile(
    r"<!-- it-stats:start -->.*?<!-- it-stats:end -->", re.S
)


def update_stats_block(text: str, stats: dict) -> str:
    block = "\n".join(_stats_block(stats))
    if STATS_RE.search(text):
        return STATS_RE.sub(block, text, count=1)
    return text.rstrip() + "\n\n---\n\n" + block + "\n"


def _judgment_section(
    changes: List[dict], active: Optional[List[dict]] = None, cfg=None
) -> List[str]:
    """日报里的「判断动态」。

    今天有变化的判断给完整卡片；其余观察中的判断给一行简表，
    这样下午新建的判断明天也能在报纸里看到，不会永远错过。
    """
    active = active or []
    if not changes and not active:
        return []

    lines = ["## ▍判断", ""]
    changed_ids = set()
    for change in changes[:6]:
        item = change["summary"]
        changed_ids.add(int(item["id"]))
        latest = change.get("latest") or {}
        previous = change.get("previous") or {}
        claim = item.get("claim") or latest.get("claim") or ""
        if not claim:
            continue

        confidence = int(item.get("confidence") or latest.get("confidence") or 0)
        version = int(item.get("version") or 1)
        status = item.get("status") or "观察中"
        claim_type = item.get("claim_type") or latest.get("claim_type") or ""
        horizon = item.get("horizon") or latest.get("horizon") or ""
        quality = item.get("source_quality") or latest.get("source_quality") or {}
        quality_level = quality.get("level") if isinstance(quality, dict) else ""

        lines.append(
            "> [!judgment] 判断 v%d · 置信度 %d%% · %s"
            % (version, confidence, md_safe(status, 12))
        )
        lines.append(">")
        lines.append("> **判断**：%s" % md_safe(claim, 220))

        meta = []
        if claim_type:
            meta.append("类型：%s" % claim_type)
        if horizon:
            meta.append("有效期：%s" % md_safe(horizon, 40))
        if quality_level:
            meta.append("信源：%s" % quality_level)
        if meta:
            lines.append("> %s" % " · ".join(meta))

        if version <= 1:
            change_text = "今日新增判断（v1）"
        else:
            before = int(previous.get("confidence") or 0)
            change_text = "v%d → v%d，置信度 %d%% → %d%%" % (
                max(1, version - 1),
                version,
                before,
                confidence,
            )
        reason = (change.get("change_reason") or "").strip()
        if reason:
            change_text += " · %s" % md_safe(reason, 160)
        lines.append("> **今日变化**：%s" % change_text)

        confirm = [str(x) for x in (latest.get("confirm_if") or []) if str(x).strip()][:2]
        falsify = [str(x) for x in (latest.get("falsifiers") or []) if str(x).strip()][:2]
        if confirm:
            lines.append("> **什么算我对**：%s" % "；".join(md_safe(x, 90) for x in confirm))
        if falsify:
            lines.append("> **什么算我错**：%s" % "；".join(md_safe(x, 90) for x in falsify))

        evidence = change.get("evidence") or []
        counts = {"support": 0, "contradict": 0, "neutral": 0}
        for row in evidence:
            stance = str(row.get("stance") or "neutral")
            if stance not in counts:
                stance = "neutral"
            counts[stance] += 1
        if evidence:
            lines.append(
                "> **新证据**：支持 %d · 反驳 %d · 无关 %d"
                % (counts["support"], counts["contradict"], counts["neutral"])
            )
            shown = 0
            for row in evidence:
                stance = str(row.get("stance") or "neutral")
                if stance not in ("support", "contradict"):
                    continue
                label = "支持" if stance == "support" else "反驳"
                title = md_safe(row.get("title") or "", 70)
                url = str(row.get("url") or "")
                note = md_safe(row.get("note") or "", 80)
                line = "> - %s：[%s](<%s>)" % (label, title, url)
                if note:
                    line += " — %s" % note
                lines.append(line)
                shown += 1
                if shown >= 3:
                    break

        links = []
        if item.get("url"):
            links.append("[原文](<%s>)" % item["url"])
        links.append("[判断簿](obsidian://info-tracker?cmd=home)")
        lines.append(">")
        lines.append("> %s" % " · ".join(links))
        lines.append("")

    others = [item for item in active if int(item["id"]) not in changed_ids][:6]
    if others:
        lines.append("> [!judgment] 观察中的判断（%d）" % len(active))
        lines.append(">")
        for item in others:
            counts = item.get("evidence_counts") or {}
            evidence_text = ""
            if counts.get("support") or counts.get("contradict"):
                evidence_text = " · 证据 支持%d/反驳%d" % (
                    int(counts.get("support") or 0),
                    int(counts.get("contradict") or 0),
                )
            lines.append(
                "> - %s（v%d · %d%% · %s%s）"
                % (
                    md_safe(item.get("claim") or "", 120),
                    int(item.get("version") or 1),
                    int(item.get("confidence") or 0),
                    md_safe(item.get("status") or "观察中", 12),
                    evidence_text,
                )
            )
        lines.append(">")
        lines.append("> [打开判断簿](obsidian://info-tracker?cmd=home)")
        lines.append("")

    if len(lines) <= 2:
        return []
    return lines


def _tracking_story(row, cfg, ai=None, translator=None) -> List[str]:
    """跟踪报告里的最新一条，按正式新闻的完整版式渲染。"""
    title = row["item_title"] or ""
    summary = row["item_summary"] or ""
    region = row["item_region"] or "cn"
    if translator is not None and region == "intl":
        zh_title, zh_summary, translated = translator.display(
            title, summary, row["item_lang"] or ""
        )
        if translated:
            title = zh_title
            summary = zh_summary or summary

    item_id = int(row["item_id"])
    when = datetime.fromisoformat(row["created_at"]).astimezone()
    day = when.strftime("%Y-%m-%d")
    daily = _wikilink(str(Path(cfg.digest_dir) / ("%s.md" % day)), cfg)
    callout = "feature-intl" if region == "intl" else "feature-cn"

    lines = ["> [!%s] %s" % (callout, md_safe(title, 90)), ">"]
    lines.append("> *%s* · %s" % (md_safe(row["item_source"] or "", 30), when.strftime("%m-%d %H:%M")))
    if summary:
        lines += [">", "> **发生了什么**：%s" % md_safe(summary, 260)]

    links = ["[原文](<%s>)" % row["item_url"], "[[%s#^item-%d|当日报纸]]" % (daily, item_id)]
    if ai is not None and ai.available():
        links.append("[AI 解读](%s)" % _ai_link(item_id))
        links.append("[AI 交流](%s)" % _chat_link(item_id, title))
    lines += [">", "> %s" % " · ".join(links)]
    lines += [
        ">",
        "> - [ ] *已读* <!-- r:%d -->" % item_id,
        "> - [x] **跟踪** <!-- t:%d -->" % item_id,
        "",
    ]
    return lines


def _short_watch_summary(row, ai=None) -> str:
    title = row["item_title"] or ""
    text = row["item_summary"] or ""
    if ai is not None and ai.available():
        out = ai.short_summary(title, text)
        if out:
            return out[:20]
    return (title or text)[:20]


def _watch_section(
    watch_groups: List[dict], cfg, ai=None, translator=None, fold_mode: str = "auto"
) -> List[str]:
    groups = [g for g in watch_groups if g.get("updates")]
    if not groups:
        return []
    lines = ["🔔 跟踪进展", ""]
    multi = len(groups) > 1
    if fold_mode == "expanded":
        marker = "+"
    elif fold_mode == "collapsed":
        marker = "-"
    else:
        marker = "-" if multi else "+"
    for group in groups:
        note = _wikilink(group["note_path"], cfg)
        lines.append("> [!tracking]%s [[%s|%s]]" % (marker, note, md_safe(group["title"], 80)))
        for row in group["updates"][:6]:
            when = datetime.fromisoformat(row["created_at"]).astimezone()
            summary = _short_watch_summary(row, ai)
            lines.append(
                "> %s · %s" % (when.strftime("%m-%d %H:%M"), md_safe(summary, 20))
            )
        lines.append("")
    return lines


def render_markdown(
    domestic: List[dict],
    foreign: List[dict],
    cfg,
    now: datetime,
    day: str,
    translator=None,
    watch_groups: Optional[List[dict]] = None,
    checked: Optional[set] = None,
    ai=None,
    comments: Optional[Dict[int, List[dict]]] = None,
    read_ids: Optional[set] = None,
    judgment_changes: Optional[List[dict]] = None,
    judgment_active: Optional[List[dict]] = None,
    stats: Optional[dict] = None,
) -> str:
    checked = checked or set()
    comments = comments or {}
    read_ids = read_ids or set()
    top_cn, rest_cn = domestic[:1], domestic[1:]
    top_intl, rest_intl = foreign[:1], foreign[1:]

    lines: List[str] = []
    lines.append("---")
    lines.append("date: %s" % day)
    lines.append("type: 每日热点")
    lines.append("cssclasses:")
    lines.append("  - it-reading-mode")
    lines.append("tags:")
    lines.append("  - 每日热点")
    lines.append("  - 信息跟踪")
    lines.append("generated: %s" % now.isoformat(timespec="seconds"))
    lines.append("cn: %d" % len(domestic))
    lines.append("intl: %d" % len(foreign))
    lines.append("---")
    lines.append("")
    lines.append(
        "# %s 每日热点 [一键解读](obsidian://info-tracker?cmd=ai-all&day=%s)"
        % (day, day)
    )
    lines.append("")

    if watch_groups:
        fold_mode = str((cfg.section("digest") or {}).get("tracking_fold", "auto"))
        lines.extend(_watch_section(watch_groups, cfg, ai, translator, fold_mode))

    if judgment_changes or judgment_active:
        lines.extend(_judgment_section(judgment_changes or [], judgment_active, cfg))

    if domestic:
        lines.append("## ▍国内")
        lines.append("")
        for index, cluster in enumerate(top_cn, start=1):
            main = _main_item(cluster)
            lines.extend(
                _story("headline", index, cluster, translator, ai, checked, read_ids,
                       comments.get(main["id"]))
            )
        for index, cluster in enumerate(rest_cn, start=1):
            main = _main_item(cluster)
            if _prefer_brief(cluster):
                lines.extend(_brief(cluster, translator, checked, read_ids, ai,
                                    comments.get(main["id"])))
            else:
                lines.extend(
                    _story("feature", index, cluster, translator, ai, checked, read_ids,
                           comments.get(main["id"]))
                )

    if foreign:
        lines.append("## ▍国外")
        lines.append("")
        for index, cluster in enumerate(top_intl, start=1):
            main = _main_item(cluster)
            lines.extend(
                _story("headline", index, cluster, translator, ai, checked, read_ids,
                       comments.get(main["id"]))
            )
        for index, cluster in enumerate(rest_intl, start=1):
            main = _main_item(cluster)
            if _prefer_brief(cluster):
                lines.extend(_brief(cluster, translator, checked, read_ids, ai,
                                    comments.get(main["id"])))
            else:
                lines.extend(
                    _story("feature", index, cluster, translator, ai, checked, read_ids,
                           comments.get(main["id"]))
                )

    if not domestic and not foreign:
        lines.append("_这一轮没有抓到新内容。_")
        lines.append("")

    lines.append("")
    if stats:
        lines.extend(_stats_block(stats))
    return "\n".join(lines)


def write_digest(
    conn: sqlite3.Connection,
    cfg,
    now: datetime,
    translator=None,
    day: Optional[str] = None,
    watch_groups: Optional[List[dict]] = None,
    ai=None,
    session=None,
) -> Optional[Path]:
    from .enrich import enrich_clusters, hn_comments, reddit_comments, zhihu_comments

    day = day or now.strftime("%Y-%m-%d")
    stats: Dict[str, int] = {}
    domestic, foreign = collect(conn, cfg, now, stats=stats)
    if stats.get("skipped_repeat"):
        print(
            "[dedupe] 跳过 %d 组前 %s 天已报道、且未跟踪的新闻"
            % (
                stats["skipped_repeat"],
                (cfg.section("dedupe") or {}).get("lookback_days", 7),
            ),
            flush=True,
        )
    if stats.get("skipped_filter"):
        print(
            "[filter] 屏蔽 %d 条命中规则的新闻" % stats["skipped_filter"],
            flush=True,
        )
    if not domestic and not foreign:
        return None

    if session is not None:
        domestic = enrich_clusters(conn, cfg, domestic, session)
        foreign = enrich_clusters(conn, cfg, foreign, session)

    # 国外条目用 AI 整理成完整中文摘要（只整理，不做解读）
    if ai is not None and ai.available() and foreign:
        for cluster in foreign:
            main = _main_item(cluster)
            lead = cluster.get("lead") or ""
            if main["lang"] != "zh" and len(lead) >= 40 and not has_cjk(lead):
                zh = ai.summarize(cluster["title"], lead)
                if zh:
                    cluster["lead"] = zh

    if bool(cfg.section("content").get("require", True)):
        mins = cfg.min_per_source or {}
        domestic = [
            c for c in domestic
            if c.get("has_content") or c.get("main_source") in mins
        ]
        foreign = [
            c for c in foreign
            if c.get("has_content") or c.get("main_source") in mins
        ]
    if not domestic and not foreign:
        return None

    comments: Dict[int, List[dict]] = {}
    if session is not None:
        candidates = [
            c for c in (domestic + foreign)
            if _main_item(c)["kind"] in ("hn", "reddit")
        ][:6]
        for cluster in candidates:
            main = _main_item(cluster)
            got = (
                hn_comments(conn, session, main, 3)
                or reddit_comments(conn, session, main, 3)
                or zhihu_comments(
                    conn, session, main, (cfg.section("cookies") or {}).get("zhihu", ""), 3
                )
            )
            if got:
                comments[main["id"]] = got

    target = Path(cfg.digest_dir) / ("%s.md" % day)
    checked = _checked_ids(target, "t")
    read_ids = _checked_ids(target, "r") | db.read_ids(conn)
    judgment_changes = judgment.changes_for_day(conn, day)
    judgment_active = judgment.status_list(conn, limit=20)

    stats = {
        "day": day,
        "today_fetched": db.count_items_for_day(conn, day),
        "today_read": db.count_reads(conn, day),
        "total_read": db.count_reads(conn),
        "total_watches": int(
            conn.execute("SELECT COUNT(*) AS n FROM watches").fetchone()["n"] or 0
        ),
    }

    markdown = render_markdown(
        domestic, foreign, cfg, now, day, translator, watch_groups, checked, ai, comments,
        read_ids, judgment_changes, judgment_active, stats,
    )
    target.parent.mkdir(parents=True, exist_ok=True)

    tmp = target.with_suffix(".md.tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        fh.write(markdown)
    os.replace(str(tmp), str(target))

    item_ids = [
        int(item["id"])
        for cluster in (domestic + foreign)
        for item in cluster["items"]
    ]
    db.mark_digested(conn, day, item_ids)
    db.clear_digest_seen(conn, day)
    db.record_digest_seen(
        conn,
        day,
        [
            (int(item["id"]), item["title"], item["region"] or cluster["region"])
            for cluster in (domestic + foreign)
            for item in cluster["items"]
        ],
    )
    db.record_digest(conn, day, str(target), len(item_ids), len(domestic) + len(foreign))
    return target
