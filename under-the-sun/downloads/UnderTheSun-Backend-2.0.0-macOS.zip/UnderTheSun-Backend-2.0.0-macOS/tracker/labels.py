"""来源显示名与默认地区。"""

SOURCE_LABELS = [
    ("baidu_hot", "百度热搜", "cn"),
    ("toutiao_hot", "头条热榜", "cn"),
    ("qq_hot", "腾讯新闻", "cn"),
    ("weibo_hot", "微博热搜", "cn"),
    ("zhihu_hot", "知乎热榜", "cn"),
    ("xiaohongshu_hot", "小红书热点", "cn"),
    ("bilibili_hot", "B站热搜", "cn"),
    ("douyin_hot", "抖音热榜", "cn"),
    ("hackernews", "Hacker News", "intl"),
    ("github_trending", "GitHub Trending", "intl"),
    ("reddit", "Reddit", "intl"),
    ("rss", "RSS 订阅", "cn"),
]

SOURCE_LABEL_MAP = {
    key: {"label": label, "region": region} for key, label, region in SOURCE_LABELS
}
