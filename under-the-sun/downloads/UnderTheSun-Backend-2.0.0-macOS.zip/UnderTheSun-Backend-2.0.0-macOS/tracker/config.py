"""配置加载。"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

import yaml

ROOT = Path(__file__).resolve().parent.parent


class Config:
    def __init__(self, data: Dict[str, Any], path: Path):
        self.data = data or {}
        self.path = path

    def section(self, name: str) -> Dict[str, Any]:
        value = self.data.get(name) or {}
        return value if isinstance(value, dict) else {}

    def __getitem__(self, name: str) -> Dict[str, Any]:
        return self.section(name)

    def get(self, name: str, default: Any = None) -> Any:
        return self.data.get(name, default)

    @property
    def root(self) -> Path:
        return ROOT

    @property
    def vault_dir(self) -> Path:
        raw = str(self.section("vault").get("path", "")).strip()
        if not raw:
            raise ValueError("config.yaml 里 vault.path 没填")
        return Path(os.path.expanduser(raw))

    @property
    def digest_dir(self) -> Path:
        folder = str(self.section("vault").get("folder", "信息跟踪/日报"))
        return self.vault_dir / folder

    @property
    def db_path(self) -> Path:
        return ROOT / "data" / "tracker.db"

    @property
    def log_dir(self) -> Path:
        return ROOT / "logs"

    @property
    def digest_hour(self) -> int:
        return int(self.section("digest").get("hour", 7))

    @property
    def window_hours(self) -> int:
        return int(self.section("digest").get("window_hours", 24))

    @property
    def top_n(self) -> int:
        return int(self.section("digest").get("top_n", 5))

    @property
    def max_items(self) -> int:
        return int(self.section("digest").get("max_items", 45))

    @property
    def top_n_cn(self) -> int:
        return int(self.section("digest").get("top_n_cn", 8))

    @property
    def top_n_intl(self) -> int:
        return int(self.section("digest").get("top_n_intl", 5))

    @property
    def max_cn(self) -> int:
        return int(self.section("digest").get("max_cn", 30))

    @property
    def max_intl(self) -> int:
        return int(self.section("digest").get("max_intl", 15))

    @property
    def watch_dir(self) -> Path:
        folder = str(self.section("watch").get("folder", "信息跟踪/跟踪"))
        return self.vault_dir / folder

    @property
    def per_source_limit(self) -> int:
        return int(self.section("digest").get("per_source_limit", 4))

    @property
    def min_per_source(self) -> Dict[str, int]:
        raw = self.section("digest").get("min_per_source") or {}
        return {str(k): int(v) for k, v in raw.items()}

    @property
    def max_age_hours(self) -> int:
        return int(self.section("digest").get("max_age_hours", 72))

    @property
    def min_score(self) -> float:
        return float(self.section("digest").get("min_score", 0.0))

    @property
    def scoring(self) -> Dict[str, Any]:
        raw = self.section("scoring")
        return {
            "metric_weight": float(raw.get("metric_weight", 3.0)),
            "source_weight": float(raw.get("source_weight", 2.2)),
            "recency_weight": float(raw.get("recency_weight", 1.5)),
            "recency_half_life_hours": float(raw.get("recency_half_life_hours", 24)),
            "metric_scale": raw.get("metric_scale") or {},
        }

    @property
    def cookies(self) -> Dict[str, str]:
        raw = self.section("cookies")
        return {str(k): str(v or "").strip() for k, v in raw.items()}

    @property
    def ai(self) -> Dict[str, Any]:
        raw = self.section("ai")
        return {
            "enabled": bool(raw.get("enabled", False)),
            "base_url": str(raw.get("base_url") or "https://api.openai.com/v1"),
            "api_key": os.environ.get("INFO_TRACKER_API_KEY")
            or str(raw.get("api_key") or ""),
            "model": str(raw.get("model") or "gpt-4o-mini"),
            "max_items": int(raw.get("max_items", 12)),
            "timeout": int(raw.get("timeout", 60)),
            "temperature": float(raw.get("temperature", 0.3)),
            "reasoning_effort": str(raw.get("reasoning_effort") or "medium"),
        }

    @property
    def http(self) -> Dict[str, Any]:
        return self.section("http")


def _deep_merge(base: Dict[str, Any], over: Dict[str, Any]) -> Dict[str, Any]:
    for key, value in over.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def load(path: str = None) -> Config:
    cfg_path = Path(path).expanduser() if path else ROOT / "config.yaml"
    if not cfg_path.exists():
        raise FileNotFoundError("找不到配置文件：%s" % cfg_path)
    with cfg_path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}

    # 插件改的配置写在这里，不动 config.yaml 的注释
    overrides_path = ROOT / "data" / "overrides.json"
    if overrides_path.exists():
        try:
            with overrides_path.open("r", encoding="utf-8") as fh:
                _deep_merge(data, json.load(fh) or {})
        except (OSError, ValueError):
            pass

    return Config(data, cfg_path)
