#!/bin/bash
# 双击这个文件安装 Under the Sun 本地增强服务。
set -euo pipefail
cd "$(dirname "$0")"
exec ./backend/install-backend.command "$@"
