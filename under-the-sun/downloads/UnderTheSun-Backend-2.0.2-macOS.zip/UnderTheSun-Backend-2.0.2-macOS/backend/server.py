#!/usr/bin/env python3
"""Under the Sun 本地后端。

Obsidian 插件只通过 http://127.0.0.1:<port> 调用这里，不直接运行 Python。
默认端口 8765，token 从 ~/.underthesun/token 读取；没有就自动生成。
"""

from __future__ import annotations

import json
import os
import secrets
import subprocess
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parent
TOKEN_FILE = Path.home() / ".underthesun" / "token"
LOG_FILE = ROOT / "logs" / "run.log"
OVERRIDES = ROOT / "data" / "overrides.json"
STATUS = ROOT / "data" / "status.json"
SCHEDULE = ROOT / "data" / "schedule.json"
API_VERSION = 1
DEFAULT_SCHEDULE = {"enabled": True, "morning": "07:00", "evening": "19:00", "eveningDigest": False}

ALLOWED_COMMANDS = {
    "run",
    "fetch",
    "process",
    "watch",
    "digest",
    "status",
    "stats",
    "watch-stop",
    "watch-start",
    "watch-sort",
    "toggle-feed",
    "add",
    "research",
    "ai-one",
    "ai-all",
    "judge",
    "judge-review",
    "judge-list",
    "watch-flags",
}

_child: subprocess.Popen | None = None


def read_version() -> str:
    try:
        return (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        return "0.0.0"


def load_schedule() -> Dict[str, Any]:
    data = dict(DEFAULT_SCHEDULE)
    try:
        raw = json.loads(SCHEDULE.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            data.update(raw)
    except (OSError, ValueError):
        pass
    return data


def save_schedule(patch: Dict[str, Any]) -> Dict[str, Any]:
    data = load_schedule()
    if "enabled" in patch:
        data["enabled"] = bool(patch["enabled"])
    if "eveningDigest" in patch:
        data["eveningDigest"] = bool(patch["eveningDigest"])
    for key in ("morning", "evening"):
        value = str(patch.get(key, "")).strip()
        if value:
            data[key] = value
    SCHEDULE.parent.mkdir(parents=True, exist_ok=True)
    SCHEDULE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return data


def valid_time(value: str) -> bool:
    try:
        hour, minute = value.split(":")
        return 0 <= int(hour) <= 23 and 0 <= int(minute) <= 59
    except (ValueError, AttributeError):
        return False


def test_sources() -> List[Dict[str, Any]]:
    """逐个测试热榜和 RSS 源，结果取决于本机网络、代理和运行环境。"""
    try:
        from concurrent.futures import ThreadPoolExecutor

        from tracker.adapters.base import build_adapters, build_session, parse_feed_bytes
        from tracker.config import load
        from tracker.labels import SOURCE_LABEL_MAP
    except Exception as exc:  # noqa: BLE001
        return [
            {
                "key": "",
                "name": "配置",
                "url": "",
                "kind": "config",
                "region": "cn",
                "ok": False,
                "status": 0,
                "count": 0,
                "error": str(exc),
            }
        ]
    try:
        cfg = load()
    except Exception as exc:  # noqa: BLE001
        return [
            {
                "key": "",
                "name": "配置",
                "url": "",
                "kind": "config",
                "region": "cn",
                "ok": False,
                "status": 0,
                "count": 0,
                "error": str(exc),
            }
        ]

    session = build_session(cfg.section("http"))
    rss_cfg = cfg.section("sources").get("rss") or {}
    rss_region = str(rss_cfg.get("region") or "cn")
    tasks: List[Any] = []

    for index, feed in enumerate(rss_cfg.get("feeds") or []):
        if isinstance(feed, dict):
            url = str(feed.get("url") or "")
            name = str(feed.get("name") or url)
            region = str(feed.get("region") or rss_region)
        else:
            url = str(feed or "")
            name = url
            region = rss_region
        if not url:
            continue
        tasks.append(("rss", {"key": "rss:%d" % index, "name": name, "url": url, "region": region}))

    for adapter in build_adapters(cfg, session, include_disabled=True):
        if adapter.kind == "rss":
            continue
        tasks.append(("hot", adapter))

    def run(task: Any) -> Dict[str, Any]:
        kind, payload = task
        if kind == "rss":
            url = payload["url"]
            try:
                res = session.get(url, timeout=12)
                parsed = parse_feed_bytes(res.content)
                count = len(parsed.entries)
                ok = 200 <= res.status_code < 400 and count > 0
                if ok:
                    error = ""
                elif res.status_code >= 400:
                    error = "HTTP %s" % res.status_code
                else:
                    error = "没有解析到条目"
                return {
                    "key": payload["key"],
                    "name": payload["name"],
                    "url": url,
                    "kind": "rss",
                    "region": payload["region"],
                    "ok": ok,
                    "status": res.status_code,
                    "count": count,
                    "error": error,
                }
            except Exception as exc:  # noqa: BLE001
                return {
                    "key": payload["key"],
                    "name": payload["name"],
                    "url": url,
                    "kind": "rss",
                    "region": payload["region"],
                    "ok": False,
                    "status": 0,
                    "count": 0,
                    "error": str(exc)[:180],
                }

        adapter = payload
        try:
            adapter.cfg = dict(adapter.cfg)
            adapter.cfg["limit"] = min(3, max(1, int(adapter.cfg.get("limit", 20) or 20)))
            adapter.cfg["limit_per_feed"] = 1
            items = adapter.fetch()
        except Exception as exc:  # noqa: BLE001
            return {
                "key": adapter.name,
                "name": adapter.label,
                "url": "",
                "kind": "hot",
                "region": adapter.region,
                "ok": False,
                "status": 0,
                "count": 0,
                "error": str(exc)[:180],
            }
        ok = bool(items)
        label = (SOURCE_LABEL_MAP.get(adapter.name) or {}).get("label") or adapter.label
        return {
            "key": adapter.name,
            "name": label,
            "url": "",
            "kind": "hot",
            "region": adapter.region,
            "ok": ok,
            "status": 200 if ok else 0,
            "count": len(items),
            "error": "" if ok else (adapter.last_warning or "没有返回条目（可能被阻断、限流或接口变化）"),
        }

    with ThreadPoolExecutor(max_workers=8) as pool:
        return list(pool.map(run, tasks))


def _ai_config() -> Dict[str, Any]:
    from tracker.config import load

    cfg = load()
    ai = cfg.ai
    base_url = str(ai.get("base_url") or "https://api.deepseek.com/v1").rstrip("/")
    return {
        "cfg": cfg,
        "api_key": str(ai.get("api_key") or ""),
        "base_url": base_url,
        "model": str(ai.get("model") or ""),
    }


def _ai_error(text: str, status: int) -> str:
    try:
        data = json.loads(text)
        message = ((data.get("error") or {}).get("message")) or data.get("message")
        if message:
            return "HTTP %d：%s" % (status, str(message)[:200])
    except (ValueError, TypeError):
        pass
    return "HTTP %d：%s" % (status, (text or "")[:200])


def ai_models() -> Dict[str, Any]:
    try:
        from tracker.adapters.base import build_session

        info = _ai_config()
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "models": [], "error": str(exc)}
    if not info["api_key"]:
        return {"ok": False, "models": [], "error": "还没有配置 API Key"}
    session = build_session(info["cfg"].section("http"))
    try:
        res = session.get(
            "%s/models" % info["base_url"],
            headers={"Authorization": "Bearer %s" % info["api_key"]},
            timeout=20,
        )
        if res.status_code != 200:
            return {"ok": False, "models": [], "error": _ai_error(res.text, res.status_code)}
        data = res.json() or {}
        models = sorted(
            {
                str(item.get("id"))
                for item in (data.get("data") or [])
                if isinstance(item, dict) and item.get("id")
            }
        )
        return {"ok": True, "models": models}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "models": [], "error": str(exc)[:200]}


def ai_test(model: str = "", base_url: str = "") -> Dict[str, Any]:
    try:
        from tracker.adapters.base import build_session

        info = _ai_config()
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "message": str(exc)}
    if not info["api_key"]:
        return {"ok": False, "message": "还没有配置 API Key"}
    test_model = (model or info["model"]).strip()
    test_base = (base_url or info["base_url"]).strip().rstrip("/")
    if not test_model:
        return {"ok": False, "message": "还没有配置模型"}
    session = build_session(info["cfg"].section("http"))
    payload = {
        "model": test_model,
        "messages": [{"role": "user", "content": "只回复 ok"}],
        "max_tokens": 32,
        "temperature": 0,
        "stream": False,
    }
    try:
        res = session.post(
            "%s/chat/completions" % test_base,
            headers={
                "Authorization": "Bearer %s" % info["api_key"],
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=30,
        )
        if res.status_code == 200:
            return {
                "ok": True,
                "message": "连接成功：%s 可用" % test_model,
                "model": test_model,
            }
        return {
            "ok": False,
            "message": _ai_error(res.text, res.status_code),
            "model": test_model,
        }
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "message": "请求失败：%s" % str(exc)[:200], "model": test_model}


def scheduler_loop() -> None:

    last: Dict[str, str] = {}
    while True:
        try:
            schedule = load_schedule()
            if schedule.get("enabled", True):
                now = datetime.now()
                clock = now.strftime("%H:%M")
                today = now.strftime("%Y-%m-%d")
                for key in ("morning", "evening"):
                    if schedule.get(key) != clock or last.get(key) == today:
                        continue
                    last[key] = today
                    if key == "evening" and schedule.get("eveningDigest"):
                        run_cli(["run", "--force"])
                    elif key == "morning":
                        run_cli(["run"])
                    else:
                        run_cli(["fetch"])
        except Exception:
            pass
        time.sleep(20)


def load_token() -> str:
    env = os.environ.get("UNDER_THE_SUN_TOKEN", "").strip()
    if env:
        return env
    try:
        token = TOKEN_FILE.read_text(encoding="utf-8").strip()
        if token:
            return token
    except OSError:
        pass
    token = secrets.token_urlsafe(32)
    TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(token + "\n", encoding="utf-8")
    try:
        TOKEN_FILE.chmod(0o600)
    except OSError:
        pass
    print("生成后端 token：%s" % TOKEN_FILE, flush=True)
    return token


TOKEN = load_token()


def python_binary() -> str:
    venv = ROOT / ".venv" / "bin" / "python"
    if venv.exists():
        return str(venv)
    return sys.executable


def json_response(handler: BaseHTTPRequestHandler, code: int, payload: Any) -> None:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def text_response(handler: BaseHTTPRequestHandler, code: int, text: str) -> None:
    body = text.encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", "text/plain; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def read_json_body(handler: BaseHTTPRequestHandler) -> Dict[str, Any]:
    length = int(handler.headers.get("Content-Length") or 0)
    if length <= 0:
        return {}
    raw = handler.rfile.read(length)
    try:
        data = json.loads(raw.decode("utf-8"))
        return data if isinstance(data, dict) else {}
    except (ValueError, UnicodeDecodeError):
        return {}


def run_cli(args: List[str]) -> Dict[str, Any]:
    global _child
    if not args:
        return {"code": -1, "output": "缺少命令"}
    command = str(args[0])
    if command not in ALLOWED_COMMANDS:
        return {"code": -1, "output": "不允许的命令：%s" % command}
    if _child is not None and _child.poll() is None:
        return {"code": -1, "output": "已有任务在运行"}

    cmd = [python_binary(), str(ROOT / "main.py"), *[str(a) for a in args]]
    env = dict(os.environ)
    env["PYTHONUNBUFFERED"] = "1"
    started = time.time()
    try:
        _child = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            text=True,
        )
        output, _ = _child.communicate(timeout=900)
        code = _child.returncode
    except subprocess.TimeoutExpired:
        _child.kill()
        output, _ = _child.communicate()
        code = -1
        output = (output or "") + "\n任务超时"
    except Exception as exc:  # noqa: BLE001
        code = -1
        output = "启动失败：%s" % exc
    finally:
        _child = None

    if len(output) > 200000:
        output = output[-200000:]
    return {
        "code": int(code if code is not None else -1),
        "output": output,
        "duration": round(time.time() - started, 2),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "UnderTheSun/%s" % read_version()

    def log_message(self, fmt: str, *args: Any) -> None:
        # 避免每个请求都刷屏；需要排查时再看 stdout
        if os.environ.get("UNDER_THE_SUN_DEBUG"):
            super().log_message(fmt, *args)

    def authorized(self) -> bool:
        if not TOKEN:
            return True
        return self.headers.get("X-Under-The-Sun-Token", "") == TOKEN

    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Under-The-Sun-Token")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            return json_response(
                self,
                200,
                {"ok": True, "version": read_version(), "api": API_VERSION},
            )
        if not self.authorized():
            return json_response(self, 401, {"ok": False, "error": "unauthorized"})
        if self.path == "/status":
            try:
                data = json.loads(STATUS.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                data = {}
            data["version"] = read_version()
            data["api"] = API_VERSION
            data["root"] = str(ROOT)
            data["schedule"] = load_schedule()
            return json_response(self, 200, data)
        if self.path == "/schedule":
            return json_response(self, 200, load_schedule())
        if self.path == "/sources/test":
            return json_response(self, 200, {"ok": True, "results": test_sources()})
        if self.path == "/ai/models":
            return json_response(self, 200, ai_models())
        if self.path == "/logs":
            try:
                lines = LOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                lines = []
            return text_response(self, 200, "\n".join(lines[-300:]))
        return json_response(self, 404, {"ok": False, "error": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        if not self.authorized():
            return json_response(self, 401, {"ok": False, "error": "unauthorized"})
        if self.path == "/cli":
            data = read_json_body(self)
            args = data.get("args")
            if not isinstance(args, list):
                return json_response(self, 400, {"ok": False, "error": "args must be an array"})
            return json_response(self, 200, run_cli(args))
        if self.path == "/schedule":
            data = read_json_body(self)
            for key in ("morning", "evening"):
                if key in data and not valid_time(str(data[key])):
                    return json_response(self, 400, {"ok": False, "error": "时间格式应为 HH:MM"})
            return json_response(self, 200, save_schedule(data))
        if self.path == "/ai/test":
            data = read_json_body(self)
            return json_response(
                self,
                200,
                ai_test(
                    str(data.get("model") or ""),
                    str(data.get("base_url") or ""),
                ),
            )
        if self.path == "/config":
            data = read_json_body(self)
            try:
                current = json.loads(OVERRIDES.read_text(encoding="utf-8"))
                if not isinstance(current, dict):
                    current = {}
            except (OSError, ValueError):
                current = {}

            def merge(base: Dict[str, Any], patch: Dict[str, Any]) -> None:
                for key, value in patch.items():
                    if isinstance(value, dict) and isinstance(base.get(key), dict):
                        merge(base[key], value)
                    else:
                        base[key] = value

            merge(current, data)
            OVERRIDES.parent.mkdir(parents=True, exist_ok=True)
            OVERRIDES.write_text(
                json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            return json_response(self, 200, {"ok": True})
        return json_response(self, 404, {"ok": False, "error": "not found"})


def main() -> int:
    host = os.environ.get("UNDER_THE_SUN_HOST", "127.0.0.1")
    port = int(os.environ.get("UNDER_THE_SUN_PORT", "8765"))
    server = ThreadingHTTPServer((host, port), Handler)
    threading.Thread(target=scheduler_loop, daemon=True).start()
    print("Under the Sun backend %s on http://%s:%d" % (read_version(), host, port), flush=True)
    print("token file: %s" % TOKEN_FILE, flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
