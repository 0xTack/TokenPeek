#!/bin/bash
# Under the Sun 本地增强服务安装器（macOS）
#
# 用法：
#   双击安装包最外层的「① 双击我安装.command」
#   或在本文件所在目录执行 ./install_backend.sh
#
# 可选参数：
#   --dir "路径"       指定程序安装目录（默认 ~/Library/Application Support/UnderTheSun/backend）
#   --vault "路径"     指定 Obsidian vault，跳过选择
#   --no-launchd       只准备环境，不安装开机自启
#   --no-open          不自动打开 Obsidian
#   --dry-run          只打印将要做的事
#   --keep-src         不复制，直接在当前目录运行（开发用）

set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT="$SRC"
ORIG_ARGS=("$@")
TARGET="$HOME/Library/Application Support/UnderTheSun/backend"
VAULT=""
INSTALL_LAUNCHD=1
OPEN_OBSIDIAN=1
DRY_RUN=0
KEEP_SRC=0
PORT="${UNDER_THE_SUN_PORT:-8765}"
LABEL="com.0xtack.underthesun.backend"
AGENT="$HOME/Library/LaunchAgents/$LABEL.plist"
TOKEN_DIR="$HOME/.underthesun"
TOKEN_FILE="$TOKEN_DIR/token"
STEP=0
TOTAL=6

while [ $# -gt 0 ]; do
  case "$1" in
    --dir) TARGET="${2:-}"; shift 2 ;;
    --vault) VAULT="${2:-}"; shift 2 ;;
    --no-launchd) INSTALL_LAUNCHD=0; shift ;;
    --no-open) OPEN_OBSIDIAN=0; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    --keep-src) KEEP_SRC=1; shift ;;
    -h|--help) sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "未知参数：$1"; exit 1 ;;
  esac
done

say()  { printf '\n%s\n' "$*"; }
step() { STEP=$((STEP + 1)); printf '\n[%d/%d] %s\n' "$STEP" "$TOTAL" "$*"; }
ok()   { printf '      %s ✓\n' "$*"; }
warn() { printf '      %s\n' "$*"; }
die()  {
  printf '\n安装没有完成\n'
  printf '原因：%s\n\n' "$*"
  printf '需要帮助时，把下面这个文件发给作者：\n  %s\n\n' "${ROOT:-$SRC}/logs/backend.log"
  printf '按回车关闭这个窗口。'
  read -r _ || true
  exit 1
}
dry() { [ "$DRY_RUN" -eq 1 ]; }

expand_path() {
  local p="$1"
  p="${p%\"}"; p="${p#\"}"
  p="${p%/}"
  case "$p" in "~"*) p="$HOME${p#\~}" ;; esac
  printf '%s' "$p"
}

is_protected_path() {
  case "$1" in
    "$HOME/Downloads"/*|"$HOME/Desktop"/*|"$HOME/Documents"/*) return 0 ;;
    *) return 1 ;;
  esac
}

printf 'Under the Sun · 本地增强服务安装\n'
printf '==============================\n'

# ---------- 1. 确定安装目录并复制 ----------
TARGET="$(expand_path "$TARGET")"

UNDER_THE_SUN_FROM=""
if [ "$KEEP_SRC" -eq 0 ] && [ "$SRC" != "$TARGET" ]; then
  if is_protected_path "$TARGET"; then
    die "不能安装到「下载 / 桌面 / 文稿」。macOS 不允许后台服务读这些目录，请换一个位置，例如 ~/Library/Application Support/UnderTheSun/backend"
  fi
  step "把程序复制到固定位置"
  echo "      $TARGET"
  if dry; then
    echo "      [dry-run] 跳过复制"
  else
    mkdir -p "$TARGET"
    RSYNC_ARGS=(-a --exclude '.venv' --exclude '__pycache__' --exclude '.DS_Store' --exclude 'config.yaml')
    if [ -d "$TARGET/data" ]; then
      RSYNC_ARGS+=(--exclude 'data')
      echo "      检测到已有数据，保留原来的数据库"
    fi
    if ! rsync "${RSYNC_ARGS[@]}" "$SRC/" "$TARGET/" 2>/dev/null; then
      die "复制失败：没有权限写入 $TARGET。请换一个位置：--dir ~/code/under-the-sun"
    fi
    # 用户改过的 config.yaml 不覆盖
    rsync -a --ignore-existing "$SRC/config.yaml" "$TARGET/"
    chmod +x "$TARGET/scripts/install_backend.sh" 2>/dev/null || true
    ok "完成"
  fi
  if [ "$DRY_RUN" -eq 0 ]; then
    UNDER_THE_SUN_FROM="$SRC"
    SRC="$TARGET"
    ROOT="$TARGET"
  fi
else
  TOTAL=$((TOTAL - 1))
fi

if [ "$KEEP_SRC" -eq 1 ]; then
  ROOT="$SRC"
fi

# ---------- 2. Python ----------
step "检查运行环境"
if ! command -v python3 >/dev/null 2>&1; then
  die "没有找到 python3。请先安装 Python 3.9 或更高版本：https://www.python.org/downloads/"
fi
if ! python3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)'; then
  die "Python 版本太低（当前 $(python3 --version 2>&1)），需要 3.9 或更高。https://www.python.org/downloads/"
fi
ok "Python $(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:3])))')"

# ---------- 3. 选择 vault ----------
step "找到要写入的 Obsidian 笔记库"
find_vaults() {
  local base
  for base in \
    "$HOME/Library/Mobile Documents/iCloud~md~obsidian/Documents" \
    "$HOME/Documents" \
    "$HOME/Obsidian"; do
    [ -d "$base" ] || continue
    find "$base" -maxdepth 3 -type d -name .obsidian -print 2>/dev/null \
      | sed 's#/\.obsidian$##'
  done | sort -u
}

if [ -z "$VAULT" ]; then
  ALL=()
  while IFS= read -r line; do [ -n "$line" ] && ALL+=("$line"); done < <(find_vaults)

  WITH_PLUGIN=()
  for v in "${ALL[@]:-}"; do
    [ -n "$v" ] || continue
    if [ -d "$v/.obsidian/plugins/under-the-sun" ]; then
      WITH_PLUGIN+=("$v")
    fi
  done

  if [ "${#WITH_PLUGIN[@]}" -eq 1 ]; then
    VAULT="${WITH_PLUGIN[0]}"
    echo "      检测到插件安装在："
    echo "      $VAULT"
    echo "      自动选择，不用操作。"
  elif [ "${#ALL[@]}" -eq 0 ]; then
    die "没有找到 Obsidian 笔记库。请先在 Obsidian 里打开你的笔记库，再运行一次。"
  elif [ "${#ALL[@]}" -eq 1 ]; then
    VAULT="${ALL[0]}"
    echo "      $VAULT"
    warning="还没在 Obsidian 里安装 Under the Sun 插件，这次只配置后端。"
    ok "找到一个笔记库"; warn "$warning"
  else
    echo "      找到多个笔记库，请选一个（输入数字后按回车）："
    for i in "${!ALL[@]}"; do
      printf '        %d) %s\n' "$((i + 1))" "${ALL[$i]}"
    done
    printf '      选择：'
    read -r choice
    if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#ALL[@]}" ]; then
      VAULT="${ALL[$((choice - 1))]}"
    else
      VAULT="$choice"
    fi
  fi
fi

VAULT="$(expand_path "$VAULT")"
if [ ! -d "$VAULT/.obsidian" ]; then
  die "这不是一个 Obsidian 笔记库（找不到 .obsidian）：$VAULT"
fi
ok "笔记库：$VAULT"

# ---------- 4. Python 环境 ----------
step "安装运行环境（首次约 1–3 分钟）"
if [ ! -x "$ROOT/.venv/bin/python" ]; then
  if dry; then
    echo "      [dry-run] 创建 .venv"
  else
    python3 -m venv "$ROOT/.venv"
  fi
fi
PY="$ROOT/.venv/bin/python"
if dry && [ ! -x "$PY" ]; then PY="$(command -v python3)"; fi
if ! dry; then
  "$PY" -m pip install --upgrade pip >/dev/null 2>&1 || true
  if ! "$PY" -m pip install -r "$ROOT/requirements.txt" >/tmp/uts-pip.log 2>&1; then
    printf '      依赖安装失败，最后几行：\n'
    tail -n 15 /tmp/uts-pip.log
    die "安装 Python 依赖失败。请检查网络后重试；如果需要代理，先在终端设置 http_proxy。"
  fi
  ok "完成"
fi

# ---------- 5. 配置 ----------
step "写入配置和访问密码"
if dry; then
  echo "      [dry-run] 写入 vault 路径、token、插件配置"
else
  mkdir -p "$ROOT/data" "$TOKEN_DIR"
  VAULT="$VAULT" ROOT="$ROOT" "$PY" - <<'PY'
import json, os
from pathlib import Path
root = Path(os.environ["ROOT"])
path = root / "data" / "overrides.json"
try:
    data = json.loads(path.read_text(encoding="utf-8"))
except Exception:
    data = {}
data.setdefault("vault", {})["path"] = os.environ["VAULT"]
path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
PY
  if [ ! -s "$TOKEN_FILE" ]; then
    openssl rand -hex 32 > "$TOKEN_FILE"
    chmod 600 "$TOKEN_FILE"
  fi

  PLUGIN_JSON="$VAULT/.obsidian/plugins/under-the-sun/data.json"
  if [ -d "$(dirname "$PLUGIN_JSON")" ]; then
    if pgrep -x Obsidian >/dev/null 2>&1; then
      echo "      先关闭 Obsidian，避免配置被覆盖 …"
      osascript -e 'tell application "Obsidian" to quit' >/dev/null 2>&1 || true
      for _ in $(seq 1 20); do pgrep -x Obsidian >/dev/null 2>&1 || break; sleep 1; done
    fi
    ROOT="$ROOT" PLUGIN_JSON="$PLUGIN_JSON" TOKEN_FILE="$TOKEN_FILE" PORT="$PORT" "$PY" - <<'PY'
import json, os
from pathlib import Path
path = Path(os.environ["PLUGIN_JSON"])
try:
    data = json.loads(path.read_text(encoding="utf-8"))
except Exception:
    data = {}
data["backendUrl"] = "http://127.0.0.1:%s" % os.environ["PORT"]
data["backendToken"] = Path(os.environ["TOKEN_FILE"]).read_text(encoding="utf-8").strip()
path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
PY
    ok "已写入插件配置"
  else
    warn "还没装插件，稍后在插件设置里粘贴 token 即可"
  fi
fi

# ---------- 6. 开机自启 ----------
if [ "$INSTALL_LAUNCHD" -eq 1 ]; then
  step "设置开机自动启动"
  if dry; then
    echo "      [dry-run] 写入 $AGENT"
  else
    mkdir -p "$HOME/Library/LaunchAgents" "$ROOT/logs"
    sed -e "s|__ROOT__|$ROOT|g" -e "s|__PY__|$PY|g" \
      "$ROOT/scripts/underthesun-backend.plist.template" > "$AGENT"
    launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
    if ! launchctl bootstrap "gui/$(id -u)" "$AGENT"; then
      rm -f "$AGENT"
      die "后台服务注册失败。请重启电脑后重试。"
    fi
    launchctl enable "gui/$(id -u)/$LABEL" 2>/dev/null || true
    ok "完成"
  fi
else
  step "跳过开机自动启动（--no-launchd）"
fi

# ---------- 验证 ----------
port_owner() {
  local pid
  pid="$(lsof -nP -iTCP:"$PORT" -sTCP:LISTEN -t 2>/dev/null | head -1)"
  [ -n "$pid" ] || return 1
  ps -o command= -p "$pid" 2>/dev/null | head -1
}

show_log() {
  if [ -f "$ROOT/logs/backend.log" ]; then
    printf '\n---- 最近日志 ----\n'
    tail -n 25 "$ROOT/logs/backend.log" || true
    printf -- '------------------\n'
  fi
}

rollback() {
  launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
  rm -f "$AGENT"
  printf '已停止后台服务，避免它反复重启。\n'
}

if ! dry && [ "$INSTALL_LAUNCHD" -eq 1 ]; then
  printf '\n正在等待后台服务启动（最多 20 秒）…\n'
  ready=0
  for _ in $(seq 1 20); do
    if curl -fsS "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; then
      ready=1
      break
    fi
    sleep 1
  done

  if [ "$ready" -ne 1 ]; then
    show_log
    rollback
    die "后台服务没有启动成功。常见原因是安装目录没有权限、网络不通、或 8765 端口被占用。"
  fi

  owner="$(port_owner || true)"
  case "$owner" in
    *"$ROOT"*)
      printf '\n后台服务已就绪 ✓  http://127.0.0.1:%s\n' "$PORT"
      curl -s "http://127.0.0.1:$PORT/health"; echo
      ;;
    "")
      show_log
      rollback
      die "端口 $PORT 有响应，但查不到是哪个程序。请重试，或换端口：UNDER_THE_SUN_PORT=8766"
      ;;
    *)
      show_log
      rollback
      die "端口 $PORT 被另一个程序占用，这次安装没有生效。先关掉旧的后端，或换端口重装。"
      ;;
  esac
fi

if [ "$OPEN_OBSIDIAN" -eq 1 ] && ! dry; then
  open -b md.obsidian 2>/dev/null || open -a Obsidian 2>/dev/null || true
fi

printf '\n安装完成 ✓\n\n'
printf '程序位置：\n  %s\n\n' "$ROOT"
if [ "$UNDER_THE_SUN_FROM" != "" ] && [ "$UNDER_THE_SUN_FROM" != "$ROOT" ]; then
  removable="$UNDER_THE_SUN_FROM"
  if [ "$(basename "$removable")" = "backend" ]; then
    removable="$(dirname "$removable")"
  fi
  printf '解压出来的安装文件夹可以删掉了：\n  %s\n\n' "$removable"
fi
printf '接下来：\n'
printf '  1. 打开 Obsidian\n'
printf '  2. 点开 Under the Sun 主页\n'
printf '  3. 底部显示「本地增强服务 已连接」就好了\n\n'
printf '按回车关闭这个窗口。'
read -r _ || true
